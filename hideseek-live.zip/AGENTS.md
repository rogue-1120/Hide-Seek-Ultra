# Project Guidance

## User Preferences

- Live pinch-zoom map built in-app with real map tiles and touch gestures (no third-party map SDK)
- Mobile-first experience
- Unique player colors chosen per device
- Game rules: 5-minute seeker wait, 500m play zone, 3m catch range, 20m hider-seeker visibility, 10s reveal every 3min, 1-hour game length
- Physical-movement rules shown as on-screen warnings; auto-disqualify only on clearly detected violations
- Anyone with the lobby code joins instantly; lobby holds 2 to 12 players

## Verified Commands

- **typecheck**: `pnpm typecheck`
- **fix**: `pnpm fix`
- **build**: `pnpm build`

## Learnings

- Under --default-persistent-actors with an enhanced migration chain, every stable field in main.mo must be declared with a type only (no initializer); the init migration's NewActor must supply a value for each, including AccessControl.initState().
- Motoko has no triple-quoted string literal — build multi-line documents from escaped single-line literals concatenated with #.
- Immutable record fields cannot be assigned with := (M0073); when the record also has var fields, rebuild the record explicitly and store it back into the owning Map.
- `?Record != null` fails with M0060 when the record has var fields — use a switch on the option instead.
- A query function cannot mutate state, so reveal-window opening must live in the update-path tick(); toRevealState must be a pure read.
- GameMap anchors the play-zone arc to a projected boundaryCenter, not the viewport center, so the circle stays fixed to the seeker's start point while panning and zooming.
- The backend returns no hider coordinates to a seeker outside a reveal window, so the catch control must be enabled from the roster and let catchHider validate the 3m rule server-side.
- leaveLobby accepts both #lobby and #ended phases so non-hosts are not stranded after the host calls endLobby.
- useGameState's notInLobby is true while the actor is still loading, so null-state branches can flash before the actor resolves.
- TanStack Router's root route reads useRouterState to apply Layout fullBleed/hideHeader per pathname, giving gameplay routes a full-viewport map.
