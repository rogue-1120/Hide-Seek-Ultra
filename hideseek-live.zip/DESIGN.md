# Design Brief

## Direction

Night Ops Field Kit — a dark, tactical instrument panel for an outdoor hide-and-seek game, built to be read at a glance while running in the dark.

## Tone

Brutalist-utilitarian meets playful game night: near-black surfaces, hairline grids, and one electric signal green that reads as "live channel" — the interface of a field radio, not a party app.

## Differentiation

Every critical number is a monospaced, tabular readout (access code, distance-to-zone, countdown, catch range) — the app feels like a piece of equipment you carry, not a website you visit.

## Color Palette

| Token      | OKLCH       | Role                                        |
| ---------- | ----------- | ------------------------------------------- |
| background | 0.16 0.012 250 | App canvas — near-black with cool cast   |
| foreground | 0.95 0.008 250 | Primary text, high contrast for outdoors |
| card       | 0.21 0.016 250 | Panels, lobby rows, HUD tiles            |
| primary    | 0.78 0.19 148  | Signal green — live, seeker, go states   |
| accent     | 0.68 0.2 28    | Hot coral — catch, out-of-zone, danger   |
| muted      | 0.26 0.02 250  | Inactive rows, secondary surfaces        |
| warning    | 0.8 0.16 82    | Freeze warning (0–10m proximity)         |

## Typography

- Display: Space Grotesk — headings, role labels, player names (sharp, numeric-friendly)
- Body: DM Sans — paragraphs, buttons, form labels (legible in daylight glare)
- Mono: JetBrains Mono — access codes, distances, countdowns, coordinates
- Scale: hero `text-4xl font-bold tracking-tight`, h2 `text-2xl font-semibold tracking-tight`, label `text-xs font-semibold tracking-[0.2em] uppercase`, body `text-base`

## Elevation & Depth

Flat dark surfaces with hairline borders; depth comes from layered opacity (`bg-muted/40`), a 22px field grid texture on map-adjacent panels, and two restrained glows (`glow-signal`, `glow-danger`) reserved for live and catch states.

## Structural Zones

| Zone    | Background             | Border      | Notes                                             |
| ------- | ---------------------- | ----------- | ------------------------------------------------- |
| Header  | `bg-card`              | `border-b`  | Lobby code + role badge always visible            |
| Content | `bg-background`        | —           | Map fills viewport; HUD floats over it            |
| Panels  | `bg-muted/40`          | `border`    | Player list, rule cards, RPS chooser              |
| Footer  | `bg-card/95 backdrop-blur` | `border-t` | Sticky action bar: Start, Catch, Reset            |

## Spacing & Rhythm

Mobile-first single column with `px-4` gutters; 8/12/16px micro-spacing inside tiles, 24px between sections, and generous 32px breathing room around the primary CTA so it is thumb-reachable and never crowded.

## Component Patterns

- Buttons: pill (`rounded-full`) for primary actions, `rounded-xl` for secondary; primary uses `bg-primary text-primary-foreground`, danger uses `bg-gradient-danger`, hover lifts with `transition-smooth`
- Cards: `rounded-2xl bg-card border border-border`, no drop shadows, `field-grid` texture on map overlays
- Badges: small pill with `role` color dot + uppercase mono label; player color shown as a filled 12px swatch ring

## Motion

- Entrance: 200ms fade + 8px rise, staggered 40ms per list item
- Hover: 150ms background/border shift only — no scale on mobile
- Decorative: `pulse-live` 2s breathing glow on the seeker indicator; `radar-sweep` 3s rotating ring for the 10-second hider reveal

## Constraints

- Dark-first: light mode exists only as a daylight fallback, never the default
- Contrast AA+ everywhere; never rely on opacity alone for meaning
- Player identity colors are data, not theme tokens — never hardcode them as accents
- Map is canvas-rendered (tiles + gestures), so its colors may use literal values
- No in-game chat surfaces, no match history or stats surfaces

## Signature Detail

The access-code plate: a monospaced, `0.32em`-tracked code inside a bordered plate with a signal-green glow — the lobby's handshake, styled like a callsign readout.
