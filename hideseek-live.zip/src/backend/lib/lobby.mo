import Char "mo:core/Char";
import Int "mo:core/Int";
import Iter "mo:core/Iter";
import Nat "mo:core/Nat";
import Nat64 "mo:core/Nat64";
import Result "mo:core/Result";
import Text "mo:core/Text";
import Time "mo:core/Time";
import Common "../types/common";
import LobbyTypes "../types/lobby";

module {
  public type Lobby = LobbyTypes.Lobby;
  public type Player = LobbyTypes.Player;
  public type GameError = Common.GameError;
  public type GameView = Common.GameView;
  public type PlayerView = Common.PlayerView;
  public type PlayerPosition = Common.PlayerPosition;
  public type GeoPoint = Common.GeoPoint;
  public type Timestamp = Common.Timestamp;
  public type Centimetres = Common.Centimetres;
  public type ColorHex = Common.ColorHex;
  public type AccessCode = Common.AccessCode;
  public type LobbyId = Common.LobbyId;
  public type PlayerId = Common.PlayerId;
  public type RpsChoice = Common.RpsChoice;
  public type RpsState = Common.RpsState;
  public type RevealState = Common.RevealState;
  public type EndReason = Common.EndReason;
  public type LobbyPhase = Common.LobbyPhase;

  /// Maximum players allowed in a lobby.
  public let maxPlayers : Nat = 12;

  /// Minimum players required to start a game.
  public let minPlayers : Nat = 2;

  /// Play-zone radius in centimetres (500 metres).
  public let playZoneRadiusCm : Centimetres = 50_000;

  /// Catch range in centimetres (3 metres).
  public let catchRangeCm : Centimetres = 300;

  /// Distance within which a hider can see the seeker (20 metres).
  public let hiderSeekerVisibilityCm : Centimetres = 2_000;

  /// Seeker wait phase duration in nanoseconds (5 minutes).
  public let waitPhaseNs : Int = 300_000_000_000;

  /// Total game duration in nanoseconds (1 hour).
  public let gameDurationNs : Int = 3_600_000_000_000;

  /// Reveal window duration in nanoseconds (10 seconds).
  public let revealWindowNs : Int = 10_000_000_000;

  /// Interval between reveal windows in nanoseconds (3 minutes).
  public let revealIntervalNs : Int = 180_000_000_000;

  /// Characters used for access codes: uppercase alphanumeric with ambiguous
  /// characters (0/O, 1/I) removed.
  let codeAlphabet : [Char] = [
    'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M',
    'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
    '2', '3', '4', '5', '6', '7', '8', '9',
  ];

  /// Generate a unique random 6-character uppercase alphanumeric access code
  /// that is not already present in `existing`.
  public func generateAccessCode(existing : [AccessCode]) : AccessCode {
    var candidate = "";
    var attempts = 0;
    while (attempts < 100) {
      candidate := randomCode(attempts);
      if (not existing.contains(candidate)) {
        return candidate;
      };
      attempts += 1;
    };
    // Extremely unlikely fallback: extend with a numeric suffix until unique.
    var suffix = 0;
    var fallback = candidate;
    while (existing.contains(fallback)) {
      fallback := candidate.concat(suffix.toText());
      suffix += 1;
    };
    fallback;
  };

  /// Build one random 6-character code from the unambiguous alphabet.
  /// Uses a small xorshift PRNG seeded from the server clock; the code is a
  /// convenience handle, not a secret, and uniqueness is enforced by the caller.
  func randomCode(salt : Nat) : AccessCode {
    let size = codeAlphabet.size();
    var rng = Nat.toNat64(Int.abs(Time.now()) + salt * 0x9E3779B9);
    var code = "";
    var i = 0;
    while (i < 6) {
      rng := xorshift(rng);
      let idx = rng.toNat() % size;
      code := code.concat(codeAlphabet[idx].toText());
      i += 1;
    };
    code;
  };

  /// xorshift64* step.
  func xorshift(x : Nat64) : Nat64 {
    var v = x;
    if (v == 0) { v := 0x9E3779B97F4A7C15 };
    v := v ^ (v >> 12);
    v := v ^ (v << 25);
    v := v ^ (v >> 27);
    v *% 0x2545F4914F6CDD1D;
  };

  /// Find a player by principal within a lobby.
  public func findPlayerByPrincipal(lobby : Lobby, principal : Principal) : ?Player {
    lobby.players.find(func(p) = p.principal == principal);
  };

  /// Find a player by id within a lobby.
  public func findPlayerById(lobby : Lobby, playerId : PlayerId) : ?Player {
    lobby.players.find(func(p) = p.id == playerId);
  };

  /// Transfer host to another principal. `hostPrincipal` is immutable, so a
  /// rebuilt lobby record is returned for the caller to store back into the map.
  public func transferHost(lobby : Lobby, newHost : Principal) : Lobby {
    {
      id = lobby.id;
      accessCode = lobby.accessCode;
      hostPrincipal = newHost;
      var phase = lobby.phase;
      var players = lobby.players;
      var startPoint = lobby.startPoint;
      var startedAt = lobby.startedAt;
      var waitEndsAt = lobby.waitEndsAt;
      var endsAt = lobby.endsAt;
      var rpsRound = lobby.rpsRound;
      var rpsOutcome = lobby.rpsOutcome;
      var seekerId = lobby.seekerId;
      var revealStartedAt = lobby.revealStartedAt;
      var revealExpiresAt = lobby.revealExpiresAt;
      var nextRevealAt = lobby.nextRevealAt;
      var endReason = lobby.endReason;
      var winnerIds = lobby.winnerIds;
    };
  };

  /// Change a player's color. `color` is immutable, so the player record is
  /// rebuilt and swapped into the lobby's player array.
  public func setPlayerColor(lobby : Lobby, playerId : PlayerId, color : ColorHex) : () {
    let rebuilt = lobby.players.map(
      func(p) {
        if (p.id == playerId) {
          {
            id = p.id;
            principal = p.principal;
            name = p.name;
            color;
            var role = p.role;
            var isOriginalSeeker = p.isOriginalSeeker;
            var isReady = p.isReady;
            var isDisqualified = p.isDisqualified;
            var isCaught = p.isCaught;
            var lastPosition = p.lastPosition;
            var lastPositionAt = p.lastPositionAt;
            var rpsChoice = p.rpsChoice;
          };
        } else {
          p;
        };
      }
    );
    lobby.players := rebuilt;
  };

  /// Whether a color is already taken by another player in the lobby.
  public func isColorTaken(lobby : Lobby, color : ColorHex) : Bool {
    lobby.players.any(func(p) = p.color == color);
  };

  /// Validate a display name (non-empty, bounded length).
  public func isValidName(name : Text) : Bool {
    let trimmed = name.trim(#predicate(func(c) = c == ' '));
    trimmed.size() > 0 and trimmed.size() <= 24;
  };

  /// Validate a color hex string (e.g. "#ff8800").
  public func isValidColor(color : ColorHex) : Bool {
    if (color.size() != 7) { return false };
    if (not color.startsWith(#text "#")) { return false };
    let body = color.trimStart(#text "#");
    body.size() == 6 and body.toIter().all(func(c) = isHexDigit(c));
  };

  func isHexDigit(c : Char) : Bool {
    (c >= '0' and c <= '9') or (c >= 'a' and c <= 'f') or (c >= 'A' and c <= 'F');
  };

  /// Build the caller-specific game view, applying visibility rules.
  public func toGameView(lobby : Lobby, caller : Principal, now : Timestamp) : GameView {
    let self = findPlayerByPrincipal(lobby, caller);
    let selfId = switch (self) {
      case (?p) { p.id };
      case null { 0 };
    };
    let selfPosition = switch (self) {
      case (?p) { toPosition(lobby, p) };
      case null { null };
    };
    let visible = switch (self) {
      case (?p) { visiblePositions(lobby, p, now) };
      case null { [] };
    };
    let hostId = switch (findPlayerByPrincipal(lobby, lobby.hostPrincipal)) {
      case (?h) { h.id };
      case null { 0 };
    };
    {
      lobbyId = lobby.id;
      accessCode = lobby.accessCode;
      phase = lobby.phase;
      hostId;
      startPoint = lobby.startPoint;
      startedAt = lobby.startedAt;
      waitEndsAt = lobby.waitEndsAt;
      endsAt = lobby.endsAt;
      serverNow = now;
      players = lobby.players.map(func(p) = toPlayerView(lobby, p));
      selfId;
      selfPosition;
      visiblePositions = visible;
      rps = if (lobby.phase == #rps) { ?toRpsState(lobby) } else { null };
      reveal = if (lobby.phase == #active or lobby.phase == #waiting) {
        ?toRevealState(lobby, now);
      } else {
        null;
      };
      endReason = lobby.endReason;
      winnerIds = lobby.winnerIds;
    };
  };

  /// Build the public player view.
  public func toPlayerView(lobby : Lobby, player : Player) : PlayerView {
    {
      id = player.id;
      name = player.name;
      color = player.color;
      role = player.role;
      isOriginalSeeker = player.isOriginalSeeker;
      isReady = player.isReady;
      isDisqualified = player.isDisqualified;
      isCaught = player.isCaught;
      isHost = player.principal == lobby.hostPrincipal;
    };
  };

  /// Build a position record for a player that has reported one.
  func toPosition(lobby : Lobby, player : Player) : ?PlayerPosition {
    switch (player.lastPosition, player.lastPositionAt) {
      case (?point, ?updatedAt) {
        ?{
          playerId = player.id;
          point;
          distanceFromStart = distanceFromStart(lobby, point);
          updatedAt;
        };
      };
      case _ { null };
    };
  };

  /// Compute the distance in centimetres between two geographic points.
  public func distanceBetween(a : GeoPoint, b : GeoPoint) : Centimetres {
    // Equirectangular approximation, accurate enough at these scales.
    let latDiff = Int.abs(a.lat - b.lat);
    let lngDiff = Int.abs(a.lng - b.lng);
    // 1 micro-degree of latitude is ~11.132 cm; longitude scales by cos(lat).
    let latCm = latDiff * 11132 / 10000;
    let midLat = (a.lat + b.lat) / 2;
    let cosScaled = cosineScaled(midLat);
    let lngCm = lngDiff * 11132 / 10000 * cosScaled / 10000;
    sqrtNat(latCm * latCm + lngCm * lngCm);
  };

  /// Scaled cosine (x10000) of a latitude in micro-degrees.
  func cosineScaled(microDeg : Int) : Nat {
    // Normalise to [-180_000_000, 180_000_000] micro-degrees.
    let deg = microDeg % 360_000_000;
    let normalised = if (deg > 180_000_000) { deg - 360_000_000 } else { deg };
    let absDeg = Int.abs(normalised);
    // Linear approximation of cos over 0..90 degrees is poor; use a small
    // piecewise table over 0..90 degrees in 10-degree steps.
    let table : [Nat] = [10000, 9848, 9397, 8660, 7660, 6428, 5000, 3420, 1736, 0];
    if (absDeg >= 90_000_000) {
      // Mirror for 90..180 degrees.
      let mirrored = 180_000_000 - absDeg;
      let idx = mirrored / 10_000_000;
      let i = if (idx >= 9) { 9 } else { idx };
      table[i];
    } else {
      let idx = absDeg / 10_000_000;
      let i = if (idx >= 9) { 9 } else { idx };
      table[i];
    };
  };

  /// Integer square root (floor).
  func sqrtNat(n : Nat) : Nat {
    if (n == 0) { return 0 };
    var x = n;
    var y = (x + 1) / 2;
    while (y < x) {
      x := y;
      y := (x + n / x) / 2;
    };
    x;
  };

  /// Compute the distance in centimetres from the lobby start point.
  public func distanceFromStart(lobby : Lobby, point : GeoPoint) : Centimetres {
    switch (lobby.startPoint) {
      case (?start) { distanceBetween(start, point) };
      case null { 0 };
    };
  };

  /// Record a player's position and disqualify them if outside the 500m zone.
  public func updatePosition(lobby : Lobby, player : Player, point : GeoPoint, now : Timestamp) : () {
    player.lastPosition := ?point;
    player.lastPositionAt := ?now;
    if (lobby.phase == #waiting or lobby.phase == #active) {
      // The play zone is centred on the seeker's start point; capture it the
      // first time the seeker reports a position.
      if (player.isOriginalSeeker and lobby.startPoint == null) {
        lobby.startPoint := ?point;
      };
      let dist = distanceFromStart(lobby, point);
      if (dist > playZoneRadiusCm and not player.isDisqualified) {
        player.isDisqualified := true;
      };
    };
  };

  /// Advance the lobby phase based on the server clock (wait phase end, game end).
  public func tick(lobby : Lobby, now : Timestamp) : () {
    switch (lobby.phase) {
      case (#waiting) {
        switch (lobby.waitEndsAt) {
          case (?waitEndsAt) {
            if (now >= waitEndsAt) {
              lobby.phase := #active;
            };
          };
          case null {};
        };
      };
      case (#active) {
        // Open a reveal window when one is due.
        switch (lobby.nextRevealAt) {
          case (?nextRevealAt) {
            if (now >= nextRevealAt) {
              lobby.revealStartedAt := ?now;
              lobby.revealExpiresAt := ?(now + revealWindowNs);
              lobby.nextRevealAt := ?(now + revealIntervalNs);
            };
          };
          case null {};
        };
        switch (lobby.endsAt) {
          case (?endsAt) {
            if (now >= endsAt) {
              endGame(lobby, #timeExpired, now);
            };
          };
          case null {};
        };
      };
      case _ {};
    };
  };

  /// Resolve the current rock-paper-scissors round once all players have chosen.
  public func resolveRps(lobby : Lobby) : () {
    if (lobby.phase != #rps) { return };
    let active = lobby.players.filter(func(p) = not p.isDisqualified);
    if (active.size() < minPlayers) { return };
    let allChosen = active.all(func(p) = p.rpsChoice != null);
    if (not allChosen) { return };

    // Count wins per player: a player wins if they beat every other choice.
    var winners : [Player] = [];
    for (p in active.values()) {
      let mine = p.rpsChoice;
      var beatsAll = true;
      for (q in active.values()) {
        if (q.id != p.id) {
          if (not beats(mine, q.rpsChoice)) {
            beatsAll := false;
          };
        };
      };
      if (beatsAll) {
        winners := winners.concat([p]);
      };
    };

    if (winners.size() == 1) {
      let seeker = winners[0];
      lobby.seekerId := ?seeker.id;
      lobby.rpsOutcome := #resolved;
      for (p in lobby.players.values()) {
        p.role := #hider;
        p.isOriginalSeeker := false;
      };
      seeker.role := #seeker;
      seeker.isOriginalSeeker := true;
      lobby.phase := #waiting;
      let now = Time.now();
      lobby.startedAt := ?now;
      lobby.waitEndsAt := ?(now + waitPhaseNs);
      lobby.endsAt := ?(now + gameDurationNs);
      lobby.startPoint := seeker.lastPosition;
      lobby.revealStartedAt := null;
      lobby.revealExpiresAt := null;
      lobby.nextRevealAt := ?(now + waitPhaseNs + revealIntervalNs);
    } else {
      // Tie (or no single winner): re-run the round.
      lobby.rpsOutcome := #tie;
      lobby.rpsRound += 1;
      for (p in lobby.players.values()) {
        p.rpsChoice := null;
      };
    };
  };

  /// Whether `mine` beats `theirs` in rock-paper-scissors.
  func beats(mine : ?RpsChoice, theirs : ?RpsChoice) : Bool {
    switch (mine, theirs) {
      case (?#rock, ?#scissors) { true };
      case (?#scissors, ?#paper) { true };
      case (?#paper, ?#rock) { true };
      case _ { false };
    };
  };

  /// Build the current rock-paper-scissors state for display.
  public func toRpsState(lobby : Lobby) : RpsState {
    {
      round = lobby.rpsRound;
      outcome = lobby.rpsOutcome;
      players = lobby.players.map(func(p) = {
        playerId = p.id;
        hasChosen = p.rpsChoice != null;
        choice = p.rpsChoice;
      });
      seekerId = lobby.seekerId;
    };
  };

  /// Build the seeker's reveal-window state. Pure read: the window is opened by
  /// `tick`, so this is safe to call from a query.
  public func toRevealState(lobby : Lobby, now : Timestamp) : RevealState {
    let active = switch (lobby.revealExpiresAt) {
      case (?expiresAt) { now < expiresAt };
      case null { false };
    };

    let hiders = if (active) {
      lobby.players.filter(func(p) = p.role == #hider and not p.isDisqualified)
        .filterMap(func(p) = switch (p.lastPosition) {
          case (?point) { ?{ playerId = p.id; point } };
          case null { null };
        });
    } else {
      [];
    };

    {
      active;
      startedAt = lobby.revealStartedAt;
      expiresAt = lobby.revealExpiresAt;
      nextRevealAt = lobby.nextRevealAt;
      hiders;
    };
  };

  /// Positions visible to the given player, applying the game's visibility rules.
  func visiblePositions(lobby : Lobby, self : Player, now : Timestamp) : [PlayerPosition] {
    var out : [PlayerPosition] = [];
    let selfPoint = self.lastPosition;

    if (self.role == #seeker) {
      // Seeker sees all hider positions only during an active reveal window.
      let reveal = toRevealState(lobby, now);
      if (reveal.active) {
        for (p in lobby.players.values()) {
          if (p.role == #hider and not p.isDisqualified) {
            switch (p.lastPosition, p.lastPositionAt) {
              case (?point, ?updatedAt) {
                out := out.concat([{
                  playerId = p.id;
                  point;
                  distanceFromStart = distanceFromStart(lobby, point);
                  updatedAt;
                }]);
              };
              case _ {};
            };
          };
        };
      };
    } else {
      // Hiders see each other continuously.
      for (p in lobby.players.values()) {
        if (p.id != self.id and p.role == #hider and not p.isDisqualified) {
          switch (p.lastPosition, p.lastPositionAt) {
            case (?point, ?updatedAt) {
              out := out.concat([{
                playerId = p.id;
                point;
                distanceFromStart = distanceFromStart(lobby, point);
                updatedAt;
              }]);
            };
            case _ {};
          };
        };
      };
      // A hider sees the seeker only when within 20m.
      switch (selfPoint) {
        case (?sp) {
          for (p in lobby.players.values()) {
            if (p.role == #seeker) {
              switch (p.lastPosition, p.lastPositionAt) {
                case (?point, ?updatedAt) {
                  if (distanceBetween(sp, point) <= hiderSeekerVisibilityCm) {
                    out := out.concat([{
                      playerId = p.id;
                      point;
                      distanceFromStart = distanceFromStart(lobby, point);
                      updatedAt;
                    }]);
                  };
                };
                case _ {};
              };
            };
          };
        };
        case null {};
      };
    };
    out;
  };

  /// Attempt a catch: allowed only when the target hider is within 3m.
  public func catchHider(lobby : Lobby, seeker : Player, targetId : PlayerId, now : Timestamp) : Result.Result<(), GameError> {
    if (lobby.phase != #active) { return #err(#gameNotActive) };
    if (seeker.role != #seeker) { return #err(#notSeeker) };
    let target = switch (findPlayerById(lobby, targetId)) {
      case (?t) { t };
      case null { return #err(#notInLobby) };
    };
    if (target.role != #hider) { return #err(#targetNotHider) };
    if (target.isDisqualified) { return #err(#targetDisqualified) };
    let seekerPoint = switch (seeker.lastPosition) {
      case (?p) { p };
      case null { return #err(#noPosition) };
    };
    let targetPoint = switch (target.lastPosition) {
      case (?p) { p };
      case null { return #err(#noPosition) };
    };
    if (distanceBetween(seekerPoint, targetPoint) > catchRangeCm) {
      return #err(#hiderNotNearby);
    };
    target.isCaught := true;
    target.role := #seeker;
    // If no hiders remain, the original seeker wins.
    let hidersLeft = lobby.players.any(func(p) = p.role == #hider and not p.isDisqualified);
    if (not hidersLeft) {
      endGame(lobby, #allHidersCaught, now);
    };
    #ok(());
  };

  /// Determine winners and end the game.
  public func endGame(lobby : Lobby, reason : EndReason, now : Timestamp) : () {
    if (lobby.phase == #ended) { return };
    lobby.phase := #ended;
    lobby.endReason := ?reason;
    switch (reason) {
      case (#allHidersCaught) {
        // Original seeker wins.
        let original = lobby.players.find(func(p) = p.isOriginalSeeker);
        lobby.winnerIds := switch (original) {
          case (?p) { [p.id] };
          case null { [] };
        };
      };
      case (#timeExpired) {
        // Remaining hiders win.
        lobby.winnerIds := lobby.players.filter(
          func(p) = p.role == #hider and not p.isDisqualified
        ).map(func(p) = p.id);
      };
      case (#hostEnded) {
        lobby.winnerIds := [];
      };
    };
    ignore now;
  };

  /// Reset a lobby back to the lobby phase, clearing game state.
  public func resetLobby(lobby : Lobby) : () {
    lobby.phase := #lobby;
    lobby.startPoint := null;
    lobby.startedAt := null;
    lobby.waitEndsAt := null;
    lobby.endsAt := null;
    lobby.rpsRound := 0;
    lobby.rpsOutcome := #pending;
    lobby.seekerId := null;
    lobby.revealStartedAt := null;
    lobby.revealExpiresAt := null;
    lobby.nextRevealAt := null;
    lobby.endReason := null;
    lobby.winnerIds := [];
    for (p in lobby.players.values()) {
      p.role := #hider;
      p.isOriginalSeeker := false;
      p.isReady := false;
      p.isDisqualified := false;
      p.isCaught := false;
      p.lastPosition := null;
      p.lastPositionAt := null;
      p.rpsChoice := null;
    };
  };
};
