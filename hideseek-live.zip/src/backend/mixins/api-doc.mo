/// Static behavioral documentation for the public backend API.
///
/// The document is a compile-time literal: it reads no actor state, so it is
/// safe to serve from a query and never traps. It is returned directly from the
/// function body — never bound to a top-level `let`, which would be stable
/// state inside a mixin and trap at runtime.
mixin () {
  public query func getApiDoc() : async Text {
    "# Hide & Seek — Backend API\n\n" #
    "A mobile-first, real-world hide-and-seek game. Players create or join a lobby\n" #
    "with a short access code, pick a color, and play rock-paper-scissors to choose\n" #
    "the seeker. The game then runs in timed phases over a 500 m play zone, with\n" #
    "live positions reported by each device and polled back from the canister.\n\n" #
    "All game state lives in the canister. Timestamps are **server-derived**\n" #
    "(`Time.now()`); clients must never trust their own clock for phase transitions.\n\n" #
    "## Authentication and identity\n\n" #
    "Every method is callable by any principal, including anonymous ones — there is\n" #
    "no sign-in gate on the game itself. Identity is the caller's principal, and a\n" #
    "player is bound to the principal that created or joined the lobby. A caller\n" #
    "that never joined a lobby receives `#err(#notInLobby)` from every\n" #
    "lobby-scoped method.\n\n" #
    "The app's frontend pins an Internet Identity derivation origin, published at\n" #
    "`/.well-known/ii-derivation-origin` when available. An agent already holding\n" #
    "the user's Internet Identity authorization derives the correct per-app\n" #
    "principal against that origin (for example\n" #
    "`icp identity link web <name> --app <host>`). Such a delegation acts with the\n" #
    "user's full authority in this app until it expires.\n\n" #
    "A principal is only \"in a lobby\" if it joined through the app's own frontend.\n" #
    "A signed-in caller derived against a different origin is a *different*\n" #
    "principal than the one the frontend registered, so it will be treated as a\n" #
    "stranger and receive `#err(#notInLobby)`.\n\n" #
    "## Authorization\n\n" #
    "- **Lobby membership** is the only authorization boundary. Methods that act on\n" #
    "  a lobby resolve the caller's lobby by principal and return\n" #
    "  `#err(#notInLobby)` when the caller is not a member.\n" #
    "- **Host-only** methods (`startGame`, `resetGame`, `endLobby`) additionally\n" #
    "  require the caller to be the lobby's current host, otherwise\n" #
    "  `#err(#notHost)`. Host is transferred to the earliest remaining player when\n" #
    "  the host leaves during the lobby phase.\n" #
    "- **Seeker-only** behavior is enforced inside `catchHider`, which returns\n" #
    "  `#err(#notSeeker)` for non-seekers.\n" #
    "- **OQL tables** (`lobby`, `player`) are controller-only. They are readable by\n" #
    "  the platform's Data Intelligence agent and never by end users; the app reads\n" #
    "  game state through `getGameState` / `syncGameState` instead.\n\n" #
    "## Units and encodings\n\n" #
    "| Concept | Encoding |\n" #
    "| --- | --- |\n" #
    "| Timestamps | `Int` nanoseconds since the Unix epoch (`Time.now()`). |\n" #
    "| Latitude / longitude | `Int` **micro-degrees** (degrees × 1,000,000). |\n" #
    "| Distances | `Nat` **centimetres**. |\n" #
    "| Player color | `Text` hex string, exactly `#rrggbb` (e.g. `\"#ff8800\"`). |\n" #
    "| Access code | `Text`, 6 uppercase alphanumeric characters from an unambiguous alphabet (no `0/O`, `1/I`). |\n" #
    "| Lobby / player ids | `Nat`, stable and globally unique within the canister. |\n" #
    "| Optional values | Candid `opt`; absent means \"not yet reported\" or \"not applicable\". |\n\n" #
    "Distances are computed server-side with an equirectangular approximation, which\n" #
    "is accurate at the scales this game uses (metres to hundreds of metres).\n\n" #
    "## Lifecycle and phases\n\n" #
    "A lobby moves through `#lobby → #rps → #waiting → #active → #ended`.\n\n" #
    "1. **`#lobby`** — players join, pick colors, and mark ready. The host starts\n" #
    "   the game once 2–12 players have joined.\n" #
    "2. **`#rps`** — every player submits one rock/paper/scissors choice. When all\n" #
    "   active players have chosen, the round resolves. A single winner becomes the\n" #
    "   seeker and the game advances to `#waiting`; a tie clears all choices and\n" #
    "   re-runs the round (`rpsRound` increments).\n" #
    "3. **`#waiting`** — the 5-minute seeker wait. `waitEndsAt` is the server time\n" #
    "   the phase ends. The seeker's first reported position becomes the play-zone\n" #
    "   centre (`startPoint`).\n" #
    "4. **`#active`** — the 1-hour game. `endsAt` is the server time the game ends.\n" #
    "5. **`#ended`** — `endReason` is `#timeExpired`, `#allHidersCaught`, or\n" #
    "   `#hostEnded`, and `winnerIds` lists the winners.\n\n" #
    "Phase transitions are driven by the server clock and are applied lazily by\n" #
    "`tick`, which runs inside `updatePosition`, `catchHider`, and `syncGameState`.\n" #
    "A pure `query` cannot mutate state, so `getGameState` reports the phase as it\n" #
    "currently stands without advancing it. **Clients that need the phase to\n" #
    "advance must call `syncGameState` (an update) or `updatePosition`.**\n\n" #
    "## Polling\n\n" #
    "There is no push channel. Poll `getGameState` (fast, read-only) on an interval\n" #
    "for display, and call `syncGameState` periodically to let the canister advance\n" #
    "timers. A reasonable cadence is every 1–2 seconds while the game is active.\n" #
    "`serverNow` in the response is the authoritative clock; compute countdowns\n" #
    "against it rather than the device clock.\n\n" #
    "## Visibility rules\n\n" #
    "`getGameState` returns a **caller-specific** view. `visiblePositions` is\n" #
    "filtered per role:\n\n" #
    "- **Hiders** see every other non-disqualified hider continuously, plus the\n" #
    "  seeker only when the seeker is within **20 m** (2,000 cm) of them.\n" #
    "- **Seekers** see hider positions only during an active reveal window — a\n" #
    "  **10-second** window that opens every **3 minutes** while the game is active.\n" #
    "  Outside a window, `visiblePositions` is empty for the seeker.\n" #
    "- A player's own position is always returned in `selfPosition`.\n\n" #
    "`reveal.active` tells the seeker whether a window is currently open;\n" #
    "`reveal.expiresAt` and `reveal.nextRevealAt` are server timestamps.\n\n" #
    "## Mutation retry safety\n\n" #
    "- `createLobby` and `joinLobby` are **not idempotent**: each successful call\n" #
    "  allocates a new lobby or player. Retrying after a timeout can create a\n" #
    "  duplicate. A caller already in a joinable lobby cannot create or join\n" #
    "  another (`#err(#lobbyNotJoinable)`), which bounds the damage.\n" #
    "- `setReady`, `setColor`, `updatePosition`, and `chooseRps` are effectively\n" #
    "  idempotent for the same input; re-sending the same value is harmless.\n" #
    "  `chooseRps` returns `#err(#alreadyChosen)` on a second call in the same round.\n" #
    "- `catchHider` is **not** idempotent in effect: a successful catch converts the\n" #
    "  target to a seeker. A retry after a timeout returns `#err(#targetNotHider)`\n" #
    "  rather than double-converting.\n" #
    "- `resetGame` and `endLobby` are destructive and host-only. `endLobby` ends the\n" #
    "  game for everyone with `#hostEnded` and no winners; the ended state stays\n" #
    "  readable so the results screen can render, and every player can then call\n" #
    "  `leaveLobby` to return home. `resetGame` clears all game state and returns\n" #
    "  the lobby to `#lobby`, keeping the players and their colors.\n" #
    "- `leaveLobby` removes the caller. It is allowed in the `#lobby` and `#ended`\n" #
    "  phases; in any other phase it returns `#err(#wrongPhase)`. If the last player\n" #
    "  leaves, the lobby and its access code are deleted and the code becomes\n" #
    "  reusable.\n\n" #
    "## Errors\n\n" #
    "All fallible methods return `Result<_, GameError>`. `GameError` variants:\n\n" #
    "`#notFound`, `#notInLobby`, `#notHost`, `#lobbyFull`, `#lobbyNotJoinable`,\n" #
    "`#invalidCode`, `#colorTaken`, `#invalidColor`, `#invalidName`,\n" #
    "`#notEnoughPlayers`, `#tooManyPlayers`, `#wrongPhase`, `#alreadyChosen`,\n" #
    "`#notSeeker`, `#hiderNotNearby`, `#targetNotHider`, `#targetDisqualified`,\n" #
    "`#alreadyDisqualified`, `#noPosition`, `#gameNotActive`.\n\n" #
    "## Methods\n\n" #
    "### Lobby and identity\n\n" #
    "- `createLobby(name : Text, color : Text) : Result<CreateLobbyResult, GameError>`\n" #
    "  — creates a lobby, joins the caller as host, and returns\n" #
    "  `{ lobbyId; accessCode; playerId }`. Names are trimmed and must be 1–24\n" #
    "  characters; colors must be `#rrggbb`.\n" #
    "- `joinLobby(accessCode : Text, name : Text, color : Text) : Result<JoinLobbyResult, GameError>`\n" #
    "  — joins by code. Fails with `#invalidCode`, `#lobbyNotJoinable` (not in the\n" #
    "  lobby phase, or caller already in a lobby), `#lobbyFull` (12 players), or\n" #
    "  `#colorTaken`.\n" #
    "- `leaveLobby() : Result<(), GameError>` — leaves during the `#lobby` or\n" #
    "  `#ended` phase; `#err(#wrongPhase)` otherwise.\n" #
    "- `setReady(ready : Bool) : Result<(), GameError>` — lobby phase only.\n" #
    "- `setColor(color : Text) : Result<(), GameError>` — lobby phase only; fails\n" #
    "  with `#colorTaken` if another player holds the color.\n\n" #
    "### Seeker selection\n\n" #
    "- `startGame() : Result<(), GameError>` — host-only; requires 2–12 players;\n" #
    "  enters `#rps`.\n" #
    "- `chooseRps(choice : RpsChoice) : Result<(), GameError>` — `#rock`, `#paper`,\n" #
    "  or `#scissors`. Resolves automatically once all active players have chosen.\n\n" #
    "### Gameplay\n\n" #
    "- `updatePosition(lat : Int, lng : Int) : Result<(), GameError>` — reports the\n" #
    "  caller's position in micro-degrees. Advances timers. During `#waiting` and\n" #
    "  `#active`, a position more than 500 m from `startPoint` disqualifies the\n" #
    "  caller immediately (`isDisqualified`).\n" #
    "- `catchHider(targetId : Nat) : Result<(), GameError>` — seeker-only. Succeeds\n" #
    "  only when the target is a non-disqualified hider within **3 m** (300 cm);\n" #
    "  otherwise `#hiderNotNearby`, `#targetNotHider`, `#targetDisqualified`, or\n" #
    "  `#noPosition`. A caught hider becomes a seeker. If no hiders remain, the game\n" #
    "  ends with `#allHidersCaught` and the original seeker wins.\n\n" #
    "### Lifecycle\n\n" #
    "- `resetGame() : Result<(), GameError>` — host-only; returns the lobby to\n" #
    "  `#lobby` and clears all game state.\n" #
    "- `endLobby() : Result<(), GameError>` — host-only; ends the game for everyone\n" #
    "  with `#hostEnded` and no winners. The ended state remains readable for the\n" #
    "  results screen, and each player leaves with `leaveLobby`.\n\n" #
    "### Reads\n\n" #
    "- `getGameState() : Result<GameView, GameError>` — **query**; caller-specific\n" #
    "  view. Does not advance timers.\n" #
    "- `syncGameState() : Result<GameView, GameError>` — **update**; same view, but\n" #
    "  advances timers first. Use this to drive phase transitions.\n\n" #
    "### Data Intelligence\n\n" #
    "- `schema() : Text` — OQL schema document (controller-only tables).\n" #
    "- `execute(qJson : Text) : Result` — runs an OQL query against the `lobby` and\n" #
    "  `player` tables.\n\n" #
    "## Gotchas\n\n" #
    "- **Server time is authoritative.** `serverNow` is the only clock to trust for\n" #
    "  countdowns; device clocks drift.\n" #
    "- **`getGameState` never advances the game.** A client that only polls the\n" #
    "  query will never see `#waiting` become `#active`. Call `syncGameState` or\n" #
    "  `updatePosition`.\n" #
    "- **The play zone is centred on the seeker's first reported position**, not on\n" #
    "  a fixed point. Until the seeker reports a position, `startPoint` is `null`\n" #
    "  and no disqualification can occur.\n" #
    "- **Disqualification is permanent for the game.** `resetGame` clears it.\n" #
    "- **The reveal window is opened by `tick`**, so a seeker polling only\n" #
    "  `getGameState` may see `reveal.active` flip only after another player's\n" #
    "  update lands.\n" #
    "- **Colors are unique per lobby** and are released when a player leaves.\n" #
    "- **Access codes are convenience handles, not secrets.** Anyone with a code can\n" #
    "  join while the lobby is in the `#lobby` phase.\n" #
    "- **`winnerIds` is empty** when the host ends the game manually.\n";
  };
};
