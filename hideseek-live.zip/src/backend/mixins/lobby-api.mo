import Map "mo:core/Map";
import Result "mo:core/Result";
import Time "mo:core/Time";
import Common "../types/common";
import LobbyTypes "../types/lobby";
import LobbyLib "../lib/lobby";

mixin (
  lobbies : Map.Map<Common.LobbyId, LobbyTypes.Lobby>,
  codeIndex : Map.Map<Common.AccessCode, Common.LobbyId>,
  state : { var nextLobbyId : Nat; var nextPlayerId : Nat },
) {
  /// Find the lobby the caller currently belongs to. A live lobby always wins
  /// over an ended one, so a stale ended lobby can never shadow an active
  /// membership. An ended lobby is only returned when it is the caller's sole
  /// membership, which is what lets the results screen render.
  func callerLobby(caller : Principal) : ?LobbyTypes.Lobby {
    var ended : ?LobbyTypes.Lobby = null;
    for (lobby in lobbies.values()) {
      switch (LobbyLib.findPlayerByPrincipal(lobby, caller)) {
        case (?_) {
          if (lobby.phase != #ended) { return ?lobby };
          switch (ended) {
            case null { ended := ?lobby };
            case (?_) {};
          };
        };
        case null {};
      };
    };
    ended;
  };

  /// Remove a player from a lobby. Transfers host to the earliest remaining
  /// player, or drops the lobby and frees its access code when it becomes empty.
  /// Returns true when the lobby was dropped.
  func removePlayerFromLobby(lobby : LobbyTypes.Lobby, principal : Principal) : Bool {
    let remaining = lobby.players.filter(func(p) = p.principal != principal);
    if (remaining.size() == 0) {
      lobbies.remove(lobby.id);
      codeIndex.remove(lobby.accessCode);
      return true;
    };
    lobby.players := remaining;
    if (lobby.hostPrincipal == principal) {
      let updated = LobbyLib.transferHost(lobby, remaining[0].principal);
      lobbies.add(updated.id, updated);
    };
    false;
  };

  /// Create a new lobby and join it as host. Returns the lobby id and access code.
  public shared ({ caller }) func createLobby(name : Text, color : Common.ColorHex) : async Result.Result<LobbyTypes.CreateLobbyResult, Common.GameError> {
    if (not LobbyLib.isValidName(name)) { return #err(#invalidName) };
    if (not LobbyLib.isValidColor(color)) { return #err(#invalidColor) };

    // A caller may belong to at most one joinable lobby. Reject a second
    // membership outright; an ended lobby is stale, so drop the caller from it
    // before creating the new one.
    switch (callerLobby(caller)) {
      case (?existing) {
        if (existing.phase != #ended) { return #err(#lobbyNotJoinable) };
        ignore removePlayerFromLobby(existing, caller);
      };
      case null {};
    };

    let existingCodes = codeIndex.keys().toArray();
    let accessCode = LobbyLib.generateAccessCode(existingCodes);
    let lobbyId = state.nextLobbyId;
    let playerId = state.nextPlayerId;
    state.nextLobbyId += 1;
    state.nextPlayerId += 1;

    let host : LobbyTypes.Player = {
      id = playerId;
      principal = caller;
      name = name;
      color;
      var role = #hider;
      var isOriginalSeeker = false;
      var isReady = false;
      var isDisqualified = false;
      var isCaught = false;
      var lastPosition = null;
      var lastPositionAt = null;
      var rpsChoice = null;
    };

    let lobby : LobbyTypes.Lobby = {
      id = lobbyId;
      accessCode;
      hostPrincipal = caller;
      var phase = #lobby;
      var players = [host];
      var startPoint = null;
      var startedAt = null;
      var waitEndsAt = null;
      var endsAt = null;
      var rpsRound = 0;
      var rpsOutcome = #pending;
      var seekerId = null;
      var revealStartedAt = null;
      var revealExpiresAt = null;
      var nextRevealAt = null;
      var endReason = null;
      var winnerIds = [];
    };

    lobbies.add(lobbyId, lobby);
    codeIndex.add(accessCode, lobbyId);
    #ok({ lobbyId; accessCode; playerId });
  };

  /// Join an existing lobby by its 6-character access code.
  public shared ({ caller }) func joinLobby(accessCode : Common.AccessCode, name : Text, color : Common.ColorHex) : async Result.Result<LobbyTypes.JoinLobbyResult, Common.GameError> {
    if (not LobbyLib.isValidName(name)) { return #err(#invalidName) };
    if (not LobbyLib.isValidColor(color)) { return #err(#invalidColor) };

    let lobbyId = switch (codeIndex.get(accessCode)) {
      case (?id) { id };
      case null { return #err(#invalidCode) };
    };
    let lobby = switch (lobbies.get(lobbyId)) {
      case (?l) { l };
      case null { return #err(#notFound) };
    };
    if (lobby.phase != #lobby) { return #err(#lobbyNotJoinable) };
    switch (LobbyLib.findPlayerByPrincipal(lobby, caller)) {
      case (?_) { return #err(#lobbyNotJoinable) };
      case null {};
    };
    if (lobby.players.size() >= LobbyLib.maxPlayers) { return #err(#lobbyFull) };
    if (LobbyLib.isColorTaken(lobby, color)) { return #err(#colorTaken) };

    let playerId = state.nextPlayerId;
    state.nextPlayerId += 1;
    let player : LobbyTypes.Player = {
      id = playerId;
      principal = caller;
      name = name;
      color;
      var role = #hider;
      var isOriginalSeeker = false;
      var isReady = false;
      var isDisqualified = false;
      var isCaught = false;
      var lastPosition = null;
      var lastPositionAt = null;
      var rpsChoice = null;
    };
    lobby.players := lobby.players.concat([player]);
    #ok({ lobbyId; playerId });
  };

  /// Leave the current lobby. Allowed while the lobby is open and after the host
  /// has ended it, so every player has a working exit back home.
  public shared ({ caller }) func leaveLobby() : async Result.Result<(), Common.GameError> {
    let lobby = switch (callerLobby(caller)) {
      case (?l) { l };
      case null { return #err(#notInLobby) };
    };
    if (lobby.phase != #lobby and lobby.phase != #ended) { return #err(#wrongPhase) };
    ignore removePlayerFromLobby(lobby, caller);
    #ok(());
  };

  /// Mark the caller ready or not ready in the lobby.
  public shared ({ caller }) func setReady(ready : Bool) : async Result.Result<(), Common.GameError> {
    let lobby = switch (callerLobby(caller)) {
      case (?l) { l };
      case null { return #err(#notInLobby) };
    };
    if (lobby.phase != #lobby) { return #err(#wrongPhase) };
    let player = switch (LobbyLib.findPlayerByPrincipal(lobby, caller)) {
      case (?p) { p };
      case null { return #err(#notInLobby) };
    };
    player.isReady := ready;
    #ok(());
  };

  /// Change the caller's chosen color, if still available.
  public shared ({ caller }) func setColor(color : Common.ColorHex) : async Result.Result<(), Common.GameError> {
    if (not LobbyLib.isValidColor(color)) { return #err(#invalidColor) };
    let lobby = switch (callerLobby(caller)) {
      case (?l) { l };
      case null { return #err(#notInLobby) };
    };
    if (lobby.phase != #lobby) { return #err(#wrongPhase) };
    let player = switch (LobbyLib.findPlayerByPrincipal(lobby, caller)) {
      case (?p) { p };
      case null { return #err(#notInLobby) };
    };
    if (player.color == color) { return #ok(()) };
    if (LobbyLib.isColorTaken(lobby, color)) { return #err(#colorTaken) };
    LobbyLib.setPlayerColor(lobby, player.id, color);
    #ok(());
  };

  /// Host-only: start the game (requires 2-12 players), entering the RPS phase.
  public shared ({ caller }) func startGame() : async Result.Result<(), Common.GameError> {
    let lobby = switch (callerLobby(caller)) {
      case (?l) { l };
      case null { return #err(#notInLobby) };
    };
    if (lobby.hostPrincipal != caller) { return #err(#notHost) };
    if (lobby.phase != #lobby) { return #err(#wrongPhase) };
    let count = lobby.players.size();
    if (count < LobbyLib.minPlayers) { return #err(#notEnoughPlayers) };
    if (count > LobbyLib.maxPlayers) { return #err(#tooManyPlayers) };

    lobby.phase := #rps;
    lobby.rpsRound := 0;
    lobby.rpsOutcome := #pending;
    lobby.seekerId := null;
    for (p in lobby.players.values()) {
      p.rpsChoice := null;
      p.role := #hider;
      p.isOriginalSeeker := false;
      p.isCaught := false;
      p.isDisqualified := false;
    };
    #ok(());
  };

  /// Submit the caller's rock-paper-scissors choice for the current round.
  public shared ({ caller }) func chooseRps(choice : Common.RpsChoice) : async Result.Result<(), Common.GameError> {
    let lobby = switch (callerLobby(caller)) {
      case (?l) { l };
      case null { return #err(#notInLobby) };
    };
    if (lobby.phase != #rps) { return #err(#wrongPhase) };
    let player = switch (LobbyLib.findPlayerByPrincipal(lobby, caller)) {
      case (?p) { p };
      case null { return #err(#notInLobby) };
    };
    if (player.rpsChoice != null) { return #err(#alreadyChosen) };
    player.rpsChoice := ?choice;
    LobbyLib.resolveRps(lobby);
    #ok(());
  };

  /// Report the caller's current position (latitude/longitude).
  public shared ({ caller }) func updatePosition(lat : Common.MicroDegrees, lng : Common.MicroDegrees) : async Result.Result<(), Common.GameError> {
    let lobby = switch (callerLobby(caller)) {
      case (?l) { l };
      case null { return #err(#notInLobby) };
    };
    let player = switch (LobbyLib.findPlayerByPrincipal(lobby, caller)) {
      case (?p) { p };
      case null { return #err(#notInLobby) };
    };
    let now = Time.now();
    LobbyLib.tick(lobby, now);
    LobbyLib.updatePosition(lobby, player, { lat; lng }, now);
    #ok(());
  };

  /// Seeker-only: catch a hider within 3m, converting them to a seeker.
  public shared ({ caller }) func catchHider(targetId : Common.PlayerId) : async Result.Result<(), Common.GameError> {
    let lobby = switch (callerLobby(caller)) {
      case (?l) { l };
      case null { return #err(#notInLobby) };
    };
    let seeker = switch (LobbyLib.findPlayerByPrincipal(lobby, caller)) {
      case (?p) { p };
      case null { return #err(#notInLobby) };
    };
    let now = Time.now();
    LobbyLib.tick(lobby, now);
    LobbyLib.catchHider(lobby, seeker, targetId, now);
  };

  /// Host-only: reset the game back to the lobby phase.
  public shared ({ caller }) func resetGame() : async Result.Result<(), Common.GameError> {
    let lobby = switch (callerLobby(caller)) {
      case (?l) { l };
      case null { return #err(#notInLobby) };
    };
    if (lobby.hostPrincipal != caller) { return #err(#notHost) };
    LobbyLib.resetLobby(lobby);
    #ok(());
  };

  /// Host-only: end the lobby and return everyone to home.
  public shared ({ caller }) func endLobby() : async Result.Result<(), Common.GameError> {
    let lobby = switch (callerLobby(caller)) {
      case (?l) { l };
      case null { return #err(#notInLobby) };
    };
    if (lobby.hostPrincipal != caller) { return #err(#notHost) };
    LobbyLib.endGame(lobby, #hostEnded, Time.now());
    #ok(());
  };

  /// Read the caller's current lobby and game state.
  public query ({ caller }) func getGameState() : async Result.Result<Common.GameView, Common.GameError> {
    let lobby = switch (callerLobby(caller)) {
      case (?l) { l };
      case null { return #err(#notInLobby) };
    };
    #ok(LobbyLib.toGameView(lobby, caller, Time.now()));
  };

  /// Read the caller's current lobby and game state (update variant, advances timers).
  public shared ({ caller }) func syncGameState() : async Result.Result<Common.GameView, Common.GameError> {
    let lobby = switch (callerLobby(caller)) {
      case (?l) { l };
      case null { return #err(#notInLobby) };
    };
    let now = Time.now();
    LobbyLib.tick(lobby, now);
    #ok(LobbyLib.toGameView(lobby, caller, now));
  };
};
