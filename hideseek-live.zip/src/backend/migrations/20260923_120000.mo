import Map "mo:core/Map";
import Nat "mo:core/Nat";
import AccessControl "mo:caffeineai-authorization/access-control";

module {
  type LobbyId = Nat;
  type AccessCode = Text;

  type Player = {
    id : Nat;
    principal : Principal;
    name : Text;
    color : Text;
    var role : { #seeker; #hider };
    var isOriginalSeeker : Bool;
    var isReady : Bool;
    var isDisqualified : Bool;
    var isCaught : Bool;
    var lastPosition : ?{ lat : Int; lng : Int };
    var lastPositionAt : ?Int;
    var rpsChoice : ?{ #rock; #paper; #scissors };
  };

  type Lobby = {
    id : LobbyId;
    accessCode : AccessCode;
    hostPrincipal : Principal;
    var phase : { #lobby; #rps; #waiting; #active; #ended };
    var players : [Player];
    var startPoint : ?{ lat : Int; lng : Int };
    var startedAt : ?Int;
    var waitEndsAt : ?Int;
    var endsAt : ?Int;
    var rpsRound : Nat;
    var rpsOutcome : { #pending; #tie; #resolved };
    var seekerId : ?Nat;
    var revealStartedAt : ?Int;
    var revealExpiresAt : ?Int;
    var nextRevealAt : ?Int;
    var endReason : ?{ #timeExpired; #allHidersCaught; #hostEnded };
    var winnerIds : [Nat];
  };

  type NewActor = {
    accessControlState : AccessControl.AccessControlState;
    lobbies : Map.Map<LobbyId, Lobby>;
    codeIndex : Map.Map<AccessCode, LobbyId>;
    state : { var nextLobbyId : Nat; var nextPlayerId : Nat };
  };

  public func migration(_old : {}) : NewActor {
    {
      accessControlState = AccessControl.initState();
      lobbies = Map.empty();
      codeIndex = Map.empty();
      state = { var nextLobbyId = 0; var nextPlayerId = 0 };
    };
  };
};
