module {
  /// Server-derived timestamp in nanoseconds (Time.now()).
  public type Timestamp = Int;

  /// Latitude/longitude in micro-degrees (degrees * 1_000_000) to avoid floats.
  public type MicroDegrees = Int;

  /// Distance in centimetres.
  public type Centimetres = Nat;

  /// A player's chosen display color as a hex string (e.g. "#ff8800").
  public type ColorHex = Text;

  /// A 6-character uppercase alphanumeric lobby access code.
  public type AccessCode = Text;

  /// A stable numeric identifier for a lobby.
  public type LobbyId = Nat;

  /// A stable numeric identifier for a player within a lobby.
  public type PlayerId = Nat;

  /// A geographic point.
  public type GeoPoint = {
    lat : MicroDegrees;
    lng : MicroDegrees;
  };

  /// A player's role in the game.
  public type Role = {
    #seeker;
    #hider;
  };

  /// Lifecycle phase of a lobby.
  public type LobbyPhase = {
    #lobby;
    #rps;
    #waiting;
    #active;
    #ended;
  };

  /// A player's rock-paper-scissors choice.
  public type RpsChoice = {
    #rock;
    #paper;
    #scissors;
  };

  /// Outcome of a rock-paper-scissors round.
  public type RpsOutcome = {
    #pending;
    #tie;
    #resolved;
  };

  /// Why a game ended.
  public type EndReason = {
    #timeExpired;
    #allHidersCaught;
    #hostEnded;
  };

  /// A player's public profile within a lobby.
  public type PlayerView = {
    id : PlayerId;
    name : Text;
    color : ColorHex;
    role : Role;
    isOriginalSeeker : Bool;
    isReady : Bool;
    isDisqualified : Bool;
    isCaught : Bool;
    isHost : Bool;
  };

  /// A player's last reported position.
  public type PlayerPosition = {
    playerId : PlayerId;
    point : GeoPoint;
    distanceFromStart : Centimetres;
    updatedAt : Timestamp;
  };

  /// A player's rock-paper-scissors state.
  public type RpsPlayerState = {
    playerId : PlayerId;
    hasChosen : Bool;
    choice : ?RpsChoice;
  };

  /// The current rock-paper-scissors round state.
  public type RpsState = {
    round : Nat;
    outcome : RpsOutcome;
    players : [RpsPlayerState];
    seekerId : ?PlayerId;
  };

  /// A single hider position revealed to the seeker during a reveal window.
  public type RevealedHider = {
    playerId : PlayerId;
    point : GeoPoint;
  };

  /// The seeker's timed reveal window state.
  public type RevealState = {
    active : Bool;
    startedAt : ?Timestamp;
    expiresAt : ?Timestamp;
    nextRevealAt : ?Timestamp;
    hiders : [RevealedHider];
  };

  /// The full game state as seen by a specific caller.
  public type GameView = {
    lobbyId : LobbyId;
    accessCode : AccessCode;
    phase : LobbyPhase;
    hostId : PlayerId;
    startPoint : ?GeoPoint;
    startedAt : ?Timestamp;
    waitEndsAt : ?Timestamp;
    endsAt : ?Timestamp;
    serverNow : Timestamp;
    players : [PlayerView];
    selfId : PlayerId;
    selfPosition : ?PlayerPosition;
    visiblePositions : [PlayerPosition];
    rps : ?RpsState;
    reveal : ?RevealState;
    endReason : ?EndReason;
    winnerIds : [PlayerId];
  };

  /// Errors returned by lobby and game operations.
  public type GameError = {
    #notFound;
    #notInLobby;
    #notHost;
    #lobbyFull;
    #lobbyNotJoinable;
    #invalidCode;
    #colorTaken;
    #invalidColor;
    #invalidName;
    #notEnoughPlayers;
    #tooManyPlayers;
    #wrongPhase;
    #alreadyChosen;
    #notSeeker;
    #hiderNotNearby;
    #targetNotHider;
    #targetDisqualified;
    #alreadyDisqualified;
    #noPosition;
    #gameNotActive;
  };
};
