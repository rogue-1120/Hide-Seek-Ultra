import Common "common";

module {
  public type Timestamp = Common.Timestamp;
  public type MicroDegrees = Common.MicroDegrees;
  public type Centimetres = Common.Centimetres;
  public type ColorHex = Common.ColorHex;
  public type AccessCode = Common.AccessCode;
  public type LobbyId = Common.LobbyId;
  public type PlayerId = Common.PlayerId;
  public type GeoPoint = Common.GeoPoint;
  public type Role = Common.Role;
  public type LobbyPhase = Common.LobbyPhase;
  public type RpsChoice = Common.RpsChoice;
  public type RpsOutcome = Common.RpsOutcome;
  public type EndReason = Common.EndReason;
  public type PlayerView = Common.PlayerView;
  public type PlayerPosition = Common.PlayerPosition;
  public type RpsPlayerState = Common.RpsPlayerState;
  public type RpsState = Common.RpsState;
  public type RevealedHider = Common.RevealedHider;
  public type RevealState = Common.RevealState;
  public type GameView = Common.GameView;
  public type GameError = Common.GameError;

  /// Internal player record stored in a lobby.
  public type Player = {
    id : PlayerId;
    principal : Principal;
    name : Text;
    color : ColorHex;
    var role : Role;
    var isOriginalSeeker : Bool;
    var isReady : Bool;
    var isDisqualified : Bool;
    var isCaught : Bool;
    var lastPosition : ?GeoPoint;
    var lastPositionAt : ?Timestamp;
    var rpsChoice : ?RpsChoice;
  };

  /// Internal lobby record.
  public type Lobby = {
    id : LobbyId;
    accessCode : AccessCode;
    hostPrincipal : Principal;
    var phase : LobbyPhase;
    var players : [Player];
    var startPoint : ?GeoPoint;
    var startedAt : ?Timestamp;
    var waitEndsAt : ?Timestamp;
    var endsAt : ?Timestamp;
    var rpsRound : Nat;
    var rpsOutcome : RpsOutcome;
    var seekerId : ?PlayerId;
    var revealStartedAt : ?Timestamp;
    var revealExpiresAt : ?Timestamp;
    var nextRevealAt : ?Timestamp;
    var endReason : ?EndReason;
    var winnerIds : [PlayerId];
  };

  /// Result of creating a lobby.
  public type CreateLobbyResult = {
    lobbyId : LobbyId;
    accessCode : AccessCode;
    playerId : PlayerId;
  };

  /// Result of joining a lobby.
  public type JoinLobbyResult = {
    lobbyId : LobbyId;
    playerId : PlayerId;
  };
};
