import Bool "mo:core/Bool";
import Int "mo:core/Int";
import Iter "mo:core/Iter";
import List "mo:core/List";
import Map "mo:core/Map";
import Nat "mo:core/Nat";
import Principal "mo:core/Principal";
import Text "mo:core/Text";
import AccessControl "mo:caffeineai-authorization/access-control";
import MixinAuthorization "mo:caffeineai-authorization/MixinAuthorization";
import OQL "mo:caffeineai-oql";
import Expose "mo:caffeineai-oql/Expose";
// Resolver modules, imported top-level: the builder chain (`.sample` / `.build` /
// `.controllerOnly`) resolves through `Entity`, and the structural `_toRow`
// derivation for the flat row records resolves through `RecordValue` plus one
// `<Type>Value` per primitive field type present.
import Entity "mo:caffeineai-oql/Entity";
import RecordValue "mo:caffeineai-oql/RecordValue";
import NatValue "mo:caffeineai-oql/NatValue";
import IntValue "mo:caffeineai-oql/IntValue";
import TextValue "mo:caffeineai-oql/TextValue";
import BoolValue "mo:caffeineai-oql/BoolValue";
import PrincipalValue "mo:caffeineai-oql/PrincipalValue";
import Common "types/common";
import LobbyTypes "types/lobby";
import LobbyApi "mixins/lobby-api";
import ApiDocMixin "mixins/api-doc";

actor {
  let accessControlState : AccessControl.AccessControlState;
  include MixinAuthorization(accessControlState, null);

  let lobbies : Map.Map<Common.LobbyId, LobbyTypes.Lobby>;
  let codeIndex : Map.Map<Common.AccessCode, Common.LobbyId>;
  let state : { var nextLobbyId : Nat; var nextPlayerId : Nat };

  include LobbyApi(lobbies, codeIndex, state);

  // ---------------------------------------------------------------------------
  // OQL projections
  //
  // The persisted state is `lobbies` (each holding an array of players) and
  // `codeIndex`. Both are projected into flat, all-primitive row records so the
  // compiler can auto-derive their schema. Rows are recomputed per query, so
  // the entities always reflect live state.
  // ---------------------------------------------------------------------------

  /// Flat, queryable projection of a lobby.
  type LobbyRow = {
    id : Nat;
    accessCode : Text;
    hostPrincipal : Principal;
    phase : Text;
    playerCount : Nat;
    startLat : Int;
    startLng : Int;
    startedAt : Int;
    waitEndsAt : Int;
    endsAt : Int;
    rpsRound : Nat;
    rpsOutcome : Text;
    seekerId : Nat;
    endReason : Text;
    winnerIds : Text;
  };

  /// Flat, queryable projection of a player, carrying its lobby id as a foreign key.
  type PlayerRow = {
    id : Nat;
    lobbyId : Nat;
    name : Text;
    color : Text;
    role : Text;
    isOriginalSeeker : Bool;
    isReady : Bool;
    isDisqualified : Bool;
    isCaught : Bool;
    lastLat : Int;
    lastLng : Int;
    lastPositionAt : Int;
    rpsChoice : Text;
  };

  func phaseText(phase : Common.LobbyPhase) : Text = switch phase {
    case (#lobby) "lobby";
    case (#rps) "rps";
    case (#waiting) "waiting";
    case (#active) "active";
    case (#ended) "ended";
  };

  func roleText(role : Common.Role) : Text = switch role {
    case (#seeker) "seeker";
    case (#hider) "hider";
  };

  func rpsOutcomeText(outcome : Common.RpsOutcome) : Text = switch outcome {
    case (#pending) "pending";
    case (#tie) "tie";
    case (#resolved) "resolved";
  };

  func endReasonText(reason : ?Common.EndReason) : Text = switch reason {
    case (?#timeExpired) "timeExpired";
    case (?#allHidersCaught) "allHidersCaught";
    case (?#hostEnded) "hostEnded";
    case null "";
  };

  func rpsChoiceText(choice : ?Common.RpsChoice) : Text = switch choice {
    case (?#rock) "rock";
    case (?#paper) "paper";
    case (?#scissors) "scissors";
    case null "";
  };

  func optInt(value : ?Int) : Int = switch value {
    case (?v) v;
    case null 0;
  };

  func optNat(value : ?Nat) : Nat = switch value {
    case (?v) v;
    case null 0;
  };

  func optLat(point : ?Common.GeoPoint) : Int = switch point {
    case (?p) p.lat;
    case null 0;
  };

  func optLng(point : ?Common.GeoPoint) : Int = switch point {
    case (?p) p.lng;
    case null 0;
  };

  func toLobbyRow(lobby : LobbyTypes.Lobby) : LobbyRow = {
    id = lobby.id;
    accessCode = lobby.accessCode;
    hostPrincipal = lobby.hostPrincipal;
    phase = phaseText(lobby.phase);
    playerCount = lobby.players.size();
    startLat = optLat(lobby.startPoint);
    startLng = optLng(lobby.startPoint);
    startedAt = optInt(lobby.startedAt);
    waitEndsAt = optInt(lobby.waitEndsAt);
    endsAt = optInt(lobby.endsAt);
    rpsRound = lobby.rpsRound;
    rpsOutcome = rpsOutcomeText(lobby.rpsOutcome);
    seekerId = optNat(lobby.seekerId);
    endReason = endReasonText(lobby.endReason);
    winnerIds = lobby.winnerIds.values().map(func(id) = id.toText()).join(",");
  };

  func toPlayerRow(lobby : LobbyTypes.Lobby, player : LobbyTypes.Player) : PlayerRow = {
    id = player.id;
    lobbyId = lobby.id;
    name = player.name;
    color = player.color;
    role = roleText(player.role);
    isOriginalSeeker = player.isOriginalSeeker;
    isReady = player.isReady;
    isDisqualified = player.isDisqualified;
    isCaught = player.isCaught;
    lastLat = optLat(player.lastPosition);
    lastLng = optLng(player.lastPosition);
    lastPositionAt = optInt(player.lastPositionAt);
    rpsChoice = rpsChoiceText(player.rpsChoice);
  };

  func lobbyRows() : Iter.Iter<LobbyRow> {
    lobbies.values().map(toLobbyRow);
  };

  func playerRows() : Iter.Iter<PlayerRow> {
    let rows = List.empty<PlayerRow>();
    for (lobby in lobbies.values()) {
      for (player in lobby.players.values()) {
        rows.add(toPlayerRow(lobby, player));
      };
    };
    rows.values();
  };

  include Expose({
    entities = [
      // Lobby and player rows carry live player locations and access codes, so
      // both tables stay controller-only: the Data Intelligence agent reads
      // them, end users never do (they use getGameState instead).
      OQL.Entity.new<LobbyRow>("lobby", lobbyRows, "Lobby", "id")
        .sample({
          id = 0;
          accessCode = "";
          hostPrincipal = Principal.fromText("aaaaa-aa");
          phase = "";
          playerCount = 0;
          startLat = 0;
          startLng = 0;
          startedAt = 0;
          waitEndsAt = 0;
          endsAt = 0;
          rpsRound = 0;
          rpsOutcome = "";
          seekerId = 0;
          endReason = "";
          winnerIds = "";
        })
        .controllerOnly()
        .build(),
      OQL.Entity.new<PlayerRow>("player", playerRows, "Player", "id")
        .sample({
          id = 0;
          lobbyId = 0;
          name = "";
          color = "";
          role = "";
          isOriginalSeeker = false;
          isReady = false;
          isDisqualified = false;
          isCaught = false;
          lastLat = 0;
          lastLng = 0;
          lastPositionAt = 0;
          rpsChoice = "";
        })
        .edge("lobbyId", "lobby")
        .controllerOnly()
        .build(),
    ];
  });

  include ApiDocMixin();
};
