import { describe, expect, it } from "vitest";

import {
  bearingDegrees,
  bearingLabel,
  clamp,
  cmToMetres,
  degreesToMicro,
  formatCountdown,
  formatDistance,
  haversineMetres,
  metresPerPixel,
  metresToCm,
  microToDegrees,
  pointToLatLng,
} from "@/lib/geo";
import { PLAYER_COLORS, colorSlot } from "@/types/game";

/**
 * Pure helpers that the gameplay HUD, the play-zone boundary, and the catch
 * range all depend on. These are the numeric seams behind the accepted rules
 * (500m zone, 3m catch, 20m visibility, 3ft stay-put), so a regression here
 * silently changes the game even when every component still renders.
 */
describe("geo helpers", () => {
  it("round-trips micro-degrees and decimal degrees", () => {
    expect(microToDegrees(51_507_400n)).toBeCloseTo(51.5074, 6);
    expect(degreesToMicro(51.5074)).toBe(51_507_400n);
    expect(pointToLatLng({ lat: 51_507_400n, lng: -127_400n })).toEqual({
      lat: 51.5074,
      lng: -0.1274,
    });
  });

  it("round-trips centimetres and metres", () => {
    expect(cmToMetres(50_000n)).toBe(500);
    expect(metresToCm(500)).toBe(50_000n);
    expect(metresToCm(0.9144)).toBe(91n);
  });

  it("measures a known great-circle distance", () => {
    // One degree of latitude is ~111.2km.
    const d = haversineMetres({ lat: 0, lng: 0 }, { lat: 1, lng: 0 });
    expect(d).toBeGreaterThan(110_000);
    expect(d).toBeLessThan(112_000);
    expect(haversineMetres({ lat: 5, lng: 5 }, { lat: 5, lng: 5 })).toBe(0);
  });

  it("computes bearings and compass labels", () => {
    const north = bearingDegrees({ lat: 0, lng: 0 }, { lat: 1, lng: 0 });
    expect(north).toBeCloseTo(0, 3);
    expect(bearingLabel(north)).toBe("N");
    const east = bearingDegrees({ lat: 0, lng: 0 }, { lat: 0, lng: 1 });
    expect(east).toBeCloseTo(90, 3);
    expect(bearingLabel(east)).toBe("E");
  });

  it("formats distances and countdowns for the HUD", () => {
    expect(formatDistance(312)).toBe("312m");
    expect(formatDistance(1400)).toBe("1.4km");
    expect(formatDistance(Number.NaN)).toBe("—");
    expect(formatCountdown(0)).toBe("00:00");
    expect(formatCountdown(65_000)).toBe("01:05");
    expect(formatCountdown(-5_000)).toBe("00:00");
  });

  it("scales metres-per-pixel with latitude and zoom", () => {
    const atEquator = metresPerPixel(0, 0);
    const atZoom1 = metresPerPixel(0, 1);
    expect(atZoom1).toBeCloseTo(atEquator / 2, 6);
    expect(metresPerPixel(60, 0)).toBeLessThan(atEquator);
  });

  it("clamps into an inclusive range", () => {
    expect(clamp(5, 0, 10)).toBe(5);
    expect(clamp(-1, 0, 10)).toBe(0);
    expect(clamp(11, 0, 10)).toBe(10);
  });
});

describe("player colors", () => {
  it("exposes six distinct identity colors", () => {
    expect(PLAYER_COLORS).toHaveLength(6);
    const hexes = PLAYER_COLORS.map((c) => c.hex.toLowerCase());
    expect(new Set(hexes).size).toBe(6);
    expect(PLAYER_COLORS.map((c) => c.slot)).toEqual([1, 2, 3, 4, 5, 6]);
  });

  it("resolves a hex to its slot, case-insensitively", () => {
    expect(colorSlot("#3FD67F")).toBe(1);
    expect(colorSlot("#5aa9ff")).toBe(2);
    expect(colorSlot("#000000")).toBeNull();
  });
});
