import { createActor } from "@/backend";
import type {
  AccessCode,
  ColorHex,
  GameError,
  GameView,
  MicroDegrees,
  PlayerId,
  RpsChoice,
} from "@/types/game";

export { createActor };

/** Result of a lobby-creating call. */
export interface CreateLobbyOutcome {
  lobbyId: bigint;
  accessCode: AccessCode;
  playerId: PlayerId;
}

/** Result of a lobby-joining call. */
export interface JoinLobbyOutcome {
  lobbyId: bigint;
  playerId: PlayerId;
}

/** A backend call that returns either a payload or a `GameError`. */
export type GameResult<T> =
  | { ok: true; value: T }
  | { ok: false; error: GameError };

/** Narrow the generated `Result_*` union into a discriminated `GameResult`. */
function unwrap<T>(result: { __kind__: "ok"; ok: T } | { __kind__: "err"; err: GameError }): GameResult<T> {
  if (result.__kind__ === "ok") {
    return { ok: true, value: result.ok };
  }
  return { ok: false, error: result.err };
}

/** Human-readable copy for every backend `GameError` variant. */
export const GAME_ERROR_MESSAGES: Record<GameError, string> = {
  notFound: "That lobby no longer exists.",
  notInLobby: "You are not in a lobby right now.",
  notHost: "Only the host can do that.",
  lobbyFull: "This lobby is full (12 players max).",
  lobbyNotJoinable: "This lobby has already started.",
  invalidCode: "That access code is not valid.",
  colorTaken: "That color was just taken — pick another.",
  invalidColor: "That color is not available.",
  invalidName: "Enter a callsign between 1 and 24 characters.",
  notEnoughPlayers: "You need at least 2 players to start.",
  tooManyPlayers: "Too many players — 12 is the maximum.",
  wrongPhase: "That action is not available right now.",
  alreadyChosen: "You already locked in a choice this round.",
  notSeeker: "Only the seeker can catch hiders.",
  hiderNotNearby: "No hider is within catching range.",
  targetNotHider: "That player is not a hider.",
  targetDisqualified: "That player is already out of the zone.",
  alreadyDisqualified: "You have stepped outside the play zone.",
  noPosition: "Waiting for a GPS fix…",
  gameNotActive: "The game is not running.",
};

/** Resolve a `GameError` to display copy. */
export function gameErrorMessage(error: GameError): string {
  return GAME_ERROR_MESSAGES[error] ?? "Something went wrong.";
}

/** The subset of the generated actor this app calls. */
export interface GameActor {
  createLobby(name: string, color: ColorHex): Promise<unknown>;
  joinLobby(
    accessCode: AccessCode,
    name: string,
    color: ColorHex,
  ): Promise<unknown>;
  leaveLobby(): Promise<unknown>;
  setReady(ready: boolean): Promise<unknown>;
  setColor(color: ColorHex): Promise<unknown>;
  startGame(): Promise<unknown>;
  chooseRps(choice: RpsChoice): Promise<unknown>;
  updatePosition(lat: MicroDegrees, lng: MicroDegrees): Promise<unknown>;
  catchHider(targetId: PlayerId): Promise<unknown>;
  resetGame(): Promise<unknown>;
  endLobby(): Promise<unknown>;
  getGameState(): Promise<unknown>;
  syncGameState(): Promise<unknown>;
}

type RawResult<T> =
  | { __kind__: "ok"; ok: T }
  | { __kind__: "err"; err: GameError };

/** Typed wrappers around the generated bindings. */
export const gameApi = {
  async createLobby(
    actor: GameActor,
    name: string,
    color: ColorHex,
  ): Promise<GameResult<CreateLobbyOutcome>> {
    const raw = (await actor.createLobby(name, color)) as RawResult<CreateLobbyOutcome>;
    return unwrap(raw);
  },

  async joinLobby(
    actor: GameActor,
    accessCode: AccessCode,
    name: string,
    color: ColorHex,
  ): Promise<GameResult<JoinLobbyOutcome>> {
    const raw = (await actor.joinLobby(accessCode, name, color)) as RawResult<JoinLobbyOutcome>;
    return unwrap(raw);
  },

  async leaveLobby(actor: GameActor): Promise<GameResult<null>> {
    return unwrap((await actor.leaveLobby()) as RawResult<null>);
  },

  async setReady(actor: GameActor, ready: boolean): Promise<GameResult<null>> {
    return unwrap((await actor.setReady(ready)) as RawResult<null>);
  },

  async setColor(actor: GameActor, color: ColorHex): Promise<GameResult<null>> {
    return unwrap((await actor.setColor(color)) as RawResult<null>);
  },

  async startGame(actor: GameActor): Promise<GameResult<null>> {
    return unwrap((await actor.startGame()) as RawResult<null>);
  },

  async chooseRps(
    actor: GameActor,
    choice: RpsChoice,
  ): Promise<GameResult<null>> {
    return unwrap((await actor.chooseRps(choice)) as RawResult<null>);
  },

  async updatePosition(
    actor: GameActor,
    lat: MicroDegrees,
    lng: MicroDegrees,
  ): Promise<GameResult<null>> {
    return unwrap((await actor.updatePosition(lat, lng)) as RawResult<null>);
  },

  async catchHider(
    actor: GameActor,
    targetId: PlayerId,
  ): Promise<GameResult<null>> {
    return unwrap((await actor.catchHider(targetId)) as RawResult<null>);
  },

  async resetGame(actor: GameActor): Promise<GameResult<null>> {
    return unwrap((await actor.resetGame()) as RawResult<null>);
  },

  async endLobby(actor: GameActor): Promise<GameResult<null>> {
    return unwrap((await actor.endLobby()) as RawResult<null>);
  },

  async getGameState(actor: GameActor): Promise<GameResult<GameView>> {
    return unwrap((await actor.getGameState()) as RawResult<GameView>);
  },

  async syncGameState(actor: GameActor): Promise<GameResult<GameView>> {
    return unwrap((await actor.syncGameState()) as RawResult<GameView>);
  },
};
