import { describe, expect, it, vi } from "vitest";

import type { GameActor } from "@/lib/backend";
import { GAME_ERROR_MESSAGES, gameApi, gameErrorMessage } from "@/lib/backend";
import {
  type ColorHex,
  GameError,
  type GameView,
  LobbyPhase,
  type PlayerId,
  Role,
  RpsChoice,
} from "@/types/game";

/**
 * Typed consumer contract for the generated actor.
 *
 * `gameApi` is the only seam between the React app and the canister: it unwraps
 * the generated `Result_*` union into a discriminated `GameResult`. These tests
 * pin that unwrapping and the argument forwarding, so a change to the generated
 * bindings or to the wrapper surfaces here rather than as a blank screen.
 */

/** A minimal `GameView` fixture; only the fields the wrapper touches. */
function gameView(overrides: Partial<GameView> = {}): GameView {
  return {
    accessCode: "K7Q2M9",
    selfId: 1n,
    serverNow: 1_000_000_000n,
    players: [],
    lobbyId: 1n,
    phase: LobbyPhase.lobby,
    hostId: 1n,
    winnerIds: [],
    visiblePositions: [],
    ...overrides,
  };
}

/** A typed actor mock whose methods are individually stubbable. */
function mockActor(overrides: Partial<GameActor> = {}): GameActor {
  const base: GameActor = {
    createLobby: vi.fn(async () => ({ __kind__: "ok", ok: null })),
    joinLobby: vi.fn(async () => ({ __kind__: "ok", ok: null })),
    leaveLobby: vi.fn(async () => ({ __kind__: "ok", ok: null })),
    setReady: vi.fn(async () => ({ __kind__: "ok", ok: null })),
    setColor: vi.fn(async () => ({ __kind__: "ok", ok: null })),
    startGame: vi.fn(async () => ({ __kind__: "ok", ok: null })),
    chooseRps: vi.fn(async () => ({ __kind__: "ok", ok: null })),
    updatePosition: vi.fn(async () => ({ __kind__: "ok", ok: null })),
    catchHider: vi.fn(async () => ({ __kind__: "ok", ok: null })),
    resetGame: vi.fn(async () => ({ __kind__: "ok", ok: null })),
    endLobby: vi.fn(async () => ({ __kind__: "ok", ok: null })),
    getGameState: vi.fn(async () => ({ __kind__: "ok", ok: gameView() })),
    syncGameState: vi.fn(async () => ({ __kind__: "ok", ok: gameView() })),
  };
  return { ...base, ...overrides };
}

describe("gameApi result unwrapping", () => {
  it("unwraps a successful createLobby payload", async () => {
    const actor = mockActor({
      createLobby: vi.fn(async () => ({
        __kind__: "ok",
        ok: { lobbyId: 7n, accessCode: "ABC234", playerId: 3n },
      })),
    });

    const result = await gameApi.createLobby(actor, "Ada", "#3fd67f");

    expect(result).toEqual({
      ok: true,
      value: { lobbyId: 7n, accessCode: "ABC234", playerId: 3n },
    });
    expect(actor.createLobby).toHaveBeenCalledWith("Ada", "#3fd67f");
  });

  it("surfaces a backend error instead of throwing", async () => {
    const actor = mockActor({
      joinLobby: vi.fn(async () => ({
        __kind__: "err",
        err: GameError.invalidCode,
      })),
    });

    const result = await gameApi.joinLobby(actor, "ZZZZZZ", "Bob", "#5aa9ff");

    expect(result).toEqual({ ok: false, error: GameError.invalidCode });
    expect(actor.joinLobby).toHaveBeenCalledWith("ZZZZZZ", "Bob", "#5aa9ff");
  });

  it("forwards position updates as micro-degrees", async () => {
    const actor = mockActor();
    await gameApi.updatePosition(actor, 51_507_400n, -127_400n);
    expect(actor.updatePosition).toHaveBeenCalledWith(51_507_400n, -127_400n);
  });

  it("forwards an RPS choice and a catch target", async () => {
    const actor = mockActor();
    await gameApi.chooseRps(actor, RpsChoice.rock);
    await gameApi.catchHider(actor, 4n as PlayerId);
    expect(actor.chooseRps).toHaveBeenCalledWith(RpsChoice.rock);
    expect(actor.catchHider).toHaveBeenCalledWith(4n);
  });

  it("returns the game view from syncGameState", async () => {
    const view = gameView({ phase: LobbyPhase.active, selfId: 2n });
    const actor = mockActor({
      syncGameState: vi.fn(async () => ({ __kind__: "ok", ok: view })),
    });

    const result = await gameApi.syncGameState(actor);

    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.value.phase).toBe(LobbyPhase.active);
      expect(result.value.selfId).toBe(2n);
    }
  });
});

describe("gameErrorMessage", () => {
  it("maps every backend error variant to display copy", () => {
    for (const error of Object.values(GameError)) {
      expect(GAME_ERROR_MESSAGES[error]).toBeTruthy();
      expect(gameErrorMessage(error)).toBe(GAME_ERROR_MESSAGES[error]);
    }
  });

  it("falls back to generic copy for an unknown error", () => {
    expect(gameErrorMessage("somethingElse" as GameError)).toBe(
      "Something went wrong.",
    );
  });
});

describe("color contract", () => {
  it("accepts the six identity colors as valid hex strings", () => {
    const hexes: ColorHex[] = [
      "#3fd67f",
      "#5aa9ff",
      "#f06bd0",
      "#f2b53c",
      "#ff6b5a",
      "#3fd0d6",
    ];
    for (const hex of hexes) {
      expect(hex).toMatch(/^#[0-9a-f]{6}$/);
    }
  });

  it("exposes the role and phase enums the UI compares against", () => {
    expect(Role.seeker).toBe("seeker");
    expect(Role.hider).toBe("hider");
    expect(LobbyPhase.waiting).toBe("waiting");
    expect(LobbyPhase.active).toBe("active");
    expect(LobbyPhase.ended).toBe("ended");
  });
});
