import type { Centimetres, GeoPoint, MicroDegrees } from "@/types/game";

const EARTH_RADIUS_M = 6_371_000;
const DEG_TO_RAD = Math.PI / 180;
const RAD_TO_DEG = 180 / Math.PI;

/** Micro-degrees (1e-6 deg) to decimal degrees. */
export function microToDegrees(value: MicroDegrees): number {
  return Number(value) / 1_000_000;
}

/** Decimal degrees to micro-degrees (rounded to the nearest integer). */
export function degreesToMicro(value: number): MicroDegrees {
  return BigInt(Math.round(value * 1_000_000));
}

/** Convert a backend `GeoPoint` to decimal degrees. */
export function pointToLatLng(point: GeoPoint): { lat: number; lng: number } {
  return { lat: microToDegrees(point.lat), lng: microToDegrees(point.lng) };
}

/** Centimetres to metres. */
export function cmToMetres(value: Centimetres): number {
  return Number(value) / 100;
}

/** Metres to centimetres (rounded to the nearest integer). */
export function metresToCm(value: number): Centimetres {
  return BigInt(Math.round(value * 100));
}

/** Great-circle distance between two points, in metres (haversine). */
export function haversineMetres(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number },
): number {
  const dLat = (b.lat - a.lat) * DEG_TO_RAD;
  const dLng = (b.lng - a.lng) * DEG_TO_RAD;
  const lat1 = a.lat * DEG_TO_RAD;
  const lat2 = b.lat * DEG_TO_RAD;

  const sinLat = Math.sin(dLat / 2);
  const sinLng = Math.sin(dLng / 2);
  const h = sinLat * sinLat + Math.cos(lat1) * Math.cos(lat2) * sinLng * sinLng;

  return 2 * EARTH_RADIUS_M * Math.asin(Math.min(1, Math.sqrt(h)));
}

/** Initial bearing from `a` to `b`, in degrees clockwise from north. */
export function bearingDegrees(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number },
): number {
  const lat1 = a.lat * DEG_TO_RAD;
  const lat2 = b.lat * DEG_TO_RAD;
  const dLng = (b.lng - a.lng) * DEG_TO_RAD;

  const y = Math.sin(dLng) * Math.cos(lat2);
  const x =
    Math.cos(lat1) * Math.sin(lat2) -
    Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);

  return (Math.atan2(y, x) * RAD_TO_DEG + 360) % 360;
}

/** Compass label for a bearing, e.g. `"NE"`. */
export function bearingLabel(degrees: number): string {
  const points = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  return points[Math.round(degrees / 45) % 8];
}

/** Format a metre distance for a HUD readout: `"312m"` or `"1.4km"`. */
export function formatDistance(metres: number): string {
  if (!Number.isFinite(metres)) return "—";
  if (metres < 1000) return `${Math.round(metres)}m`;
  return `${(metres / 1000).toFixed(1)}km`;
}

/** Format a millisecond duration as `MM:SS` (never negative). */
export function formatCountdown(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000));
  const minutes = Math.floor(total / 60);
  const seconds = total % 60;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

/** Metres per pixel at a given latitude for a Web Mercator tile zoom level. */
export function metresPerPixel(lat: number, zoom: number): number {
  return (156543.03392 * Math.cos(lat * DEG_TO_RAD)) / 2 ** zoom;
}

/** Clamp a number into an inclusive range. */
export function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}
