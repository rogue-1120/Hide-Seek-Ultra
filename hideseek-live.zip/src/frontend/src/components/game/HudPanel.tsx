import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

export interface HudPanelProps {
  /** Small uppercase label above the readout. */
  label: string;
  /** Large monospaced value. */
  value: string;
  /** Optional trailing unit or hint. */
  hint?: string;
  /** Optional leading icon. */
  icon?: ReactNode;
  /** Accent treatment for the panel. */
  tone?: "default" | "live" | "danger" | "warning";
  className?: string;
}

const TONE_CLASSES: Record<NonNullable<HudPanelProps["tone"]>, string> = {
  default: "border-border text-foreground",
  live: "border-primary/50 text-primary",
  danger: "border-accent/60 text-accent",
  warning: "border-warning/60 text-warning",
};

/** Compact floating readout used across the gameplay HUD. */
export function HudPanel({
  label,
  value,
  hint,
  icon,
  tone = "default",
  className,
}: HudPanelProps) {
  return (
    <div
      className={cn(
        "flex flex-col gap-0.5 rounded-xl border bg-card/90 px-3 py-2 shadow-hud-panel backdrop-blur",
        TONE_CLASSES[tone],
        className,
      )}
    >
      <span className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
        {icon}
        {label}
      </span>
      <span className="numeric-readout text-lg font-semibold leading-none">
        {value}
      </span>
      {hint && (
        <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
          {hint}
        </span>
      )}
    </div>
  );
}
