import { cn } from "@/lib/utils";
import { type PlayerView, Role } from "@/types/game";
import { Eye, Ghost, ShieldAlert, Target } from "lucide-react";

export interface PlayerRosterProps {
  players: PlayerView[];
  selfId: bigint;
}

/** Compact live roster with role and status badges for every player. */
export function PlayerRoster({ players, selfId }: PlayerRosterProps) {
  return (
    <ul
      className="flex flex-col gap-1.5"
      data-ocid="game.roster.list"
      aria-label="Player roster"
    >
      {players.map((player, index) => {
        const isSeeker = player.role === Role.seeker;
        const isOut = player.isDisqualified || player.isCaught;

        return (
          <li
            key={String(player.id)}
            className={cn(
              "flex items-center gap-2.5 rounded-lg border border-border bg-card/80 px-2.5 py-2",
              player.id === selfId && "border-primary/50 bg-primary/5",
              isOut && "opacity-60",
            )}
            data-ocid={`game.roster.item.${index + 1}`}
          >
            <span
              className="size-3 shrink-0 rounded-full ring-2 ring-background"
              style={{ backgroundColor: player.color }}
              aria-hidden="true"
            />
            <span className="min-w-0 flex-1 truncate font-display text-sm font-medium">
              {player.name}
              {player.id === selfId && (
                <span className="ml-1.5 font-mono text-[10px] uppercase tracking-widest text-primary">
                  You
                </span>
              )}
            </span>

            <span className="flex shrink-0 items-center gap-1">
              {isSeeker ? (
                <Eye className="size-3.5 text-accent" aria-label="Seeker" />
              ) : (
                <Ghost
                  className="size-3.5 text-muted-foreground"
                  aria-label="Hider"
                />
              )}
              {player.isOriginalSeeker && (
                <Target
                  className="size-3.5 text-warning"
                  aria-label="Original seeker"
                />
              )}
              {player.isDisqualified && (
                <ShieldAlert
                  className="size-3.5 text-destructive"
                  aria-label="Out of zone"
                />
              )}
              {player.isCaught && !player.isDisqualified && (
                <span className="font-mono text-[10px] uppercase tracking-wider text-accent">
                  Caught
                </span>
              )}
            </span>
          </li>
        );
      })}
    </ul>
  );
}
