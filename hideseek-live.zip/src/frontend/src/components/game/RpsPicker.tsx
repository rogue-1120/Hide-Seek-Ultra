import { cn } from "@/lib/utils";
import { RpsChoice, RpsOutcome, type RpsState } from "@/types/game";
import { Check, Hand, Scissors, Square } from "lucide-react";

export interface RpsPickerProps {
  rps: RpsState;
  /** The caller's player id, used to detect whether they have chosen. */
  selfId: bigint;
  /** True while a choice mutation is in flight. */
  pending: boolean;
  onChoose: (choice: RpsChoice) => void;
}

const CHOICES: {
  choice: RpsChoice;
  label: string;
  Icon: typeof Hand;
}[] = [
  { choice: RpsChoice.rock, label: "Rock", Icon: Square },
  { choice: RpsChoice.paper, label: "Paper", Icon: Hand },
  { choice: RpsChoice.scissors, label: "Scissors", Icon: Scissors },
];

/** Rock-paper-scissors picker with round state and tie re-run messaging. */
export function RpsPicker({ rps, selfId, pending, onChoose }: RpsPickerProps) {
  const self = rps.players.find((p) => p.playerId === selfId);
  const hasChosen = self?.hasChosen ?? false;
  const chosenCount = rps.players.filter((p) => p.hasChosen).length;
  const isTie = rps.outcome === RpsOutcome.tie;

  return (
    <div
      className="flex flex-col gap-4 rounded-2xl border border-border bg-card/95 p-4 shadow-hud-panel backdrop-blur"
      data-ocid="game.rps.panel"
    >
      <div className="flex items-center justify-between gap-3">
        <div className="flex flex-col">
          <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            Round
          </span>
          <span className="numeric-readout text-xl font-semibold">
            {String(rps.round)}
          </span>
        </div>
        <div className="flex flex-col items-end">
          <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            Locked in
          </span>
          <span className="numeric-readout text-xl font-semibold">
            {chosenCount}/{rps.players.length}
          </span>
        </div>
      </div>

      {isTie && (
        <p
          className="rounded-lg border border-warning/50 bg-warning/10 px-3 py-2 text-center font-mono text-xs uppercase tracking-wider text-warning"
          data-ocid="game.rps.tie_state"
        >
          Tie — pick again to break it
        </p>
      )}

      <div className="grid grid-cols-3 gap-2">
        {CHOICES.map(({ choice, label, Icon }) => {
          const isPicked = self?.choice === choice;
          return (
            <button
              key={choice}
              type="button"
              onClick={() => onChoose(choice)}
              disabled={pending || hasChosen}
              aria-pressed={isPicked}
              data-ocid={`game.rps.choice.${choice}`}
              className={cn(
                "flex flex-col items-center gap-2 rounded-xl border px-2 py-4 transition-smooth",
                isPicked
                  ? "border-primary bg-primary/15 text-primary"
                  : "border-border bg-background/60 text-foreground",
                pending || hasChosen
                  ? "cursor-not-allowed opacity-60"
                  : "hover:border-primary/60 hover:bg-primary/5 active:scale-95",
              )}
            >
              <Icon className="size-6" />
              <span className="font-mono text-[11px] uppercase tracking-wider">
                {label}
              </span>
            </button>
          );
        })}
      </div>

      <ul className="flex flex-wrap gap-1.5">
        {rps.players.map((player) => (
          <li
            key={String(player.playerId)}
            className={cn(
              "flex items-center gap-1 rounded-full px-2 py-1 font-mono text-[10px] uppercase tracking-wider",
              player.hasChosen
                ? "bg-primary/15 text-primary"
                : "bg-muted text-muted-foreground",
            )}
          >
            {player.hasChosen && <Check className="size-3" />}
            {player.playerId === selfId ? "You" : `#${String(player.playerId)}`}
          </li>
        ))}
      </ul>

      {hasChosen && !isTie && (
        <p className="text-center text-xs text-muted-foreground">
          Choice locked. Waiting for the rest of the squad…
        </p>
      )}
    </div>
  );
}
