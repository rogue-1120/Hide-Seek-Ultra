import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";

import { RpsPicker } from "@/components/game/RpsPicker";
import { RpsChoice, RpsOutcome, type RpsState } from "@/types/game";

function rps(overrides: Partial<RpsState> = {}): RpsState {
  return {
    round: 0n,
    outcome: RpsOutcome.pending,
    players: [
      { playerId: 1n, hasChosen: false },
      { playerId: 2n, hasChosen: false },
    ],
    ...overrides,
  };
}

/**
 * The RPS picker is how a player locks in their choice. It must show the round,
 * the locked-in count, disable the controls once the caller has chosen, and
 * surface the tie re-run message.
 */
describe("RpsPicker", () => {
  it("shows the round number and locked-in count", () => {
    render(
      <RpsPicker
        rps={rps({
          round: 2n,
          players: [
            { playerId: 1n, hasChosen: true },
            { playerId: 2n, hasChosen: false },
          ],
        })}
        selfId={1n}
        pending={false}
        onChoose={() => {}}
      />,
    );

    expect(screen.getByText("2")).toBeInTheDocument();
    expect(screen.getByText("1/2")).toBeInTheDocument();
  });

  it("offers rock, paper, and scissors", () => {
    render(
      <RpsPicker rps={rps()} selfId={1n} pending={false} onChoose={() => {}} />,
    );
    expect(screen.getByRole("button", { name: /rock/i })).toBeEnabled();
    expect(screen.getByRole("button", { name: /paper/i })).toBeEnabled();
    expect(screen.getByRole("button", { name: /scissors/i })).toBeEnabled();
  });

  it("reports the chosen option", async () => {
    const user = userEvent.setup();
    const onChoose = vi.fn();
    render(
      <RpsPicker rps={rps()} selfId={1n} pending={false} onChoose={onChoose} />,
    );

    await user.click(screen.getByRole("button", { name: /scissors/i }));

    expect(onChoose).toHaveBeenCalledWith(RpsChoice.scissors);
  });

  it("disables the controls once the caller has chosen", () => {
    render(
      <RpsPicker
        rps={rps({
          players: [
            { playerId: 1n, hasChosen: true, choice: RpsChoice.rock },
            { playerId: 2n, hasChosen: false },
          ],
        })}
        selfId={1n}
        pending={false}
        onChoose={() => {}}
      />,
    );

    expect(screen.getByRole("button", { name: /rock/i })).toBeDisabled();
    expect(
      screen.getByText(/waiting for the rest of the squad/i),
    ).toBeInTheDocument();
  });

  it("announces a tie and re-enables the picker", () => {
    render(
      <RpsPicker
        rps={rps({ outcome: RpsOutcome.tie, round: 1n })}
        selfId={1n}
        pending={false}
        onChoose={() => {}}
      />,
    );

    expect(screen.getByText(/tie — pick again/i)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /rock/i })).toBeEnabled();
  });

  it("disables the controls while a choice is in flight", () => {
    render(<RpsPicker rps={rps()} selfId={1n} pending onChoose={() => {}} />);
    expect(screen.getByRole("button", { name: /rock/i })).toBeDisabled();
  });
});
