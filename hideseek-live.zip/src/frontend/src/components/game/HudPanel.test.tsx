import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";

import { HudPanel } from "@/components/game/HudPanel";
import { PlayerRoster } from "@/components/game/PlayerRoster";
import { WinnerCard } from "@/components/results/WinnerCard";
import { type PlayerView, Role } from "@/types/game";

function player(overrides: Partial<PlayerView> = {}): PlayerView {
  return {
    id: 1n,
    name: "Ada",
    color: "#3fd67f",
    role: Role.hider,
    isHost: false,
    isReady: false,
    isDisqualified: false,
    isCaught: false,
    isOriginalSeeker: false,
    ...overrides,
  };
}

describe("HudPanel", () => {
  it("renders its label, value, and hint", () => {
    render(<HudPanel label="From start" value="312m" hint="Zone 500m" />);
    expect(screen.getByText("From start")).toBeInTheDocument();
    expect(screen.getByText("312m")).toBeInTheDocument();
    expect(screen.getByText("Zone 500m")).toBeInTheDocument();
  });
});

describe("PlayerRoster", () => {
  it("lists every player with role and status badges", () => {
    render(
      <PlayerRoster
        players={[
          player({
            id: 1n,
            name: "Ada",
            role: Role.seeker,
            isOriginalSeeker: true,
          }),
          player({ id: 2n, name: "Bob", isCaught: true }),
          player({ id: 3n, name: "Cy", isDisqualified: true }),
        ]}
        selfId={1n}
      />,
    );

    expect(screen.getByText("Ada")).toBeInTheDocument();
    expect(screen.getByText("Bob")).toBeInTheDocument();
    expect(screen.getByText("Cy")).toBeInTheDocument();
    expect(screen.getByLabelText("Seeker")).toBeInTheDocument();
    expect(screen.getByLabelText("Original seeker")).toBeInTheDocument();
    expect(screen.getByText("Caught")).toBeInTheDocument();
    expect(screen.getByLabelText("Out of zone")).toBeInTheDocument();
  });

  it("marks the caller in the roster", () => {
    render(
      <PlayerRoster players={[player({ id: 5n, name: "Ada" })]} selfId={5n} />,
    );
    expect(screen.getByText("You")).toBeInTheDocument();
  });
});

describe("WinnerCard", () => {
  it("announces the headline, detail, and winners", () => {
    render(
      <WinnerCard
        winners={[
          player({ id: 1n, name: "Ada" }),
          player({ id: 2n, name: "Bob" }),
        ]}
        headline="Time expired"
        detail="The horn sounded with hiders still in play — they survive."
      />,
    );

    expect(
      screen.getByRole("heading", { name: "Time expired" }),
    ).toBeInTheDocument();
    expect(screen.getByText(/they survive/i)).toBeInTheDocument();
    expect(screen.getByText("Ada")).toBeInTheDocument();
    expect(screen.getByText("Bob")).toBeInTheDocument();
  });

  it("renders without a winner list when nobody won", () => {
    render(
      <WinnerCard
        winners={[]}
        headline="Lobby ended"
        detail="The host closed the round early."
      />,
    );
    expect(
      screen.getByRole("heading", { name: "Lobby ended" }),
    ).toBeInTheDocument();
    expect(screen.queryByRole("list")).not.toBeInTheDocument();
  });
});
