import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";

import { PlayerRow } from "@/components/lobby/PlayerRow";
import { type PlayerView, Role } from "@/types/game";

function player(overrides: Partial<PlayerView> = {}): PlayerView {
  return {
    id: 1n,
    name: "Ada",
    color: "#3fd67f",
    role: Role.hider,
    isHost: false,
    isReady: false,
    isDisqualified: false,
    isCaught: false,
    isOriginalSeeker: false,
    ...overrides,
  };
}

/**
 * The lobby roster must show every joined player with their chosen color and a
 * ready state, and mark the host and the caller.
 */
describe("PlayerRow", () => {
  it("shows the callsign, color dot, and waiting state", () => {
    render(<PlayerRow player={player()} isSelf={false} index={0} />);

    expect(screen.getByText("Ada")).toBeInTheDocument();
    expect(screen.getByText("Waiting")).toBeInTheDocument();
    expect(screen.getByText("Hider")).toBeInTheDocument();
  });

  it("marks the caller with a You label", () => {
    render(<PlayerRow player={player()} isSelf index={0} />);
    expect(screen.getByText("You")).toBeInTheDocument();
  });

  it("shows the host badge for the host", () => {
    render(
      <PlayerRow player={player({ isHost: true })} isSelf={false} index={0} />,
    );
    expect(screen.getByText("Host")).toBeInTheDocument();
  });

  it("shows a ready state once the player is ready", () => {
    render(
      <PlayerRow player={player({ isReady: true })} isSelf={false} index={0} />,
    );
    expect(screen.getByText("Ready")).toBeInTheDocument();
  });

  it("shows the seeker badge for a seeker", () => {
    render(
      <PlayerRow
        player={player({ role: Role.seeker, isOriginalSeeker: true })}
        isSelf={false}
        index={0}
      />,
    );
    expect(screen.getByText("Seeker")).toBeInTheDocument();
    expect(screen.queryByText("Hider")).not.toBeInTheDocument();
  });

  it("renders the player's identity color", () => {
    const { container } = render(
      <PlayerRow
        player={player({ color: "#f06bd0" })}
        isSelf={false}
        index={0}
      />,
    );
    const dot = container.querySelector("[aria-hidden='true']");
    expect(dot).toHaveStyle({ backgroundColor: "#f06bd0" });
  });
});
