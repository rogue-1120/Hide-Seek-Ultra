import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { type PlayerView, Role } from "@/types/game";
import { Check, Crown, Eye, Ghost } from "lucide-react";

export interface PlayerRowProps {
  player: PlayerView;
  isSelf: boolean;
  /** Position in the list, used for a stable deterministic marker. */
  index: number;
}

/** One player in the lobby roster: identity dot, callsign, badges, ready state. */
export function PlayerRow({ player, isSelf, index }: PlayerRowProps) {
  const isSeeker = player.role === Role.seeker;

  return (
    <li
      className={cn(
        "flex items-center gap-3 rounded-xl border border-border bg-card/70 px-3 py-3",
        isSelf && "border-primary/50 bg-primary/5",
      )}
      data-ocid={`lobby.player.item.${index + 1}`}
    >
      <span
        className="size-4 shrink-0 rounded-full ring-2 ring-background"
        style={{ backgroundColor: player.color }}
        aria-hidden="true"
      />

      <div className="flex min-w-0 flex-1 flex-col gap-1">
        <div className="flex min-w-0 items-center gap-2">
          <span className="truncate font-display text-sm font-semibold">
            {player.name}
          </span>
          {isSelf && (
            <span className="shrink-0 font-mono text-[10px] uppercase tracking-widest text-primary">
              You
            </span>
          )}
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          {player.isHost && (
            <Badge
              variant="outline"
              className="gap-1 border-warning/50 bg-warning/10 font-mono text-[10px] uppercase tracking-wider text-warning"
            >
              <Crown className="size-3" />
              Host
            </Badge>
          )}
          {isSeeker && (
            <Badge
              variant="outline"
              className="gap-1 border-accent/50 bg-accent/10 font-mono text-[10px] uppercase tracking-wider text-accent"
            >
              <Eye className="size-3" />
              Seeker
            </Badge>
          )}
          {!isSeeker && (
            <Badge
              variant="outline"
              className="gap-1 border-border font-mono text-[10px] uppercase tracking-wider text-muted-foreground"
            >
              <Ghost className="size-3" />
              Hider
            </Badge>
          )}
        </div>
      </div>

      <span
        className={cn(
          "flex shrink-0 items-center gap-1 rounded-full px-2 py-1 font-mono text-[10px] uppercase tracking-wider",
          player.isReady
            ? "bg-primary/15 text-primary"
            : "bg-muted text-muted-foreground",
        )}
        data-ocid={`lobby.player.ready_state.${index + 1}`}
      >
        {player.isReady ? (
          <>
            <Check className="size-3" />
            Ready
          </>
        ) : (
          "Waiting"
        )}
      </span>
    </li>
  );
}
