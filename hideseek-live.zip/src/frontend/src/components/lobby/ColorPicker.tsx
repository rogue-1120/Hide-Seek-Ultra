import { cn } from "@/lib/utils";
import { type ColorHex, PLAYER_COLORS } from "@/types/game";
import { Check } from "lucide-react";

export interface ColorPickerProps {
  /** The caller's currently selected color hex. */
  selected: ColorHex | null;
  /** Colors already claimed by other players in this lobby. */
  taken: readonly ColorHex[];
  /** Called with the chosen hex when the player taps an available swatch. */
  onSelect: (hex: ColorHex) => void;
  /** Disables interaction while a color change is in flight. */
  disabled?: boolean;
}

/** Six identity swatches; taken colors are shown but not selectable. */
export function ColorPicker({
  selected,
  taken,
  onSelect,
  disabled = false,
}: ColorPickerProps) {
  const takenSet = new Set(taken.map((hex) => hex.toLowerCase()));
  const selectedKey = selected?.toLowerCase() ?? null;

  return (
    <fieldset
      className="grid grid-cols-6 gap-2 border-0 p-0"
      data-ocid="lobby.color_picker"
    >
      <legend className="sr-only">Choose your identity color</legend>
      {PLAYER_COLORS.map((color) => {
        const isTaken = takenSet.has(color.hex.toLowerCase());
        const isSelected = selectedKey === color.hex.toLowerCase();
        const isDisabled = disabled || (isTaken && !isSelected);

        return (
          <button
            key={color.slot}
            type="button"
            onClick={() => onSelect(color.hex)}
            disabled={isDisabled}
            aria-label={
              isTaken && !isSelected
                ? `${color.label} — taken`
                : `Choose ${color.label}`
            }
            aria-pressed={isSelected}
            data-ocid={`lobby.color_option.${color.slot}`}
            className={cn(
              "relative flex aspect-square items-center justify-center rounded-xl border transition-smooth",
              isSelected
                ? "border-foreground/70 ring-2 ring-foreground/40"
                : "border-border",
              isDisabled
                ? "cursor-not-allowed opacity-30"
                : "hover:scale-105 active:scale-95",
            )}
            style={{ backgroundColor: color.hex }}
          >
            {isSelected && (
              <Check className="size-5 text-background drop-shadow" />
            )}
            {isTaken && !isSelected && (
              <span className="absolute inset-0 rounded-xl bg-background/55" />
            )}
          </button>
        );
      })}
    </fieldset>
  );
}
