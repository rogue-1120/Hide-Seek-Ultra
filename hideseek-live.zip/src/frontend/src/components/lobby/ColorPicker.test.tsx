import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";

import { ColorPicker } from "@/components/lobby/ColorPicker";
import { PLAYER_COLORS } from "@/types/game";

/**
 * The color picker enforces the "each player picks a unique color" rule on the
 * client: taken colors are rendered but not selectable, and the caller's own
 * color stays selectable even though it appears in the taken list.
 */
describe("ColorPicker", () => {
  it("renders all six identity colors", () => {
    render(<ColorPicker selected={null} taken={[]} onSelect={() => {}} />);
    for (const color of PLAYER_COLORS) {
      expect(
        screen.getByRole("button", { name: `Choose ${color.label}` }),
      ).toBeInTheDocument();
    }
  });

  it("disables colors taken by other players", () => {
    render(
      <ColorPicker selected={null} taken={["#5aa9ff"]} onSelect={() => {}} />,
    );
    expect(
      screen.getByRole("button", { name: "Cobalt — taken" }),
    ).toBeDisabled();
    expect(screen.getByRole("button", { name: "Choose Signal" })).toBeEnabled();
  });

  it("keeps the caller's own color selectable when it appears in taken", () => {
    render(
      <ColorPicker
        selected="#5aa9ff"
        taken={["#5aa9ff"]}
        onSelect={() => {}}
      />,
    );
    const own = screen.getByRole("button", { name: "Choose Cobalt" });
    expect(own).toBeEnabled();
    expect(own).toHaveAttribute("aria-pressed", "true");
  });

  it("reports the chosen hex when an available swatch is tapped", async () => {
    const user = userEvent.setup();
    const onSelect = vi.fn();
    render(<ColorPicker selected={null} taken={[]} onSelect={onSelect} />);

    await user.click(screen.getByRole("button", { name: "Choose Amber" }));

    expect(onSelect).toHaveBeenCalledWith("#f2b53c");
  });

  it("does not fire onSelect for a taken color", async () => {
    const user = userEvent.setup();
    const onSelect = vi.fn();
    render(
      <ColorPicker selected={null} taken={["#f2b53c"]} onSelect={onSelect} />,
    );

    await user.click(screen.getByRole("button", { name: "Amber — taken" }));

    expect(onSelect).not.toHaveBeenCalled();
  });

  it("disables every swatch while a change is in flight", () => {
    render(
      <ColorPicker selected={null} taken={[]} onSelect={() => {}} disabled />,
    );
    for (const color of PLAYER_COLORS) {
      expect(
        screen.getByRole("button", { name: `Choose ${color.label}` }),
      ).toBeDisabled();
    }
  });
});
