import { clamp, metresPerPixel } from "@/lib/geo";
import { cn } from "@/lib/utils";
import type { LatLng, MapMarker } from "@/types/game";
import { Crosshair, Minus, Plus } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

const TILE_SIZE = 256;
const MIN_ZOOM = 3;
const MAX_ZOOM = 19;
const TILE_URL = "https://tile.openstreetmap.org/{z}/{x}/{y}.png";

export interface GameMapProps {
  /** Map center in decimal degrees. */
  center: LatLng;
  /** Initial zoom level (Web Mercator). */
  zoom?: number;
  /** Markers to draw on top of the tiles. */
  markers?: MapMarker[];
  /** Optional play-zone radius in metres, drawn around `boundaryCenter`. */
  boundaryRadiusM?: number;
  /**
   * Anchor point for the play-zone boundary. Defaults to `center`. Pass the
   * seeker's start point so the circle stays fixed to that projected location
   * while the user pans and zooms.
   */
  boundaryCenter?: LatLng;
  /** Called when the user pans or zooms, with the new view. */
  onViewChange?: (view: { center: LatLng; zoom: number }) => void;
  /** Extra classes for the map container. */
  className?: string;
}

interface ViewState {
  center: LatLng;
  zoom: number;
}

/** Project a lat/lng to world pixel coordinates at a given zoom. */
function project(
  lat: number,
  lng: number,
  zoom: number,
): { x: number; y: number } {
  const scale = TILE_SIZE * 2 ** zoom;
  const x = ((lng + 180) / 360) * scale;
  const sinLat = Math.sin((lat * Math.PI) / 180);
  const y =
    (0.5 - Math.log((1 + sinLat) / (1 - sinLat)) / (4 * Math.PI)) * scale;
  return { x, y };
}

/** Inverse of `project`: world pixels back to lat/lng. */
function unproject(x: number, y: number, zoom: number): LatLng {
  const scale = TILE_SIZE * 2 ** zoom;
  const lng = (x / scale) * 360 - 180;
  const n = Math.PI - (2 * Math.PI * y) / scale;
  const lat = (180 / Math.PI) * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n)));
  return { lat, lng };
}

/** Distance between two touches, for pinch detection. */
function touchDistance(touches: React.TouchList): number {
  const a = touches.item(0);
  const b = touches.item(1);
  if (!a || !b) return 0;
  return Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
}

/**
 * Canvas-rendered map with real tiles, pinch-zoom, drag-pan, and overlays.
 *
 * Tiles are fetched from OpenStreetMap and drawn to a `<canvas>`; markers and
 * the optional play-zone boundary are drawn on top. Gesture handling covers
 * mouse drag, wheel zoom, single-touch drag, and two-finger pinch.
 */
export function GameMap({
  center,
  zoom = 16,
  markers = [],
  boundaryRadiusM,
  boundaryCenter,
  onViewChange,
  className,
}: GameMapProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const tileCache = useRef<Map<string, HTMLImageElement>>(new Map());
  const [view, setView] = useState<ViewState>({ center, zoom });
  const [size, setSize] = useState({ width: 0, height: 0 });
  const [tilesReady, setTilesReady] = useState(false);

  const viewRef = useRef(view);
  viewRef.current = view;
  const gestureRef = useRef<{
    dragging: boolean;
    lastX: number;
    lastY: number;
    pinchDistance: number;
    pinchZoom: number;
  }>({
    dragging: false,
    lastX: 0,
    lastY: 0,
    pinchDistance: 0,
    pinchZoom: zoom,
  });

  // Follow external center/zoom changes (e.g. recentering on the player).
  useEffect(() => {
    setView((prev) => {
      if (
        prev.center.lat === center.lat &&
        prev.center.lng === center.lng &&
        prev.zoom === zoom
      ) {
        return prev;
      }
      return { center, zoom };
    });
  }, [center, zoom]);

  // Track container size.
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const observer = new ResizeObserver((entries) => {
      const rect = entries[0].contentRect;
      setSize({ width: rect.width, height: rect.height });
    });
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const notifyView = useCallback(
    (next: ViewState) => {
      onViewChange?.(next);
    },
    [onViewChange],
  );

  const applyView = useCallback(
    (next: ViewState) => {
      setView(next);
      notifyView(next);
    },
    [notifyView],
  );

  // Draw tiles + overlays whenever the view, size, or data changes.
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || size.width === 0 || size.height === 0) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.floor(size.width * dpr);
    canvas.height = Math.floor(size.height * dpr);
    canvas.style.width = `${size.width}px`;
    canvas.style.height = `${size.height}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const { center: c, zoom: z } = view;
    const centerPx = project(c.lat, c.lng, z);
    const originX = centerPx.x - size.width / 2;
    const originY = centerPx.y - size.height / 2;

    const draw = () => {
      // Base fill so the map never flashes white.
      ctx.fillStyle = "#0d1117";
      ctx.fillRect(0, 0, size.width, size.height);

      const minTileX = Math.floor(originX / TILE_SIZE);
      const maxTileX = Math.floor((originX + size.width) / TILE_SIZE);
      const minTileY = Math.floor(originY / TILE_SIZE);
      const maxTileY = Math.floor((originY + size.height) / TILE_SIZE);
      const tileCount = 2 ** z;

      for (let tx = minTileX; tx <= maxTileX; tx++) {
        for (let ty = minTileY; ty <= maxTileY; ty++) {
          if (ty < 0 || ty >= tileCount) continue;
          const wrappedX = ((tx % tileCount) + tileCount) % tileCount;
          const key = `${z}/${wrappedX}/${ty}`;
          const img = tileCache.current.get(key);
          const dx = tx * TILE_SIZE - originX;
          const dy = ty * TILE_SIZE - originY;
          if (img?.complete && img.naturalWidth > 0) {
            ctx.drawImage(img, dx, dy, TILE_SIZE, TILE_SIZE);
          }
        }
      }

      // Hairline grid for the tactical instrument feel.
      ctx.strokeStyle = "rgba(120, 140, 170, 0.10)";
      ctx.lineWidth = 1;
      const gridStep = 64;
      const offsetX = -originX % gridStep;
      const offsetY = -originY % gridStep;
      for (let x = offsetX; x < size.width; x += gridStep) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, size.height);
        ctx.stroke();
      }
      for (let y = offsetY; y < size.height; y += gridStep) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(size.width, y);
        ctx.stroke();
      }

      // Play-zone boundary anchored to the projected start point, so it stays
      // fixed to that location while the viewport pans and zooms.
      if (boundaryRadiusM && boundaryRadiusM > 0) {
        const anchor = boundaryCenter ?? c;
        const mpp = metresPerPixel(anchor.lat, z);
        const radiusPx = boundaryRadiusM / mpp;
        const anchorPx = project(anchor.lat, anchor.lng, z);
        const cx = anchorPx.x - originX;
        const cy = anchorPx.y - originY;

        ctx.beginPath();
        ctx.arc(cx, cy, radiusPx, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(63, 214, 127, 0.10)";
        ctx.fill();
        ctx.strokeStyle = "rgba(63, 214, 127, 0.85)";
        ctx.lineWidth = 2;
        ctx.setLineDash([10, 8]);
        ctx.stroke();
        ctx.setLineDash([]);

        // Radius label on the boundary edge.
        ctx.font = "600 12px 'JetBrains Mono', monospace";
        ctx.fillStyle = "rgba(63, 214, 127, 0.95)";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(`${boundaryRadiusM}m`, cx, cy - radiusPx - 12);
      }

      // Markers.
      for (const marker of markers) {
        const p = project(marker.lat, marker.lng, z);
        const x = p.x - originX;
        const y = p.y - originY;
        if (x < -40 || y < -40 || x > size.width + 40 || y > size.height + 40) {
          continue;
        }

        if (marker.isSelf) {
          ctx.beginPath();
          ctx.arc(x, y, 18, 0, Math.PI * 2);
          ctx.fillStyle = `${marker.color}22`;
          ctx.fill();
        }

        ctx.beginPath();
        ctx.arc(x, y, marker.isSelf ? 8 : 6, 0, Math.PI * 2);
        ctx.fillStyle = marker.color;
        ctx.fill();
        ctx.lineWidth = 2;
        ctx.strokeStyle = marker.isSelf ? "#0d1117" : "rgba(13, 17, 23, 0.85)";
        ctx.stroke();

        if (marker.label) {
          ctx.font = "600 11px 'DM Sans', sans-serif";
          ctx.textAlign = "center";
          ctx.textBaseline = "bottom";
          const labelY = y - (marker.isSelf ? 14 : 12);
          const metrics = ctx.measureText(marker.label);
          const padX = 5;
          ctx.fillStyle = "rgba(13, 17, 23, 0.82)";
          ctx.fillRect(
            x - metrics.width / 2 - padX,
            labelY - 13,
            metrics.width + padX * 2,
            15,
          );
          ctx.fillStyle = "#e8ecf2";
          ctx.fillText(marker.label, x, labelY);
        }
      }
    };

    // Preload visible tiles, then redraw.
    const { center: cc, zoom: zz } = view;
    const cpx = project(cc.lat, cc.lng, zz);
    const ox = cpx.x - size.width / 2;
    const oy = cpx.y - size.height / 2;
    const minX = Math.floor(ox / TILE_SIZE);
    const maxX = Math.floor((ox + size.width) / TILE_SIZE);
    const minY = Math.floor(oy / TILE_SIZE);
    const maxY = Math.floor((oy + size.height) / TILE_SIZE);
    const count = 2 ** zz;
    let pending = 0;

    for (let tx = minX; tx <= maxX; tx++) {
      for (let ty = minY; ty <= maxY; ty++) {
        if (ty < 0 || ty >= count) continue;
        const wrappedX = ((tx % count) + count) % count;
        const key = `${zz}/${wrappedX}/${ty}`;
        if (tileCache.current.has(key)) continue;
        pending++;
        const img = new Image();
        img.crossOrigin = "anonymous";
        img.onload = () => {
          tileCache.current.set(key, img);
          draw();
        };
        img.onerror = () => {
          tileCache.current.set(key, img);
        };
        img.src = TILE_URL.replace("{z}", String(zz))
          .replace("{x}", String(wrappedX))
          .replace("{y}", String(ty));
      }
    }

    draw();
    if (pending > 0) setTilesReady(true);
  }, [view, size, markers, boundaryRadiusM, boundaryCenter]);

  // Wheel zoom (desktop).
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const onWheel = (event: WheelEvent) => {
      event.preventDefault();
      const current = viewRef.current;
      const delta = event.deltaY > 0 ? -1 : 1;
      const nextZoom = clamp(current.zoom + delta, MIN_ZOOM, MAX_ZOOM);
      if (nextZoom === current.zoom) return;
      applyView({ center: current.center, zoom: nextZoom });
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, [applyView]);

  const onPointerDown = useCallback((event: React.PointerEvent) => {
    gestureRef.current.dragging = true;
    gestureRef.current.lastX = event.clientX;
    gestureRef.current.lastY = event.clientY;
    (event.target as Element).setPointerCapture?.(event.pointerId);
  }, []);

  const onPointerMove = useCallback(
    (event: React.PointerEvent) => {
      const g = gestureRef.current;
      if (!g.dragging) return;
      const dx = event.clientX - g.lastX;
      const dy = event.clientY - g.lastY;
      g.lastX = event.clientX;
      g.lastY = event.clientY;

      const current = viewRef.current;
      const centerPx = project(
        current.center.lat,
        current.center.lng,
        current.zoom,
      );
      const next = unproject(centerPx.x - dx, centerPx.y - dy, current.zoom);
      applyView({ center: next, zoom: current.zoom });
    },
    [applyView],
  );

  const onPointerUp = useCallback((event: React.PointerEvent) => {
    gestureRef.current.dragging = false;
    (event.target as Element).releasePointerCapture?.(event.pointerId);
  }, []);

  const onTouchStart = useCallback((event: React.TouchEvent) => {
    if (event.touches.length === 2) {
      gestureRef.current.pinchDistance = touchDistance(event.touches);
      gestureRef.current.pinchZoom = viewRef.current.zoom;
      gestureRef.current.dragging = false;
    }
  }, []);

  const onTouchMove = useCallback(
    (event: React.TouchEvent) => {
      const g = gestureRef.current;
      if (event.touches.length === 2 && g.pinchDistance > 0) {
        event.preventDefault();
        const distance = touchDistance(event.touches);
        const ratio = distance / g.pinchDistance;
        const nextZoom = clamp(
          g.pinchZoom + Math.log2(ratio),
          MIN_ZOOM,
          MAX_ZOOM,
        );
        applyView({ center: viewRef.current.center, zoom: nextZoom });
      }
    },
    [applyView],
  );

  const onTouchEnd = useCallback(() => {
    gestureRef.current.pinchDistance = 0;
  }, []);

  const zoomBy = useCallback(
    (delta: number) => {
      const current = viewRef.current;
      applyView({
        center: current.center,
        zoom: clamp(current.zoom + delta, MIN_ZOOM, MAX_ZOOM),
      });
    },
    [applyView],
  );

  const recenter = useCallback(() => {
    applyView({ center, zoom });
  }, [applyView, center, zoom]);

  const zoomLabel = useMemo(() => `z${view.zoom.toFixed(0)}`, [view.zoom]);

  return (
    <div
      ref={containerRef}
      className={cn(
        "relative h-full w-full touch-none overflow-hidden bg-background",
        className,
      )}
      data-ocid="map.canvas_target"
    >
      <canvas
        ref={canvasRef}
        className="absolute inset-0 h-full w-full cursor-grab active:cursor-grabbing"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
      />

      {tilesReady && (
        <div className="pointer-events-none absolute bottom-2 right-2 rounded bg-background/70 px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground">
          © OpenStreetMap
        </div>
      )}

      <div className="absolute right-3 top-3 flex flex-col gap-2">
        <button
          type="button"
          onClick={() => zoomBy(1)}
          aria-label="Zoom in"
          data-ocid="map.zoom_in_button"
          className="flex size-11 items-center justify-center rounded-lg border border-border bg-card/90 text-foreground shadow-hud-panel backdrop-blur transition-smooth hover:bg-secondary active:scale-95"
        >
          <Plus className="size-5" />
        </button>
        <button
          type="button"
          onClick={() => zoomBy(-1)}
          aria-label="Zoom out"
          data-ocid="map.zoom_out_button"
          className="flex size-11 items-center justify-center rounded-lg border border-border bg-card/90 text-foreground shadow-hud-panel backdrop-blur transition-smooth hover:bg-secondary active:scale-95"
        >
          <Minus className="size-5" />
        </button>
        <button
          type="button"
          onClick={recenter}
          aria-label="Recenter map"
          data-ocid="map.recenter_button"
          className="flex size-11 items-center justify-center rounded-lg border border-border bg-card/90 text-foreground shadow-hud-panel backdrop-blur transition-smooth hover:bg-secondary active:scale-95"
        >
          <Crosshair className="size-5" />
        </button>
      </div>

      <div className="pointer-events-none absolute bottom-2 left-2 rounded bg-background/70 px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground">
        {zoomLabel}
      </div>
    </div>
  );
}
