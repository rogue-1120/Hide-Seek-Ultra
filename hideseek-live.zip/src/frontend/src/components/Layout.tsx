import { cn } from "@/lib/utils";
import { Link } from "@tanstack/react-router";
import { Radar } from "lucide-react";
import type { ReactNode } from "react";

export interface LayoutProps {
  children: ReactNode;
  /** Optional title shown in the header. */
  title?: string;
  /** Optional element rendered on the right of the header. */
  action?: ReactNode;
  /** When true, the main area fills the viewport with no padding (map views). */
  fullBleed?: boolean;
  /** When true, hide the header entirely (immersive gameplay). */
  hideHeader?: boolean;
}

/**
 * Mobile-first app shell with a sticky header, safe-area handling, and an
 * attribution footer. Gameplay routes use `fullBleed` + `hideHeader` so the
 * map can own the viewport.
 */
export function Layout({
  children,
  title,
  action,
  fullBleed = false,
  hideHeader = false,
}: LayoutProps) {
  return (
    <div className="flex min-h-dvh flex-col bg-background text-foreground">
      {!hideHeader && (
        <header className="sticky top-0 z-30 border-b border-border bg-card/95 pt-[env(safe-area-inset-top)] backdrop-blur">
          <div className="mx-auto flex h-14 w-full max-w-2xl items-center gap-3 px-4">
            <Link
              to="/"
              className="flex min-w-0 items-center gap-2 rounded-md outline-none transition-smooth focus-visible:ring-2 focus-visible:ring-ring"
              data-ocid="nav.home_link"
            >
              <span className="flex size-8 shrink-0 items-center justify-center rounded-md bg-primary/15 text-primary">
                <Radar className="size-4" />
              </span>
              <span className="truncate font-display text-base font-semibold tracking-tight">
                {title ?? "Night Ops"}
              </span>
            </Link>
            {action && (
              <div className="ml-auto flex items-center gap-2">{action}</div>
            )}
          </div>
        </header>
      )}

      <main
        className={cn(
          "flex-1",
          fullBleed
            ? "relative flex min-h-0 flex-col"
            : "mx-auto w-full max-w-2xl px-4 py-6 pb-[calc(1.5rem+env(safe-area-inset-bottom))]",
        )}
      >
        {children}
      </main>

      {!fullBleed && (
        <footer className="border-t border-border bg-card/60 px-4 py-4 pb-[calc(1rem+env(safe-area-inset-bottom))]">
          <p className="mx-auto max-w-2xl text-center text-xs text-muted-foreground">
            © {new Date().getFullYear()}. Built with love using{" "}
            <a
              href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`}
              target="_blank"
              rel="noreferrer"
              className="text-primary underline-offset-4 hover:underline"
            >
              caffeine.ai
            </a>
          </p>
        </footer>
      )}
    </div>
  );
}
