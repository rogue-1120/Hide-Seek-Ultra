import { cn } from "@/lib/utils";
import type { PlayerView } from "@/types/game";
import { Trophy } from "lucide-react";

export interface WinnerCardProps {
  winners: PlayerView[];
  /** Headline describing the outcome. */
  headline: string;
  /** Supporting sentence explaining the end reason. */
  detail: string;
}

/** Outcome announcement with the winning players' identity colors. */
export function WinnerCard({ winners, headline, detail }: WinnerCardProps) {
  return (
    <section
      className="relative overflow-hidden rounded-2xl border border-primary/40 bg-card p-6 shadow-hud-panel"
      data-ocid="results.winner_card"
    >
      <div className="pointer-events-none absolute inset-0 bg-zone-glow" />
      <div className="relative flex flex-col items-center gap-4 text-center">
        <span className="flex size-14 items-center justify-center rounded-full bg-primary/15 text-primary glow-signal">
          <Trophy className="size-7" />
        </span>
        <h1 className="font-display text-2xl font-bold leading-tight tracking-tight">
          {headline}
        </h1>
        <p className="max-w-sm text-sm text-muted-foreground">{detail}</p>

        {winners.length > 0 && (
          <ul className="flex flex-wrap justify-center gap-2 pt-1">
            {winners.map((winner) => (
              <li
                key={String(winner.id)}
                className={cn(
                  "flex items-center gap-2 rounded-full border border-border bg-background/70 px-3 py-1.5",
                )}
              >
                <span
                  className="size-3 rounded-full ring-2 ring-background"
                  style={{ backgroundColor: winner.color }}
                  aria-hidden="true"
                />
                <span className="font-display text-sm font-semibold">
                  {winner.name}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
