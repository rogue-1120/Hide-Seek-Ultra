import type {
  AccessCode,
  Centimetres,
  ColorHex,
  EndReason,
  GameError,
  GameView,
  GeoPoint,
  LobbyId,
  LobbyPhase,
  MicroDegrees,
  PlayerId,
  PlayerPosition,
  PlayerView,
  RevealState,
  RevealedHider,
  Role,
  RpsChoice,
  RpsOutcome,
  RpsPlayerState,
  RpsState,
  Timestamp,
} from "@/backend";

/**
 * TypeScript mirrors of the backend game contract.
 *
 * The backend enums (`Role`, `LobbyPhase`, `RpsChoice`, `RpsOutcome`,
 * `EndReason`, `GameError`) are re-exported as *values* so components can
 * compare against `Role.hider`, `LobbyPhase.active`, etc. The interfaces are
 * re-exported as types only.
 */
export {
  EndReason,
  GameError,
  LobbyPhase,
  Role,
  RpsChoice,
  RpsOutcome,
} from "@/backend";

export type {
  AccessCode,
  Centimetres,
  ColorHex,
  GameView,
  GeoPoint,
  LobbyId,
  MicroDegrees,
  PlayerId,
  PlayerPosition,
  PlayerView,
  RevealState,
  RevealedHider,
  RpsPlayerState,
  RpsState,
  Timestamp,
};

/** A player's identity color slot, 1-6, matching `--player-N` tokens. */
export type PlayerColorSlot = 1 | 2 | 3 | 4 | 5 | 6;

/** The six selectable identity colors, in slot order. */
export const PLAYER_COLORS: readonly {
  slot: PlayerColorSlot;
  hex: ColorHex;
  label: string;
}[] = [
  { slot: 1, hex: "#3fd67f", label: "Signal" },
  { slot: 2, hex: "#5aa9ff", label: "Cobalt" },
  { slot: 3, hex: "#f06bd0", label: "Magenta" },
  { slot: 4, hex: "#f2b53c", label: "Amber" },
  { slot: 5, hex: "#ff6b5a", label: "Coral" },
  { slot: 6, hex: "#3fd0d6", label: "Cyan" },
] as const;

/** Resolve a hex color to its identity slot, or `null` when unknown. */
export function colorSlot(hex: ColorHex): PlayerColorSlot | null {
  const normalized = hex.trim().toLowerCase();
  const match = PLAYER_COLORS.find((c) => c.hex.toLowerCase() === normalized);
  return match ? match.slot : null;
}

/** A marker rendered on the game map. */
export interface MapMarker {
  id: string;
  lat: number;
  lng: number;
  color: string;
  label: string;
  isSelf?: boolean;
}

/** A geographic point in decimal degrees. */
export interface LatLng {
  lat: number;
  lng: number;
}
