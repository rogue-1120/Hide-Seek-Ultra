import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";

import HomePage from "@/pages/HomePage";

/**
 * Critical journey: the default route renders and a player can start the
 * create/join flow. The app must never show a blank screen on `/`, and the
 * join control must only enable once a full 6-character code is entered.
 */

const navigate = vi.fn();

vi.mock("@tanstack/react-router", () => ({
  useNavigate: () => navigate,
}));

describe("HomePage", () => {
  beforeEach(() => {
    navigate.mockReset();
  });

  it("renders the landing screen without a blank page", () => {
    render(<HomePage />);
    expect(
      screen.getByRole("heading", { name: /hide & seek/i }),
    ).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: /create lobby/i }),
    ).toBeInTheDocument();
  });

  it("routes to the new-lobby sentinel when creating a lobby", async () => {
    const user = userEvent.setup();
    render(<HomePage />);

    await user.click(screen.getByRole("button", { name: /create lobby/i }));

    expect(navigate).toHaveBeenCalledWith({
      to: "/lobby/$code",
      params: { code: "new" },
    });
  });

  it("keeps the join button disabled until six characters are entered", async () => {
    const user = userEvent.setup();
    render(<HomePage />);

    const join = screen.getByRole("button", { name: /join lobby/i });
    expect(join).toBeDisabled();

    await user.type(screen.getByLabelText(/join with code/i), "K7Q2M");

    expect(join).toBeDisabled();
    expect(screen.getByText(/enter all 6 characters/i)).toBeInTheDocument();
  });

  it("normalizes the code and routes to the lobby on join", async () => {
    const user = userEvent.setup();
    render(<HomePage />);

    await user.type(screen.getByLabelText(/join with code/i), "k7q2m9");
    await user.click(screen.getByRole("button", { name: /join lobby/i }));

    expect(navigate).toHaveBeenCalledWith({
      to: "/lobby/$code",
      params: { code: "K7Q2M9" },
    });
  });
});
