import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";

import type { GameActor } from "@/lib/backend";
import LobbyPage from "@/pages/LobbyPage";
import { type GameView, LobbyPhase, type PlayerView, Role } from "@/types/game";

/**
 * Critical journey: create a lobby, see the roster, pick a unique color, and
 * start the game. The actor and the polling hook are mocked locally, so this
 * exercises the real page component and its wiring, not the canister.
 *
 * The page only reveals the roster after a successful create/join, so each
 * roster test performs the join first — the same path a real player takes.
 */

const navigate = vi.fn();
const refresh = vi.fn();
const actor: GameActor = {
  createLobby: vi.fn(),
  joinLobby: vi.fn(),
  leaveLobby: vi.fn(),
  setReady: vi.fn(),
  setColor: vi.fn(),
  startGame: vi.fn(),
  chooseRps: vi.fn(),
  updatePosition: vi.fn(),
  catchHider: vi.fn(),
  resetGame: vi.fn(),
  endLobby: vi.fn(),
  getGameState: vi.fn(),
  syncGameState: vi.fn(),
};

let gameState: {
  game: GameView | null;
  isLoading: boolean;
  notInLobby: boolean;
};

vi.mock("@tanstack/react-router", () => ({
  useNavigate: () => navigate,
}));

vi.mock("@caffeineai/core-infrastructure", () => ({
  useActor: () => ({ actor, isFetching: false }),
}));

vi.mock("@/hooks/useGameState", () => ({
  useGameState: () => ({
    ...gameState,
    isFetching: false,
    error: null,
    refresh,
  }),
}));

function player(overrides: Partial<PlayerView> = {}): PlayerView {
  return {
    id: 1n,
    name: "Ada",
    color: "#3fd67f",
    role: Role.hider,
    isHost: false,
    isReady: false,
    isDisqualified: false,
    isCaught: false,
    isOriginalSeeker: false,
    ...overrides,
  };
}

function gameView(overrides: Partial<GameView> = {}): GameView {
  return {
    accessCode: "K7Q2M9",
    selfId: 1n,
    serverNow: 1_000_000_000n,
    players: [player()],
    lobbyId: 1n,
    phase: LobbyPhase.lobby,
    hostId: 1n,
    winnerIds: [],
    visiblePositions: [],
    ...overrides,
  };
}

/** Join the lobby through the real form so the roster view is reachable. */
async function joinLobby(user: ReturnType<typeof userEvent.setup>) {
  vi.mocked(actor.joinLobby).mockResolvedValue({
    __kind__: "ok",
    ok: { lobbyId: 1n, playerId: 1n },
  });
  await user.click(screen.getByRole("button", { name: /join lobby/i }));
  await waitFor(() => expect(actor.joinLobby).toHaveBeenCalled());
}

describe("LobbyPage", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    gameState = { game: null, isLoading: false, notInLobby: true };
  });

  it("creates a lobby and routes to its access code", async () => {
    const user = userEvent.setup();
    vi.mocked(actor.createLobby).mockResolvedValue({
      __kind__: "ok",
      ok: { lobbyId: 1n, accessCode: "K7Q2M9", playerId: 1n },
    });

    render(<LobbyPage code="new" />);

    await user.type(screen.getByLabelText(/callsign/i), "Ada");
    await user.click(screen.getByRole("button", { name: /create lobby/i }));

    await waitFor(() => {
      expect(actor.createLobby).toHaveBeenCalledWith("Ada", "#3fd67f");
    });
    expect(navigate).toHaveBeenCalledWith({
      to: "/lobby/$code",
      params: { code: "K7Q2M9" },
      replace: true,
    });
  });

  it("joins an existing lobby by code", async () => {
    const user = userEvent.setup();
    vi.mocked(actor.joinLobby).mockResolvedValue({
      __kind__: "ok",
      ok: { lobbyId: 1n, playerId: 2n },
    });

    render(<LobbyPage code="k7q2m9" />);

    await user.type(screen.getByLabelText(/callsign/i), "Bob");
    await user.click(screen.getByRole("button", { name: /join lobby/i }));

    await waitFor(() => {
      expect(actor.joinLobby).toHaveBeenCalledWith("K7Q2M9", "Bob", "#3fd67f");
    });
  });

  it("shows an error state when the code is invalid", async () => {
    const user = userEvent.setup();
    vi.mocked(actor.joinLobby).mockResolvedValue({
      __kind__: "err",
      err: "invalidCode",
    });

    render(<LobbyPage code="ZZZZZZ" />);

    await user.click(screen.getByRole("button", { name: /join lobby/i }));

    expect(await screen.findByText(/not valid/i)).toBeInTheDocument();
  });

  it("shows the access code and every joined player with their color", async () => {
    const user = userEvent.setup();
    gameState = {
      game: gameView({
        players: [
          player({ id: 1n, name: "Ada", isHost: true, isReady: true }),
          player({ id: 2n, name: "Bob", color: "#5aa9ff" }),
        ],
      }),
      isLoading: false,
      notInLobby: false,
    };

    render(<LobbyPage code="K7Q2M9" />);
    await joinLobby(user);

    expect(screen.getByText("K7Q2M9")).toBeInTheDocument();
    expect(screen.getByText("Ada")).toBeInTheDocument();
    expect(screen.getByText("Bob")).toBeInTheDocument();
    expect(screen.getByText("2/12")).toBeInTheDocument();
    expect(screen.getByText("Ready")).toBeInTheDocument();
  });

  it("disables colors taken by other players in the lobby", async () => {
    const user = userEvent.setup();
    gameState = {
      game: gameView({
        players: [
          player({ id: 1n, name: "Ada", isHost: true }),
          player({ id: 2n, name: "Bob", color: "#5aa9ff" }),
        ],
      }),
      isLoading: false,
      notInLobby: false,
    };

    render(<LobbyPage code="K7Q2M9" />);
    await joinLobby(user);

    expect(
      screen.getByRole("button", { name: "Cobalt — taken" }),
    ).toBeDisabled();
    expect(screen.getByRole("button", { name: "Choose Amber" })).toBeEnabled();
  });

  it("lets the host start once two players have joined", async () => {
    const user = userEvent.setup();
    vi.mocked(actor.startGame).mockResolvedValue({ __kind__: "ok", ok: null });
    gameState = {
      game: gameView({
        players: [
          player({ id: 1n, name: "Ada", isHost: true }),
          player({ id: 2n, name: "Bob", color: "#5aa9ff" }),
        ],
      }),
      isLoading: false,
      notInLobby: false,
    };

    render(<LobbyPage code="K7Q2M9" />);
    await joinLobby(user);

    const start = screen.getByRole("button", { name: /start game/i });
    expect(start).toBeEnabled();
    await user.click(start);

    await waitFor(() => expect(actor.startGame).toHaveBeenCalled());
  });

  it("keeps the host's start button disabled with only one player", async () => {
    const user = userEvent.setup();
    gameState = {
      game: gameView({
        players: [player({ id: 1n, name: "Ada", isHost: true })],
      }),
      isLoading: false,
      notInLobby: false,
    };

    render(<LobbyPage code="K7Q2M9" />);
    await joinLobby(user);

    expect(screen.getByRole("button", { name: /start game/i })).toBeDisabled();
    expect(screen.getByText(/need at least 2 players/i)).toBeInTheDocument();
  });

  it("shows a waiting message to non-host players", async () => {
    const user = userEvent.setup();
    gameState = {
      game: gameView({
        selfId: 2n,
        hostId: 1n,
        players: [
          player({ id: 1n, name: "Ada", isHost: true }),
          player({ id: 2n, name: "Bob", color: "#5aa9ff" }),
        ],
      }),
      isLoading: false,
      notInLobby: false,
    };

    render(<LobbyPage code="K7Q2M9" />);
    await joinLobby(user);

    expect(
      screen.getByText(/waiting for the host to start/i),
    ).toBeInTheDocument();
    expect(
      screen.queryByRole("button", { name: /start game/i }),
    ).not.toBeInTheDocument();
  });

  it("sends a color change to the backend", async () => {
    const user = userEvent.setup();
    vi.mocked(actor.setColor).mockResolvedValue({ __kind__: "ok", ok: null });
    gameState = {
      game: gameView({
        players: [player({ id: 1n, name: "Ada", isHost: true })],
      }),
      isLoading: false,
      notInLobby: false,
    };

    render(<LobbyPage code="K7Q2M9" />);
    await joinLobby(user);

    await user.click(screen.getByRole("button", { name: "Choose Amber" }));

    await waitFor(() => expect(actor.setColor).toHaveBeenCalledWith("#f2b53c"));
  });

  it("toggles ready state through the backend", async () => {
    const user = userEvent.setup();
    vi.mocked(actor.setReady).mockResolvedValue({ __kind__: "ok", ok: null });
    gameState = {
      game: gameView({
        players: [player({ id: 1n, name: "Ada", isHost: true })],
      }),
      isLoading: false,
      notInLobby: false,
    };

    render(<LobbyPage code="K7Q2M9" />);
    await joinLobby(user);

    await user.click(screen.getByRole("switch", { name: /ready to play/i }));

    await waitFor(() => expect(actor.setReady).toHaveBeenCalledWith(true));
  });
});
