import { createActor } from "@/backend";
import { GameMap } from "@/components/GameMap";
import { HudPanel } from "@/components/game/HudPanel";
import { PlayerRoster } from "@/components/game/PlayerRoster";
import { RpsPicker } from "@/components/game/RpsPicker";
import { Button } from "@/components/ui/button";
import { useGameState } from "@/hooks/useGameState";
import { useGeolocation } from "@/hooks/useGeolocation";
import { gameApi, gameErrorMessage } from "@/lib/backend";
import {
  cmToMetres,
  formatCountdown,
  formatDistance,
  haversineMetres,
  pointToLatLng,
} from "@/lib/geo";
import { cn } from "@/lib/utils";
import {
  type LatLng,
  LobbyPhase,
  type MapMarker,
  type PlayerPosition,
  Role,
} from "@/types/game";
import { useActor } from "@caffeineai/core-infrastructure";
import { useNavigate } from "@tanstack/react-router";
import {
  AlertTriangle,
  Clock,
  Crosshair,
  Eye,
  Hand,
  Snowflake,
  Target,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";

const ZONE_RADIUS_M = 500;
const CATCH_RANGE_M = 3;
const FREEZE_RANGE_M = 10;
const SEEKER_STAY_PUT_M = 0.9144; // 3 feet

export interface GamePageProps {
  /** The `:code` route param. */
  code: string;
}

/** Main gameplay screen: live map, HUD, RPS picker, and catch control. */
export default function GamePage({ code }: GamePageProps) {
  const navigate = useNavigate();
  const { actor } = useActor(createActor);
  const { game, isLoading, notInLobby, refresh } = useGameState();
  const geo = useGeolocation(true);

  const [now, setNow] = useState(() => Date.now());
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Local clock for countdowns between polls.
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);

  // Leave for the results screen once the game ends.
  useEffect(() => {
    if (game?.phase === LobbyPhase.ended) {
      void navigate({
        to: "/results/$code",
        params: { code: game.accessCode || code },
      });
    }
  }, [game, code, navigate]);

  const self = game?.players.find((p) => p.id === game?.selfId) ?? null;
  const isSeeker = self?.role === Role.seeker;
  const startPoint = useMemo(
    () => (game?.startPoint ? pointToLatLng(game.startPoint) : null),
    [game?.startPoint],
  );

  const selfLatLng: LatLng | null = geo.position
    ? { lat: geo.position.lat, lng: geo.position.lng }
    : game?.selfPosition
      ? pointToLatLng(game.selfPosition.point)
      : null;

  const distanceFromStartM = useMemo(() => {
    if (!startPoint || !selfLatLng) return null;
    return haversineMetres(startPoint, selfLatLng);
  }, [startPoint, selfLatLng]);

  const outOfZone =
    distanceFromStartM !== null && distanceFromStartM > ZONE_RADIUS_M;

  // Nearest catchable hider, computed from backend-visible positions when the
  // seeker has them (reveal windows). Outside a reveal the backend returns no
  // hider coordinates, so the catch control falls back to the roster and lets
  // the backend validate the 3m rule.
  const nearestHider = useMemo(() => {
    if (!selfLatLng || !game) return null;
    let best: { position: PlayerPosition; distance: number } | null = null;
    for (const position of game.visiblePositions) {
      if (position.playerId === game.selfId) continue;
      const player = game.players.find((p) => p.id === position.playerId);
      if (!player || player.role !== Role.hider || player.isDisqualified) {
        continue;
      }
      const distance = haversineMetres(
        selfLatLng,
        pointToLatLng(position.point),
      );
      if (!best || distance < best.distance) {
        best = { position, distance };
      }
    }
    return best;
  }, [game, selfLatLng]);

  // Every hider still in play, from the full roster — independent of whether
  // their position is currently visible to this player.
  const catchableHiders = useMemo(() => {
    if (!game) return [];
    return game.players.filter(
      (p) => p.role === Role.hider && !p.isDisqualified,
    );
  }, [game]);

  const seekerPosition = useMemo(() => {
    if (!game || isSeeker) return null;
    const entry = game.visiblePositions.find((position) => {
      const player = game.players.find((p) => p.id === position.playerId);
      return player?.role === Role.seeker;
    });
    return entry ? pointToLatLng(entry.point) : null;
  }, [game, isSeeker]);

  const seekerDistanceM = useMemo(() => {
    if (!selfLatLng || !seekerPosition) return null;
    return haversineMetres(selfLatLng, seekerPosition);
  }, [selfLatLng, seekerPosition]);

  const markers = useMemo<MapMarker[]>(() => {
    if (!game) return [];
    const list: MapMarker[] = [];
    for (const position of game.visiblePositions) {
      const player = game.players.find((p) => p.id === position.playerId);
      if (!player) continue;
      const point = pointToLatLng(position.point);
      list.push({
        id: String(player.id),
        lat: point.lat,
        lng: point.lng,
        color: player.color,
        label: player.name,
        isSelf: player.id === game.selfId,
      });
    }
    if (selfLatLng && !list.some((marker) => marker.isSelf)) {
      list.push({
        id: "self",
        lat: selfLatLng.lat,
        lng: selfLatLng.lng,
        color: self?.color ?? "#3fd67f",
        label: "You",
        isSelf: true,
      });
    }
    return list;
  }, [game, selfLatLng, self]);

  const mapCenter: LatLng = selfLatLng ??
    startPoint ?? { lat: 51.5074, lng: -0.1278 };

  const serverOffsetMs = game ? Number(game.serverNow) / 1_000_000 - now : 0;
  const serverNowMs = now + serverOffsetMs;

  const waitRemainingMs = game?.waitEndsAt
    ? Number(game.waitEndsAt) / 1_000_000 - serverNowMs
    : null;
  const gameRemainingMs = game?.endsAt
    ? Number(game.endsAt) / 1_000_000 - serverNowMs
    : null;

  const reveal = game?.reveal ?? null;
  const revealActive = reveal?.active ?? false;
  const nextRevealMs = reveal?.nextRevealAt
    ? Number(reveal.nextRevealAt) / 1_000_000 - serverNowMs
    : null;

  const seekerMovedTooFar =
    isSeeker &&
    game?.phase === LobbyPhase.waiting &&
    distanceFromStartM !== null &&
    distanceFromStartM > SEEKER_STAY_PUT_M;

  const freezeWarning =
    !isSeeker && seekerDistanceM !== null && seekerDistanceM <= FREEZE_RANGE_M;

  const canCatch =
    isSeeker && game?.phase === LobbyPhase.active && catchableHiders.length > 0;

  const handleChoose = async (
    choice: Parameters<typeof gameApi.chooseRps>[1],
  ) => {
    if (!actor) return;
    setPending(true);
    const result = await gameApi.chooseRps(actor, choice);
    setPending(false);
    if (!result.ok) setError(gameErrorMessage(result.error));
    else refresh();
  };

  const handleCatch = async () => {
    const targetId = nearestHider?.position.playerId ?? catchableHiders[0]?.id;
    if (!actor || targetId === undefined) return;
    setPending(true);
    const result = await gameApi.catchHider(actor, targetId);
    setPending(false);
    if (!result.ok) setError(gameErrorMessage(result.error));
    else refresh();
  };

  if (isLoading) {
    return (
      <div
        className="flex flex-1 items-center justify-center bg-background"
        data-ocid="game.loading_state"
      >
        <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
          Acquiring signal…
        </span>
      </div>
    );
  }

  if (!game) {
    return (
      <div
        className="flex flex-1 flex-col items-center justify-center gap-4 bg-background px-6 text-center"
        data-ocid="game.not_in_lobby"
      >
        <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
          {notInLobby ? "No active game" : "Signal lost"}
        </span>
        <p className="max-w-xs text-sm text-muted-foreground">
          {notInLobby
            ? "You are not in a lobby right now. Create or join one to play."
            : "We could not load the game state. Try again from home."}
        </p>
        <Button
          type="button"
          className="rounded-full"
          onClick={() => void navigate({ to: "/" })}
          data-ocid="game.home_button"
        >
          Back to home
        </Button>
      </div>
    );
  }

  const countdownLabel =
    game.phase === LobbyPhase.waiting
      ? "Seeker wait"
      : game.phase === LobbyPhase.active
        ? "Time left"
        : "Phase";
  const countdownValue =
    game.phase === LobbyPhase.waiting && waitRemainingMs !== null
      ? formatCountdown(waitRemainingMs)
      : gameRemainingMs !== null
        ? formatCountdown(gameRemainingMs)
        : "--:--";

  return (
    <div className="relative flex flex-1 flex-col" data-ocid="game.page">
      <div className="absolute inset-0">
        <GameMap
          center={mapCenter}
          zoom={17}
          markers={markers}
          boundaryRadiusM={startPoint ? ZONE_RADIUS_M : undefined}
          boundaryCenter={startPoint ?? undefined}
        />
      </div>

      {/* Top HUD */}
      <div className="pointer-events-none relative z-10 flex flex-col gap-2 p-3 pt-[calc(0.75rem+env(safe-area-inset-top))]">
        <div className="flex items-start justify-between gap-2">
          <HudPanel
            label={countdownLabel}
            value={countdownValue}
            icon={<Clock className="size-3" />}
            tone={game.phase === LobbyPhase.active ? "live" : "default"}
          />
          <HudPanel
            label="From start"
            value={
              distanceFromStartM === null
                ? "—"
                : formatDistance(distanceFromStartM)
            }
            hint={`Zone ${ZONE_RADIUS_M}m`}
            icon={<Crosshair className="size-3" />}
            tone={outOfZone ? "danger" : "default"}
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <span
            className={cn(
              "rounded-full border px-2.5 py-1 font-mono text-[10px] uppercase tracking-widest",
              isSeeker
                ? "border-accent/60 bg-accent/15 text-accent"
                : "border-border bg-card/90 text-muted-foreground",
            )}
            data-ocid="game.role_badge"
          >
            {isSeeker ? "Seeker" : "Hider"}
          </span>
          {self?.isOriginalSeeker && (
            <span className="rounded-full border border-warning/60 bg-warning/15 px-2.5 py-1 font-mono text-[10px] uppercase tracking-widest text-warning">
              Original seeker
            </span>
          )}
          {self?.isDisqualified && (
            <span className="rounded-full border border-destructive/60 bg-destructive/15 px-2.5 py-1 font-mono text-[10px] uppercase tracking-widest text-destructive">
              Out of zone
            </span>
          )}
          {self?.isCaught && !self.isDisqualified && (
            <span className="rounded-full border border-accent/60 bg-accent/15 px-2.5 py-1 font-mono text-[10px] uppercase tracking-widest text-accent">
              Caught
            </span>
          )}
          {!isSeeker && revealActive && (
            <span
              className="flex items-center gap-1 rounded-full border border-primary/60 bg-primary/15 px-2.5 py-1 font-mono text-[10px] uppercase tracking-widest text-primary"
              data-ocid="game.reveal_state"
            >
              <Eye className="size-3" />
              Seeker can see you
            </span>
          )}
          {!isSeeker && !revealActive && nextRevealMs !== null && (
            <span
              className="rounded-full border border-border bg-card/90 px-2.5 py-1 font-mono text-[10px] uppercase tracking-widest text-muted-foreground"
              data-ocid="game.reveal_state"
            >
              Next reveal {formatCountdown(nextRevealMs)}
            </span>
          )}
        </div>

        {outOfZone && (
          <p
            className="flex items-center gap-2 rounded-xl border border-accent/60 bg-accent/15 px-3 py-2 font-mono text-[11px] uppercase tracking-wider text-accent"
            data-ocid="game.zone_warning"
          >
            <AlertTriangle className="size-4 shrink-0" />
            Outside the {ZONE_RADIUS_M}m zone — return now
          </p>
        )}

        {seekerMovedTooFar && (
          <p
            className="flex items-center gap-2 rounded-xl border border-warning/60 bg-warning/15 px-3 py-2 font-mono text-[11px] uppercase tracking-wider text-warning"
            data-ocid="game.stay_put_warning"
          >
            <AlertTriangle className="size-4 shrink-0" />
            Stay put — you moved more than 3 ft
          </p>
        )}

        {freezeWarning && (
          <p
            className="flex items-center gap-2 rounded-xl border border-warning/60 bg-warning/15 px-3 py-2 font-mono text-[11px] uppercase tracking-wider text-warning"
            data-ocid="game.freeze_warning"
          >
            <Snowflake className="size-4 shrink-0" />
            Freeze — seeker within {FREEZE_RANGE_M}m
          </p>
        )}

        {geo.error && (
          <p
            className="rounded-xl border border-border bg-card/90 px-3 py-2 text-[11px] text-muted-foreground"
            data-ocid="game.geo_error"
          >
            {geo.error}
          </p>
        )}
      </div>

      {/* Bottom sheet: phase controls and roster */}
      <div className="relative z-10 mt-auto flex flex-col gap-3 p-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]">
        {game.phase === LobbyPhase.rps && game.rps && (
          <RpsPicker
            rps={game.rps}
            selfId={game.selfId}
            pending={pending}
            onChoose={(choice) => void handleChoose(choice)}
          />
        )}

        {game.phase === LobbyPhase.waiting && (
          <div
            className="rounded-2xl border border-border bg-card/95 p-4 shadow-hud-panel backdrop-blur"
            data-ocid="game.waiting_panel"
          >
            <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
              {isSeeker ? "Your head start" : "Hiders, get moving"}
            </p>
            <p className="mt-1 text-sm text-muted-foreground">
              {isSeeker
                ? "Hold your start point. Moving more than 3 feet before the countdown ends is a foul."
                : "The seeker is holding position. Spread out and stay inside the zone."}
            </p>
          </div>
        )}

        {game.phase === LobbyPhase.active && (
          <div className="flex flex-col gap-2">
            {isSeeker && (
              <Button
                type="button"
                size="lg"
                disabled={!canCatch || pending}
                onClick={() => void handleCatch()}
                className="h-14 w-full rounded-full bg-gradient-danger text-base font-semibold uppercase tracking-wider text-destructive-foreground"
                data-ocid="game.catch_button"
              >
                <Target className="size-5" />
                {canCatch && nearestHider
                  ? `Catch (${formatDistance(nearestHider.distance)})`
                  : `Catch (${CATCH_RANGE_M}m)`}
              </Button>
            )}
            {isSeeker && !canCatch && (
              <p
                className="text-center text-xs text-muted-foreground"
                data-ocid="game.catch_hint"
              >
                No hider left to catch.
              </p>
            )}
            {!isSeeker && (
              <p
                className="flex items-center justify-center gap-2 rounded-xl border border-border bg-card/90 px-3 py-2 font-mono text-[11px] uppercase tracking-wider text-muted-foreground"
                data-ocid="game.hider_hint"
              >
                <Hand className="size-4" />
                Stay hidden — survive to the horn
              </p>
            )}
          </div>
        )}

        {error && (
          <p
            className="rounded-lg border border-destructive/50 bg-destructive/10 px-3 py-2 text-center text-xs text-destructive"
            data-ocid="game.error_message"
          >
            {error}
          </p>
        )}

        <details
          className="rounded-2xl border border-border bg-card/95 shadow-hud-panel backdrop-blur"
          data-ocid="game.roster.panel"
        >
          <summary className="cursor-pointer list-none px-4 py-3 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            Roster · {game.players.length} players
          </summary>
          <div className="px-3 pb-3">
            <PlayerRoster players={game.players} selfId={game.selfId} />
          </div>
        </details>
      </div>
    </div>
  );
}
