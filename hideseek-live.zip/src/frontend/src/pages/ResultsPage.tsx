import { createActor } from "@/backend";
import { WinnerCard } from "@/components/results/WinnerCard";
import { Button } from "@/components/ui/button";
import { useGameState } from "@/hooks/useGameState";
import { gameApi, gameErrorMessage } from "@/lib/backend";
import { cn } from "@/lib/utils";
import { EndReason, LobbyPhase, type PlayerView, Role } from "@/types/game";
import { useActor } from "@caffeineai/core-infrastructure";
import { useNavigate } from "@tanstack/react-router";
import { LogOut, RotateCcw } from "lucide-react";
import { useEffect, useState } from "react";

export interface ResultsPageProps {
  /** The `:code` route param. */
  code: string;
}

const END_COPY: Record<EndReason, { headline: string; detail: string }> = {
  [EndReason.allHidersCaught]: {
    headline: "All hiders caught",
    detail: "The seekers swept the zone clean before the hour was up.",
  },
  [EndReason.timeExpired]: {
    headline: "Time expired",
    detail: "The horn sounded with hiders still in play — they survive.",
  },
  [EndReason.hostEnded]: {
    headline: "Lobby ended",
    detail: "The host closed the round early.",
  },
};

/** Winner announcement with host reset/end controls. */
export default function ResultsPage({ code }: ResultsPageProps) {
  const navigate = useNavigate();
  const { actor } = useActor(createActor);
  const { game, isLoading, notInLobby } = useGameState();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // When the host resets, the phase returns to the lobby — every player,
  // host or not, should follow it back to the lobby screen.
  useEffect(() => {
    if (game?.phase === LobbyPhase.lobby) {
      void navigate({
        to: "/lobby/$code",
        params: { code: game.accessCode || code },
      });
    }
  }, [game, code, navigate]);

  const self = game?.players.find((p) => p.id === game?.selfId) ?? null;
  const isHost = self?.isHost ?? false;

  const winners: PlayerView[] = game
    ? game.players.filter((p) => game.winnerIds.includes(p.id))
    : [];

  const reason = game?.endReason ?? null;
  const copy = reason ? END_COPY[reason] : null;

  const headline = copy?.headline ?? "Round over";
  const detail = copy?.detail ?? "The round has finished.";

  const handleReset = async () => {
    if (!actor) return;
    setPending(true);
    const result = await gameApi.resetGame(actor);
    setPending(false);
    if (!result.ok) {
      setError(gameErrorMessage(result.error));
      return;
    }
    void navigate({
      to: "/lobby/$code",
      params: { code: game?.accessCode ?? code },
    });
  };

  const handleEnd = async () => {
    if (!actor) return;
    setPending(true);
    const result = await gameApi.endLobby(actor);
    setPending(false);
    if (!result.ok) {
      setError(gameErrorMessage(result.error));
      return;
    }
    void navigate({ to: "/" });
  };

  const handleLeave = async () => {
    if (!actor) return;
    setPending(true);
    setError(null);
    // The backend only accepts a leave during the lobby phase. If the game has
    // already ended the call fails, so surface it instead of navigating home
    // while the player is still bound to the lobby.
    const result = await gameApi.leaveLobby(actor);
    setPending(false);
    if (!result.ok) {
      setError(gameErrorMessage(result.error));
      return;
    }
    void navigate({ to: "/" });
  };

  if (isLoading) {
    return (
      <div
        className="flex flex-col items-center gap-3 py-20 text-center"
        data-ocid="results.loading_state"
      >
        <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
          Tallying the round…
        </span>
      </div>
    );
  }

  if (!game) {
    return (
      <div
        className="flex flex-col items-center gap-4 py-20 text-center"
        data-ocid="results.not_in_lobby"
      >
        <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
          {notInLobby ? "No round to show" : "Signal lost"}
        </span>
        <p className="max-w-xs text-sm text-muted-foreground">
          {notInLobby
            ? "You are not in a lobby right now. Create or join one to play."
            : "We could not load the round result. Try again from home."}
        </p>
        <Button
          type="button"
          className="rounded-full"
          onClick={() => void navigate({ to: "/" })}
          data-ocid="results.home_button"
        >
          Back to home
        </Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6" data-ocid="results.page">
      <WinnerCard winners={winners} headline={headline} detail={detail} />

      <section className="flex flex-col gap-3">
        <h2 className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
          Final states
        </h2>
        <ul className="flex flex-col gap-2" data-ocid="results.players.list">
          {game.players.map((player, index) => {
            const isWinner = game.winnerIds.includes(player.id);
            return (
              <li
                key={String(player.id)}
                className={cn(
                  "flex items-center gap-3 rounded-xl border border-border bg-card/70 px-3 py-3",
                  isWinner && "border-primary/50 bg-primary/5",
                )}
                data-ocid={`results.player.item.${index + 1}`}
              >
                <span
                  className="size-4 shrink-0 rounded-full ring-2 ring-background"
                  style={{ backgroundColor: player.color }}
                  aria-hidden="true"
                />
                <div className="flex min-w-0 flex-1 flex-col">
                  <span className="truncate font-display text-sm font-semibold">
                    {player.name}
                    {player.id === game.selfId && (
                      <span className="ml-1.5 font-mono text-[10px] uppercase tracking-widest text-primary">
                        You
                      </span>
                    )}
                  </span>
                  <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                    {player.role === Role.seeker ? "Seeker" : "Hider"}
                    {player.isOriginalSeeker ? " · original" : ""}
                  </span>
                </div>
                <span
                  className={cn(
                    "shrink-0 rounded-full px-2 py-1 font-mono text-[10px] uppercase tracking-wider",
                    isWinner
                      ? "bg-primary/15 text-primary"
                      : player.isDisqualified
                        ? "bg-destructive/15 text-destructive"
                        : "bg-muted text-muted-foreground",
                  )}
                >
                  {isWinner
                    ? "Winner"
                    : player.isDisqualified
                      ? "Out of zone"
                      : player.isCaught
                        ? "Caught"
                        : "Survived"}
                </span>
              </li>
            );
          })}
        </ul>
      </section>

      {error && (
        <p
          className="rounded-lg border border-destructive/50 bg-destructive/10 px-3 py-2 text-center text-xs text-destructive"
          data-ocid="results.error_message"
        >
          {error}
        </p>
      )}

      {isHost ? (
        <div className="flex flex-col gap-2">
          <Button
            type="button"
            size="lg"
            disabled={pending}
            onClick={() => void handleReset()}
            className="h-14 w-full rounded-full text-base font-semibold uppercase tracking-wider"
            data-ocid="results.reset_game_button"
          >
            <RotateCcw className="size-5" />
            Reset game
          </Button>
          <Button
            type="button"
            variant="secondary"
            size="lg"
            disabled={pending}
            onClick={() => void handleEnd()}
            className="h-12 w-full rounded-full uppercase tracking-wider"
            data-ocid="results.end_lobby_button"
          >
            <LogOut className="size-4" />
            End lobby
          </Button>
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          <p
            className="rounded-xl border border-border bg-card/60 px-4 py-3 text-center text-sm text-muted-foreground"
            data-ocid="results.waiting_for_host"
          >
            Waiting for the host to reset or end the lobby…
          </p>
          <Button
            type="button"
            variant="ghost"
            onClick={() => void handleLeave()}
            className="h-12 w-full rounded-full uppercase tracking-wider text-muted-foreground"
            data-ocid="results.leave_button"
          >
            <LogOut className="size-4" />
            Leave
          </Button>
        </div>
      )}
    </div>
  );
}
