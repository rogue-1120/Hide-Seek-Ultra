import { createActor } from "@/backend";
import { ColorPicker } from "@/components/lobby/ColorPicker";
import { PlayerRow } from "@/components/lobby/PlayerRow";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { useGameState } from "@/hooks/useGameState";
import { gameApi, gameErrorMessage } from "@/lib/backend";
import { cn } from "@/lib/utils";
import { type ColorHex, LobbyPhase, PLAYER_COLORS } from "@/types/game";
import { useActor } from "@caffeineai/core-infrastructure";
import { useNavigate } from "@tanstack/react-router";
import { LogOut, Play, Users } from "lucide-react";
import { useEffect, useRef, useState } from "react";

const MIN_PLAYERS = 2;
const MAX_PLAYERS = 12;

export interface LobbyPageProps {
  /** The `:code` route param — either a real access code or the `new` sentinel. */
  code: string;
}

/**
 * Lobby screen: creates or joins a lobby, then shows the live roster, color
 * picker, ready toggle, and the host's start control.
 */
export default function LobbyPage({ code }: LobbyPageProps) {
  const navigate = useNavigate();
  const { actor } = useActor(createActor);
  const { game, isLoading, notInLobby, refresh } = useGameState();

  const isNew = code.toLowerCase() === "new";
  const [name, setName] = useState("");
  const [color, setColor] = useState<ColorHex>(PLAYER_COLORS[0].hex);
  const [joined, setJoined] = useState(false);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const joinAttempted = useRef(false);

  // Create or join exactly once per code, using the callsign captured at the
  // moment the player confirms — never a stale value from an earlier render.
  const handleJoin = async () => {
    if (!actor || joinAttempted.current) return;
    joinAttempted.current = true;

    setPending(true);
    setError(null);
    const trimmed = name.trim();

    if (isNew) {
      const result = await gameApi.createLobby(actor, trimmed || "Host", color);
      setPending(false);
      if (!result.ok) {
        joinAttempted.current = false;
        setError(gameErrorMessage(result.error));
        return;
      }
      setJoined(true);
      void navigate({
        to: "/lobby/$code",
        params: { code: result.value.accessCode },
        replace: true,
      });
      return;
    }

    const result = await gameApi.joinLobby(
      actor,
      code.toUpperCase(),
      trimmed || "Player",
      color,
    );
    setPending(false);
    if (!result.ok) {
      joinAttempted.current = false;
      setError(gameErrorMessage(result.error));
      return;
    }
    setJoined(true);
    refresh();
  };

  // Leave the lobby screen as soon as the game moves past the lobby phase.
  useEffect(() => {
    if (game && game.phase !== LobbyPhase.lobby) {
      void navigate({ to: "/game/$code", params: { code: game.accessCode } });
    }
  }, [game, navigate]);

  const players = game?.players ?? [];
  const self = players.find((p) => p.id === game?.selfId) ?? null;
  const isHost = self?.isHost ?? false;
  const takenColors = players
    .filter((p) => p.id !== game?.selfId)
    .map((p) => p.color);
  const canStart =
    isHost && players.length >= MIN_PLAYERS && players.length <= MAX_PLAYERS;

  const handleColor = async (hex: ColorHex) => {
    setColor(hex);
    if (!actor || !joined) return;
    const result = await gameApi.setColor(actor, hex);
    if (!result.ok) setError(gameErrorMessage(result.error));
    else refresh();
  };

  const handleReady = async (ready: boolean) => {
    if (!actor) return;
    const result = await gameApi.setReady(actor, ready);
    if (!result.ok) setError(gameErrorMessage(result.error));
    else refresh();
  };

  const handleStart = async () => {
    if (!actor) return;
    setPending(true);
    const result = await gameApi.startGame(actor);
    setPending(false);
    if (!result.ok) setError(gameErrorMessage(result.error));
    else refresh();
  };

  const handleLeave = async () => {
    if (actor) await gameApi.leaveLobby(actor);
    void navigate({ to: "/" });
  };

  if (error && !joined) {
    return (
      <div
        className="flex flex-col items-center gap-4 py-16 text-center"
        data-ocid="lobby.error_state"
      >
        <h1 className="font-display text-xl font-bold">Lobby unavailable</h1>
        <p className="max-w-xs text-sm text-muted-foreground">{error}</p>
        <Button
          type="button"
          className="rounded-full"
          data-ocid="lobby.retry_button"
          onClick={() => void navigate({ to: "/" })}
        >
          Back to home
        </Button>
      </div>
    );
  }

  // Pre-join: collect the callsign and color before creating/joining, so the
  // name the player typed is the one sent to the backend.
  if (!joined) {
    return (
      <div className="flex flex-col gap-6" data-ocid="lobby.join_form">
        <section className="relative overflow-hidden rounded-2xl border border-border bg-card p-5 shadow-hud-panel">
          <div className="pointer-events-none absolute inset-0 bg-zone-glow" />
          <div className="relative flex flex-col items-center gap-2">
            <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
              {isNew ? "New lobby" : "Joining lobby"}
            </span>
            <span className="code-plate text-4xl font-bold text-primary">
              {isNew ? "NEW" : code.toUpperCase()}
            </span>
          </div>
        </section>

        <section className="flex flex-col gap-3 rounded-2xl border border-border bg-card/70 p-4">
          <Label
            htmlFor="callsign"
            className="font-mono text-xs uppercase tracking-widest text-muted-foreground"
          >
            Callsign
          </Label>
          <Input
            id="callsign"
            value={name}
            onChange={(event) => setName(event.target.value)}
            placeholder="Your name"
            maxLength={20}
            autoComplete="off"
            data-ocid="lobby.name_input"
            className="h-12 rounded-xl bg-background"
          />

          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
            Identity color
          </span>
          <ColorPicker
            selected={color}
            taken={[]}
            onSelect={(hex) => setColor(hex)}
          />
        </section>

        {error && (
          <p
            className="rounded-lg border border-destructive/50 bg-destructive/10 px-3 py-2 text-center text-xs text-destructive"
            data-ocid="lobby.error_message"
          >
            {error}
          </p>
        )}

        <Button
          type="button"
          size="lg"
          disabled={pending || !actor}
          onClick={() => void handleJoin()}
          className="h-14 w-full rounded-full text-base font-semibold uppercase tracking-wider"
          data-ocid="lobby.join_button"
        >
          <Play className="size-5" />
          {isNew ? "Create lobby" : "Join lobby"}
        </Button>
      </div>
    );
  }

  if (isLoading || pending || (!game && !notInLobby)) {
    return (
      <div className="flex flex-col gap-4" data-ocid="lobby.loading_state">
        <Skeleton className="h-28 w-full rounded-2xl" />
        <Skeleton className="h-14 w-full rounded-xl" />
        <Skeleton className="h-14 w-full rounded-xl" />
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6" data-ocid="lobby.page">
      <section className="relative overflow-hidden rounded-2xl border border-border bg-card p-5 shadow-hud-panel">
        <div className="pointer-events-none absolute inset-0 bg-zone-glow" />
        <div className="relative flex flex-col items-center gap-2">
          <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            Lobby code
          </span>
          <span
            className="code-plate text-4xl font-bold text-primary"
            data-ocid="lobby.access_code"
          >
            {game?.accessCode ?? code.toUpperCase()}
          </span>
          <p className="text-center text-xs text-muted-foreground">
            Share this code — anyone with it joins instantly.
          </p>
        </div>
      </section>

      <section className="flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Users className="size-4" />
            <h2 className="font-mono text-xs uppercase tracking-widest">
              Players
            </h2>
          </div>
          <span
            className="numeric-readout text-sm text-muted-foreground"
            data-ocid="lobby.player_count"
          >
            {players.length}/{MAX_PLAYERS}
          </span>
        </div>

        {players.length === 0 ? (
          <p
            className="rounded-xl border border-dashed border-border px-4 py-6 text-center text-sm text-muted-foreground"
            data-ocid="lobby.players.empty_state"
          >
            Waiting for players to join…
          </p>
        ) : (
          <ul className="flex flex-col gap-2" data-ocid="lobby.players.list">
            {players.map((player, index) => (
              <PlayerRow
                key={String(player.id)}
                player={player}
                isSelf={player.id === game?.selfId}
                index={index}
              />
            ))}
          </ul>
        )}
      </section>

      <section className="flex flex-col gap-3 rounded-2xl border border-border bg-card/70 p-4">
        <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
          Identity color
        </span>
        <ColorPicker
          selected={self?.color ?? color}
          taken={takenColors}
          onSelect={(hex) => void handleColor(hex)}
        />

        <div className="flex items-center justify-between rounded-xl border border-border bg-background/60 px-3 py-3">
          <Label
            htmlFor="ready-toggle"
            className="font-mono text-xs uppercase tracking-widest text-muted-foreground"
          >
            Ready to play
          </Label>
          <Switch
            id="ready-toggle"
            checked={self?.isReady ?? false}
            onCheckedChange={(checked) => void handleReady(checked)}
            data-ocid="lobby.ready_toggle"
          />
        </div>
      </section>

      {error && (
        <p
          className="rounded-lg border border-destructive/50 bg-destructive/10 px-3 py-2 text-center text-xs text-destructive"
          data-ocid="lobby.error_message"
        >
          {error}
        </p>
      )}

      <div className="flex flex-col gap-2">
        {isHost ? (
          <>
            <Button
              type="button"
              size="lg"
              disabled={!canStart || pending}
              onClick={() => void handleStart()}
              className="h-14 w-full rounded-full text-base font-semibold uppercase tracking-wider"
              data-ocid="lobby.start_game_button"
            >
              <Play className="size-5" />
              Start game
            </Button>
            {!canStart && (
              <p
                className="text-center text-xs text-muted-foreground"
                data-ocid="lobby.start_hint"
              >
                {players.length < MIN_PLAYERS
                  ? `Need at least ${MIN_PLAYERS} players to start.`
                  : "Ready to start."}
              </p>
            )}
          </>
        ) : (
          <p
            className="rounded-xl border border-border bg-card/60 px-4 py-3 text-center text-sm text-muted-foreground"
            data-ocid="lobby.waiting_for_host"
          >
            Waiting for the host to start the game…
          </p>
        )}

        <Button
          type="button"
          variant="ghost"
          onClick={() => void handleLeave()}
          className={cn(
            "h-12 w-full rounded-full uppercase tracking-wider text-muted-foreground",
          )}
          data-ocid="lobby.leave_button"
        >
          <LogOut className="size-4" />
          Leave lobby
        </Button>
      </div>
    </div>
  );
}
