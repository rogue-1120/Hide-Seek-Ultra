import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";

import type { GameActor } from "@/lib/backend";
import GamePage from "@/pages/GamePage";
import {
  EndReason,
  type GameView,
  LobbyPhase,
  type PlayerPosition,
  type PlayerView,
  Role,
  RpsChoice,
  RpsOutcome,
} from "@/types/game";

/**
 * Critical journey: the gameplay screen. The actor, the polling hook, and the
 * geolocation hook are mocked locally, so this exercises the real page's
 * visibility rules, warnings, and catch gating against controlled positions.
 */

const navigate = vi.fn();
const refresh = vi.fn();
const actor: GameActor = {
  createLobby: vi.fn(),
  joinLobby: vi.fn(),
  leaveLobby: vi.fn(),
  setReady: vi.fn(),
  setColor: vi.fn(),
  startGame: vi.fn(),
  chooseRps: vi.fn(),
  updatePosition: vi.fn(),
  catchHider: vi.fn(),
  resetGame: vi.fn(),
  endLobby: vi.fn(),
  getGameState: vi.fn(),
  syncGameState: vi.fn(),
};

let gameState: {
  game: GameView | null;
  isLoading: boolean;
  notInLobby: boolean;
};
let geoState: {
  position: { lat: number; lng: number } | null;
  accuracy: number | null;
  error: string | null;
  isLoading: boolean;
  isSupported: boolean;
};

vi.mock("@tanstack/react-router", () => ({
  useNavigate: () => navigate,
}));

vi.mock("@caffeineai/core-infrastructure", () => ({
  useActor: () => ({ actor, isFetching: false }),
}));

vi.mock("@/hooks/useGameState", () => ({
  useGameState: () => ({
    ...gameState,
    isFetching: false,
    error: null,
    refresh,
  }),
}));

vi.mock("@/hooks/useGeolocation", () => ({
  useGeolocation: () => geoState,
}));

// The map draws to a canvas and fetches OSM tiles; neither is meaningful in
// jsdom, so it is replaced with a marker that exposes the props under test.
vi.mock("@/components/GameMap", () => ({
  GameMap: (props: {
    markers?: { id: string; isSelf?: boolean }[];
    boundaryRadiusM?: number;
  }) => (
    <div
      data-testid="game-map"
      data-marker-count={props.markers?.length ?? 0}
      data-boundary-radius={props.boundaryRadiusM ?? ""}
    />
  ),
}));

function player(overrides: Partial<PlayerView> = {}): PlayerView {
  return {
    id: 1n,
    name: "Ada",
    color: "#3fd67f",
    role: Role.hider,
    isHost: false,
    isReady: false,
    isDisqualified: false,
    isCaught: false,
    isOriginalSeeker: false,
    ...overrides,
  };
}

function position(playerId: bigint, lat: number, lng: number): PlayerPosition {
  return {
    playerId,
    point: {
      lat: BigInt(Math.round(lat * 1_000_000)),
      lng: BigInt(Math.round(lng * 1_000_000)),
    },
    distanceFromStart: 0n,
    updatedAt: 1_000_000_000n,
  };
}

function gameView(overrides: Partial<GameView> = {}): GameView {
  return {
    accessCode: "K7Q2M9",
    selfId: 1n,
    serverNow: 1_000_000_000n,
    players: [player()],
    lobbyId: 1n,
    phase: LobbyPhase.active,
    hostId: 1n,
    winnerIds: [],
    visiblePositions: [],
    ...overrides,
  };
}

describe("GamePage", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    gameState = { game: null, isLoading: false, notInLobby: true };
    geoState = {
      position: { lat: 51.5074, lng: -0.1278 },
      accuracy: 5,
      error: null,
      isLoading: false,
      isSupported: true,
    };
  });

  it("shows a not-in-lobby state when there is no game", () => {
    render(<GamePage code="K7Q2M9" />);
    expect(screen.getByText(/no active game/i)).toBeInTheDocument();
  });

  it("shows the hider role badge and the map", () => {
    gameState = { game: gameView(), isLoading: false, notInLobby: false };
    render(<GamePage code="K7Q2M9" />);

    expect(screen.getByText("Hider")).toBeInTheDocument();
    expect(screen.getByTestId("game-map")).toBeInTheDocument();
  });

  it("shows the seeker role badge and the catch control", () => {
    gameState = {
      game: gameView({
        players: [
          player({
            id: 1n,
            name: "Ada",
            role: Role.seeker,
            isOriginalSeeker: true,
          }),
        ],
      }),
      isLoading: false,
      notInLobby: false,
    };
    render(<GamePage code="K7Q2M9" />);

    expect(screen.getByText("Seeker")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /catch/i })).toBeInTheDocument();
  });

  it("draws the 500m play-zone boundary around the start point", () => {
    gameState = {
      game: gameView({
        startPoint: { lat: 51_507_400n, lng: -127_800n },
      }),
      isLoading: false,
      notInLobby: false,
    };
    render(<GamePage code="K7Q2M9" />);

    expect(screen.getByTestId("game-map")).toHaveAttribute(
      "data-boundary-radius",
      "500",
    );
  });

  it("warns when the player is outside the 500m zone", () => {
    // Start point ~1.5km north of the mocked device position.
    gameState = {
      game: gameView({ startPoint: { lat: 51_521_000n, lng: -127_800n } }),
      isLoading: false,
      notInLobby: false,
    };
    render(<GamePage code="K7Q2M9" />);

    expect(screen.getByText(/outside the 500m zone/i)).toBeInTheDocument();
  });

  it("warns the seeker who moves more than 3 feet during the wait", () => {
    // Start point ~5m north of the mocked device position (3ft = 0.9144m).
    gameState = {
      game: gameView({
        phase: LobbyPhase.waiting,
        startPoint: { lat: 51_507_445n, lng: -127_800n },
        players: [
          player({
            id: 1n,
            name: "Ada",
            role: Role.seeker,
            isOriginalSeeker: true,
          }),
        ],
      }),
      isLoading: false,
      notInLobby: false,
    };
    render(<GamePage code="K7Q2M9" />);

    expect(screen.getByText(/stay put/i)).toBeInTheDocument();
  });

  it("does not warn the seeker who holds the start point", () => {
    gameState = {
      game: gameView({
        phase: LobbyPhase.waiting,
        startPoint: { lat: 51_507_400n, lng: -127_800n },
        players: [
          player({
            id: 1n,
            name: "Ada",
            role: Role.seeker,
            isOriginalSeeker: true,
          }),
        ],
      }),
      isLoading: false,
      notInLobby: false,
    };
    render(<GamePage code="K7Q2M9" />);

    expect(screen.queryByText(/stay put/i)).not.toBeInTheDocument();
  });

  it("warns a hider to freeze when the seeker is within 10m", () => {
    // Seeker ~5m north of the hider's mocked position.
    gameState = {
      game: gameView({
        players: [
          player({ id: 1n, name: "Ada", role: Role.hider }),
          player({
            id: 2n,
            name: "Bob",
            color: "#5aa9ff",
            role: Role.seeker,
            isOriginalSeeker: true,
          }),
        ],
        visiblePositions: [position(2n, 51.507445, -0.1278)],
      }),
      isLoading: false,
      notInLobby: false,
    };
    render(<GamePage code="K7Q2M9" />);

    expect(screen.getByText(/freeze — seeker within 10m/i)).toBeInTheDocument();
  });

  it("does not warn a hider when the seeker is far away", () => {
    gameState = {
      game: gameView({
        players: [
          player({ id: 1n, name: "Ada", role: Role.hider }),
          player({
            id: 2n,
            name: "Bob",
            color: "#5aa9ff",
            role: Role.seeker,
            isOriginalSeeker: true,
          }),
        ],
        visiblePositions: [position(2n, 51.6, -0.1278)],
      }),
      isLoading: false,
      notInLobby: false,
    };
    render(<GamePage code="K7Q2M9" />);

    expect(screen.queryByText(/freeze/i)).not.toBeInTheDocument();
  });

  it("enables the catch button when a hider is within 3m", () => {
    // Hider ~2m north of the seeker's mocked position.
    gameState = {
      game: gameView({
        players: [
          player({
            id: 1n,
            name: "Ada",
            role: Role.seeker,
            isOriginalSeeker: true,
          }),
          player({ id: 2n, name: "Bob", color: "#5aa9ff", role: Role.hider }),
        ],
        visiblePositions: [position(2n, 51.507418, -0.1278)],
      }),
      isLoading: false,
      notInLobby: false,
    };
    render(<GamePage code="K7Q2M9" />);

    expect(screen.getByRole("button", { name: /catch/i })).toBeEnabled();
  });

  it("sends a catch for the nearest hider", async () => {
    const user = userEvent.setup();
    vi.mocked(actor.catchHider).mockResolvedValue({ __kind__: "ok", ok: null });
    gameState = {
      game: gameView({
        players: [
          player({
            id: 1n,
            name: "Ada",
            role: Role.seeker,
            isOriginalSeeker: true,
          }),
          player({ id: 2n, name: "Bob", color: "#5aa9ff", role: Role.hider }),
        ],
        visiblePositions: [position(2n, 51.507418, -0.1278)],
      }),
      isLoading: false,
      notInLobby: false,
    };
    render(<GamePage code="K7Q2M9" />);

    await user.click(screen.getByRole("button", { name: /catch/i }));

    await waitFor(() => expect(actor.catchHider).toHaveBeenCalledWith(2n));
  });

  it("shows the RPS picker during the rps phase and submits a choice", async () => {
    const user = userEvent.setup();
    vi.mocked(actor.chooseRps).mockResolvedValue({ __kind__: "ok", ok: null });
    gameState = {
      game: gameView({
        phase: LobbyPhase.rps,
        rps: {
          round: 0n,
          outcome: RpsOutcome.pending,
          players: [
            { playerId: 1n, hasChosen: false },
            { playerId: 2n, hasChosen: false },
          ],
        },
      }),
      isLoading: false,
      notInLobby: false,
    };
    render(<GamePage code="K7Q2M9" />);

    await user.click(screen.getByRole("button", { name: /rock/i }));

    await waitFor(() =>
      expect(actor.chooseRps).toHaveBeenCalledWith(RpsChoice.rock),
    );
  });

  it("shows the seeker wait panel during the waiting phase", () => {
    gameState = {
      game: gameView({
        phase: LobbyPhase.waiting,
        players: [
          player({
            id: 1n,
            name: "Ada",
            role: Role.seeker,
            isOriginalSeeker: true,
          }),
        ],
      }),
      isLoading: false,
      notInLobby: false,
    };
    render(<GamePage code="K7Q2M9" />);

    expect(screen.getByText(/your head start/i)).toBeInTheDocument();
  });

  it("shows the seeker reveal state to a hider during an active reveal", () => {
    gameState = {
      game: gameView({
        reveal: { active: true, hiders: [] },
      }),
      isLoading: false,
      notInLobby: false,
    };
    render(<GamePage code="K7Q2M9" />);

    expect(screen.getByText(/seeker can see you/i)).toBeInTheDocument();
  });

  it("routes to the results screen once the game ends", () => {
    gameState = {
      game: gameView({
        phase: LobbyPhase.ended,
        endReason: EndReason.timeExpired,
      }),
      isLoading: false,
      notInLobby: false,
    };
    render(<GamePage code="K7Q2M9" />);

    expect(navigate).toHaveBeenCalledWith({
      to: "/results/$code",
      params: { code: "K7Q2M9" },
    });
  });
});
