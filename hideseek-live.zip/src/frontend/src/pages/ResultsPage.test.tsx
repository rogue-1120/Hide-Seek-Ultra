import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";

import type { GameActor } from "@/lib/backend";
import ResultsPage from "@/pages/ResultsPage";
import {
  EndReason,
  type GameView,
  LobbyPhase,
  type PlayerView,
  Role,
} from "@/types/game";

/**
 * Critical journey: the end-of-round screen. Verifies the winner announcement,
 * per-player final states, and the host/non-host controls. The actor and the
 * polling hook are mocked locally.
 */

const navigate = vi.fn();
const actor: GameActor = {
  createLobby: vi.fn(),
  joinLobby: vi.fn(),
  leaveLobby: vi.fn(),
  setReady: vi.fn(),
  setColor: vi.fn(),
  startGame: vi.fn(),
  chooseRps: vi.fn(),
  updatePosition: vi.fn(),
  catchHider: vi.fn(),
  resetGame: vi.fn(),
  endLobby: vi.fn(),
  getGameState: vi.fn(),
  syncGameState: vi.fn(),
};

let gameState: {
  game: GameView | null;
  isLoading: boolean;
  notInLobby: boolean;
};

vi.mock("@tanstack/react-router", () => ({
  useNavigate: () => navigate,
}));

vi.mock("@caffeineai/core-infrastructure", () => ({
  useActor: () => ({ actor, isFetching: false }),
}));

vi.mock("@/hooks/useGameState", () => ({
  useGameState: () => ({
    ...gameState,
    isFetching: false,
    error: null,
    refresh: vi.fn(),
  }),
}));

function player(overrides: Partial<PlayerView> = {}): PlayerView {
  return {
    id: 1n,
    name: "Ada",
    color: "#3fd67f",
    role: Role.hider,
    isHost: false,
    isReady: false,
    isDisqualified: false,
    isCaught: false,
    isOriginalSeeker: false,
    ...overrides,
  };
}

function gameView(overrides: Partial<GameView> = {}): GameView {
  return {
    accessCode: "K7Q2M9",
    selfId: 1n,
    serverNow: 1_000_000_000n,
    players: [player()],
    lobbyId: 1n,
    phase: LobbyPhase.ended,
    hostId: 1n,
    winnerIds: [],
    visiblePositions: [],
    ...overrides,
  };
}

describe("ResultsPage", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    gameState = { game: null, isLoading: false, notInLobby: true };
  });

  it("shows the not-in-lobby state when there is no game", () => {
    render(<ResultsPage code="K7Q2M9" />);
    expect(screen.getByText(/no round to show/i)).toBeInTheDocument();
  });

  it("announces the all-hiders-caught outcome", () => {
    gameState = {
      game: gameView({
        endReason: EndReason.allHidersCaught,
        players: [
          player({
            id: 1n,
            name: "Ada",
            role: Role.seeker,
            isOriginalSeeker: true,
          }),
        ],
        winnerIds: [1n],
      }),
      isLoading: false,
      notInLobby: false,
    };
    render(<ResultsPage code="K7Q2M9" />);

    expect(screen.getByText("All hiders caught")).toBeInTheDocument();
    expect(screen.getByText(/swept the zone clean/i)).toBeInTheDocument();
  });

  it("announces the time-expired outcome", () => {
    gameState = {
      game: gameView({ endReason: EndReason.timeExpired }),
      isLoading: false,
      notInLobby: false,
    };
    render(<ResultsPage code="K7Q2M9" />);

    expect(screen.getByText("Time expired")).toBeInTheDocument();
    expect(screen.getByText(/hiders still in play/i)).toBeInTheDocument();
  });

  it("lists each player's final state", () => {
    gameState = {
      game: gameView({
        endReason: EndReason.timeExpired,
        players: [
          player({ id: 1n, name: "Ada", role: Role.hider }),
          player({
            id: 2n,
            name: "Bob",
            color: "#5aa9ff",
            role: Role.seeker,
            isOriginalSeeker: true,
          }),
          player({
            id: 3n,
            name: "Cy",
            color: "#f06bd0",
            role: Role.hider,
            isCaught: true,
          }),
          player({
            id: 4n,
            name: "Dee",
            color: "#f2b53c",
            role: Role.hider,
            isDisqualified: true,
          }),
        ],
        winnerIds: [1n],
      }),
      isLoading: false,
      notInLobby: false,
    };
    render(<ResultsPage code="K7Q2M9" />);

    expect(screen.getByText("Winner")).toBeInTheDocument();
    expect(screen.getByText("Caught")).toBeInTheDocument();
    expect(screen.getByText("Out of zone")).toBeInTheDocument();
    expect(screen.getByText("Survived")).toBeInTheDocument();
    expect(screen.getByText("Seeker · original")).toBeInTheDocument();
  });

  it("shows host controls to the host", () => {
    gameState = {
      game: gameView({
        endReason: EndReason.timeExpired,
        players: [player({ id: 1n, name: "Ada", isHost: true })],
      }),
      isLoading: false,
      notInLobby: false,
    };
    render(<ResultsPage code="K7Q2M9" />);

    expect(
      screen.getByRole("button", { name: /reset game/i }),
    ).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: /end lobby/i }),
    ).toBeInTheDocument();
    expect(screen.queryByText(/waiting for the host/i)).not.toBeInTheDocument();
  });

  it("shows the waiting message and leave control to a non-host", () => {
    gameState = {
      game: gameView({
        endReason: EndReason.timeExpired,
        players: [
          player({ id: 1n, name: "Ada" }),
          player({ id: 2n, name: "Bob", color: "#5aa9ff", isHost: true }),
        ],
        hostId: 2n,
      }),
      isLoading: false,
      notInLobby: false,
    };
    render(<ResultsPage code="K7Q2M9" />);

    expect(screen.getByText(/waiting for the host/i)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /leave/i })).toBeInTheDocument();
    expect(
      screen.queryByRole("button", { name: /reset game/i }),
    ).not.toBeInTheDocument();
  });

  it("resets the game and returns to the lobby when the host resets", async () => {
    const user = userEvent.setup();
    vi.mocked(actor.resetGame).mockResolvedValue({ __kind__: "ok", ok: null });
    gameState = {
      game: gameView({
        endReason: EndReason.timeExpired,
        players: [player({ id: 1n, name: "Ada", isHost: true })],
      }),
      isLoading: false,
      notInLobby: false,
    };
    render(<ResultsPage code="K7Q2M9" />);

    await user.click(screen.getByRole("button", { name: /reset game/i }));

    await waitFor(() => expect(actor.resetGame).toHaveBeenCalled());
    await waitFor(() =>
      expect(navigate).toHaveBeenCalledWith({
        to: "/lobby/$code",
        params: { code: "K7Q2M9" },
      }),
    );
  });

  it("surfaces an error when the host reset fails", async () => {
    const user = userEvent.setup();
    vi.mocked(actor.resetGame).mockResolvedValue({
      __kind__: "err",
      err: { __kind__: "NotInLobby" },
    });
    gameState = {
      game: gameView({
        endReason: EndReason.timeExpired,
        players: [player({ id: 1n, name: "Ada", isHost: true })],
      }),
      isLoading: false,
      notInLobby: false,
    };
    render(<ResultsPage code="K7Q2M9" />);

    await user.click(screen.getByRole("button", { name: /reset game/i }));

    await waitFor(() =>
      expect(screen.getByText("Something went wrong.")).toBeInTheDocument(),
    );
    expect(navigate).not.toHaveBeenCalled();
  });

  it("follows the host back to the lobby when the phase returns to lobby", () => {
    gameState = {
      game: gameView({
        phase: LobbyPhase.lobby,
        endReason: EndReason.hostEnded,
        players: [player({ id: 1n, name: "Ada" })],
      }),
      isLoading: false,
      notInLobby: false,
    };
    render(<ResultsPage code="K7Q2M9" />);

    expect(navigate).toHaveBeenCalledWith({
      to: "/lobby/$code",
      params: { code: "K7Q2M9" },
    });
  });
});
