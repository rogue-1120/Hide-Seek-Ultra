import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PLAYER_COLORS } from "@/types/game";
import { useNavigate } from "@tanstack/react-router";
import { ArrowRight, KeyRound, Plus, Radar, Users } from "lucide-react";
import { useState } from "react";

/**
 * Landing screen: create a lobby or join one by access code.
 *
 * The actual create/join mutations live in the lobby task; this screen owns
 * the entry points and routes the player to `/lobby/:code`.
 */
export default function HomePage() {
  const navigate = useNavigate();
  const [code, setCode] = useState("");

  const normalizedCode = code.replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
  const canJoin = normalizedCode.length === 6;

  const handleJoin = (event: React.FormEvent) => {
    event.preventDefault();
    if (!canJoin) return;
    void navigate({
      to: "/lobby/$code",
      params: { code: normalizedCode },
    });
  };

  return (
    <div className="flex flex-col gap-8">
      <section className="relative overflow-hidden rounded-2xl border border-border bg-card p-6 shadow-hud-panel">
        <div className="pointer-events-none absolute inset-0 bg-zone-glow" />
        <div className="relative flex flex-col gap-4">
          <span className="inline-flex w-fit items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-3 py-1 font-mono text-[11px] uppercase tracking-widest text-primary">
            <span className="size-1.5 animate-pulse-live rounded-full bg-primary" />
            Live field game
          </span>
          <h1 className="font-display text-3xl font-bold leading-tight tracking-tight">
            Hide &amp; seek,
            <br />
            across the whole block.
          </h1>
          <p className="max-w-md text-sm text-muted-foreground">
            Gather 2–12 players, pick your color, and let rock-paper-scissors
            decide the seeker. Stay inside the 500m zone for one hour.
          </p>
          <div className="flex flex-wrap gap-2 pt-1">
            {PLAYER_COLORS.map((color) => (
              <span
                key={color.slot}
                className="size-4 rounded-full ring-2 ring-background"
                style={{ backgroundColor: color.hex }}
                aria-hidden="true"
              />
            ))}
          </div>
        </div>
      </section>

      <section className="flex flex-col gap-4">
        <div className="flex items-center gap-2 text-muted-foreground">
          <Radar className="size-4" />
          <h2 className="font-mono text-xs uppercase tracking-widest">
            Start a match
          </h2>
        </div>

        <Button
          type="button"
          size="lg"
          className="h-14 w-full rounded-full text-base font-semibold uppercase tracking-wider"
          data-ocid="home.create_lobby_button"
          onClick={() =>
            void navigate({ to: "/lobby/$code", params: { code: "new" } })
          }
        >
          <Plus className="size-5" />
          Create lobby
        </Button>

        <form
          onSubmit={handleJoin}
          className="flex flex-col gap-3 rounded-2xl border border-border bg-card p-5"
        >
          <div className="flex items-center gap-2">
            <KeyRound className="size-4 text-muted-foreground" />
            <Label
              htmlFor="access-code"
              className="font-mono text-xs uppercase tracking-widest text-muted-foreground"
            >
              Join with code
            </Label>
          </div>
          <Input
            id="access-code"
            value={code}
            onChange={(event) => setCode(event.target.value.toUpperCase())}
            placeholder="K7Q2M9"
            maxLength={6}
            autoComplete="off"
            autoCapitalize="characters"
            spellCheck={false}
            inputMode="text"
            data-ocid="home.access_code_input"
            className="code-plate h-14 rounded-xl border-input bg-background text-center text-2xl uppercase"
          />
          <Button
            type="submit"
            variant="secondary"
            size="lg"
            disabled={!canJoin}
            className="h-12 w-full rounded-full uppercase tracking-wider"
            data-ocid="home.join_lobby_button"
          >
            Join lobby
            <ArrowRight className="size-4" />
          </Button>
          {!canJoin && code.length > 0 && (
            <p
              className="text-center text-xs text-muted-foreground"
              data-ocid="home.code_error"
            >
              Enter all 6 characters of the lobby code.
            </p>
          )}
        </form>
      </section>

      <section className="grid grid-cols-3 gap-3">
        {[
          { icon: Users, label: "2–12 players" },
          { icon: Radar, label: "500m zone" },
          { icon: KeyRound, label: "1 hour round" },
        ].map((item) => (
          <div
            key={item.label}
            className="flex flex-col items-center gap-2 rounded-xl border border-border bg-card/60 px-2 py-4 text-center"
          >
            <item.icon className="size-5 text-primary" />
            <span className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
              {item.label}
            </span>
          </div>
        ))}
      </section>
    </div>
  );
}
