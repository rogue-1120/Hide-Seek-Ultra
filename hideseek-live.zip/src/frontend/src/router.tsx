import { Layout } from "@/components/Layout";
import GamePage from "@/pages/GamePage";
import HomePage from "@/pages/HomePage";
import LobbyPage from "@/pages/LobbyPage";
import ResultsPage from "@/pages/ResultsPage";
import {
  Outlet,
  createRootRoute,
  createRoute,
  createRouter,
  useRouterState,
} from "@tanstack/react-router";

function RootComponent() {
  const pathname = useRouterState({
    select: (state) => state.location.pathname,
  });
  // Gameplay owns the whole viewport: no header, no footer, no page padding.
  const immersive = pathname.startsWith("/game/");
  return (
    <Layout fullBleed={immersive} hideHeader={immersive}>
      <Outlet />
    </Layout>
  );
}

const rootRoute = createRootRoute({
  component: RootComponent,
});

const homeRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/",
  component: HomePage,
});

const lobbyRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/lobby/$code",
  component: LobbyRouteComponent,
});

const gameRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/game/$code",
  component: GameRouteComponent,
});

const resultsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/results/$code",
  component: ResultsRouteComponent,
});

function LobbyRouteComponent() {
  const { code } = lobbyRoute.useParams();
  return <LobbyPage code={code} />;
}

function GameRouteComponent() {
  const { code } = gameRoute.useParams();
  return <GamePage code={code} />;
}

function ResultsRouteComponent() {
  const { code } = resultsRoute.useParams();
  return <ResultsPage code={code} />;
}

const routeTree = rootRoute.addChildren([
  homeRoute,
  lobbyRoute,
  gameRoute,
  resultsRoute,
]);

export const router = createRouter({ routeTree });

declare module "@tanstack/react-router" {
  interface Register {
    router: typeof router;
  }
}
