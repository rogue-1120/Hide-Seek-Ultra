import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export type AccessCode = string;
export interface Cell {
    value: Value;
    name: string;
}
export type Centimetres = bigint;
export type ColorHex = string;
export interface CreateLobbyResult {
    playerId: PlayerId;
    accessCode: AccessCode;
    lobbyId: LobbyId;
}
export type Error_ = {
    __kind__: "FrontendOriginsNotConfigured";
    FrontendOriginsNotConfigured: null;
} | {
    __kind__: "MixedSsoSources";
    MixedSsoSources: {
        otherKeys: Array<string>;
        ssoKeys: Array<string>;
    };
} | {
    __kind__: "Stale";
    Stale: {
        ageNs: bigint;
    };
} | {
    __kind__: "MalformedCandid";
    MalformedCandid: null;
} | {
    __kind__: "AmbiguousAttribute";
    AmbiguousAttribute: {
        field: string;
        sources: Array<string>;
    };
} | {
    __kind__: "NoAttributes";
    NoAttributes: null;
} | {
    __kind__: "UnknownNonce";
    UnknownNonce: null;
} | {
    __kind__: "UntrustedSsoSource";
    UntrustedSsoSource: {
        domain: string;
    };
} | {
    __kind__: "MissingField";
    MissingField: string;
} | {
    __kind__: "FrontendOriginMismatch";
    FrontendOriginMismatch: {
        got: string;
        expected: Array<string>;
    };
};
export interface GameView {
    rps?: RpsState;
    reveal?: RevealState;
    startedAt?: Timestamp;
    selfPosition?: PlayerPosition;
    endReason?: EndReason;
    accessCode: AccessCode;
    selfId: PlayerId;
    serverNow: Timestamp;
    players: Array<PlayerView>;
    lobbyId: LobbyId;
    phase: LobbyPhase;
    hostId: PlayerId;
    waitEndsAt?: Timestamp;
    winnerIds: Array<PlayerId>;
    visiblePositions: Array<PlayerPosition>;
    startPoint?: GeoPoint;
    endsAt?: Timestamp;
}
export interface GeoPoint {
    lat: MicroDegrees;
    lng: MicroDegrees;
}
export interface JoinLobbyResult {
    playerId: PlayerId;
    lobbyId: LobbyId;
}
export type LobbyId = bigint;
export type MicroDegrees = bigint;
export type PlayerId = bigint;
export interface PlayerPosition {
    distanceFromStart: Centimetres;
    playerId: PlayerId;
    updatedAt: Timestamp;
    point: GeoPoint;
}
export interface PlayerView {
    id: PlayerId;
    isCaught: boolean;
    name: string;
    color: ColorHex;
    role: Role;
    isHost: boolean;
    isReady: boolean;
    isDisqualified: boolean;
    isOriginalSeeker: boolean;
}
export type Result = {
    __kind__: "ok";
    ok: null;
} | {
    __kind__: "err";
    err: GameError;
};
export type Result_1 = {
    __kind__: "ok";
    ok: GameView;
} | {
    __kind__: "err";
    err: GameError;
};
export type Result_2 = {
    __kind__: "ok";
    ok: JoinLobbyResult;
} | {
    __kind__: "err";
    err: GameError;
};
export type Result_3 = {
    __kind__: "ok";
    ok: CreateLobbyResult;
} | {
    __kind__: "err";
    err: GameError;
};
export type Result_4 = {
    __kind__: "ok";
    ok: null;
} | {
    __kind__: "err";
    err: Error_;
};
export interface Result__1 {
    hasMore: boolean;
    rows: Array<Array<Cell>>;
}
export interface RevealState {
    startedAt?: Timestamp;
    active: boolean;
    expiresAt?: Timestamp;
    nextRevealAt?: Timestamp;
    hiders: Array<RevealedHider>;
}
export interface RevealedHider {
    playerId: PlayerId;
    point: GeoPoint;
}
export interface RpsPlayerState {
    hasChosen: boolean;
    playerId: PlayerId;
    choice?: RpsChoice;
}
export interface RpsState {
    seekerId?: PlayerId;
    players: Array<RpsPlayerState>;
    outcome: RpsOutcome;
    round: bigint;
}
export type Timestamp = bigint;
export type Value = {
    __kind__: "int";
    int: bigint;
} | {
    __kind__: "nat";
    nat: bigint;
} | {
    __kind__: "float";
    float: number;
} | {
    __kind__: "bool";
    bool: boolean;
} | {
    __kind__: "null";
    null: null;
} | {
    __kind__: "text";
    text: string;
};
export enum EndReason {
    hostEnded = "hostEnded",
    timeExpired = "timeExpired",
    allHidersCaught = "allHidersCaught"
}
export enum GameError {
    colorTaken = "colorTaken",
    notHost = "notHost",
    lobbyNotJoinable = "lobbyNotJoinable",
    alreadyChosen = "alreadyChosen",
    hiderNotNearby = "hiderNotNearby",
    wrongPhase = "wrongPhase",
    notFound = "notFound",
    tooManyPlayers = "tooManyPlayers",
    targetDisqualified = "targetDisqualified",
    alreadyDisqualified = "alreadyDisqualified",
    notEnoughPlayers = "notEnoughPlayers",
    invalidCode = "invalidCode",
    invalidName = "invalidName",
    noPosition = "noPosition",
    lobbyFull = "lobbyFull",
    targetNotHider = "targetNotHider",
    notSeeker = "notSeeker",
    notInLobby = "notInLobby",
    gameNotActive = "gameNotActive",
    invalidColor = "invalidColor"
}
export enum LobbyPhase {
    rps = "rps",
    active = "active",
    ended = "ended",
    lobby = "lobby",
    waiting = "waiting"
}
export enum Role {
    hider = "hider",
    seeker = "seeker"
}
export enum RpsChoice {
    scissors = "scissors",
    rock = "rock",
    paper = "paper"
}
export enum RpsOutcome {
    tie = "tie",
    resolved = "resolved",
    pending = "pending"
}
export enum UserRole {
    admin = "admin",
    user = "user",
    guest = "guest"
}
export interface backendInterface {
    assignCallerUserRole(user: Principal, role: UserRole): Promise<void>;
    /**
     * / Seeker-only: catch a hider within 3m, converting them to a seeker.
     */
    catchHider(targetId: PlayerId): Promise<Result>;
    /**
     * / Submit the caller's rock-paper-scissors choice for the current round.
     */
    chooseRps(choice: RpsChoice): Promise<Result>;
    /**
     * / Create a new lobby and join it as host. Returns the lobby id and access code.
     */
    createLobby(name: string, color: ColorHex): Promise<Result_3>;
    /**
     * / Host-only: end the lobby and return everyone to home.
     */
    endLobby(): Promise<Result>;
    execute(qJson: string): Promise<Result__1>;
    getApiDoc(): Promise<string>;
    getCallerUserRole(): Promise<UserRole>;
    /**
     * / Read the caller's current lobby and game state.
     */
    getGameState(): Promise<Result_1>;
    isCallerAdmin(): Promise<boolean>;
    /**
     * / Join an existing lobby by its 6-character access code.
     */
    joinLobby(accessCode: AccessCode, name: string, color: ColorHex): Promise<Result_2>;
    /**
     * / Leave the current lobby. Allowed while the lobby is open and after the host
     * / has ended it, so every player has a working exit back home.
     */
    leaveLobby(): Promise<Result>;
    /**
     * / Host-only: reset the game back to the lobby phase.
     */
    resetGame(): Promise<Result>;
    schema(): Promise<string>;
    /**
     * / Change the caller's chosen color, if still available.
     */
    setColor(color: ColorHex): Promise<Result>;
    /**
     * / Mark the caller ready or not ready in the lobby.
     */
    setReady(ready: boolean): Promise<Result>;
    /**
     * / Host-only: start the game (requires 2-12 players), entering the RPS phase.
     */
    startGame(): Promise<Result>;
    /**
     * / Read the caller's current lobby and game state (update variant, advances timers).
     */
    syncGameState(): Promise<Result_1>;
    /**
     * / Report the caller's current position (latitude/longitude).
     */
    updatePosition(lat: MicroDegrees, lng: MicroDegrees): Promise<Result>;
}
