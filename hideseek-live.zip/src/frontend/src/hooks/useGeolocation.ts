import { createActor } from "@/backend";
import { gameApi } from "@/lib/backend";
import { degreesToMicro } from "@/lib/geo";
import { useActor } from "@caffeineai/core-infrastructure";
import { useEffect, useRef, useState } from "react";

/** Minimum movement (metres) before a new position is pushed to the backend. */
const MIN_PUSH_DISTANCE_M = 3;
/** Minimum interval between backend pushes, in milliseconds. */
const MIN_PUSH_INTERVAL_MS = 4000;

export interface GeolocationState {
  /** Latest device position in decimal degrees, or `null` before first fix. */
  position: { lat: number; lng: number } | null;
  /** Accuracy of the latest fix, in metres. */
  accuracy: number | null;
  /** Human-readable geolocation error, if any. */
  error: string | null;
  /** True until the first fix or error arrives. */
  isLoading: boolean;
  /** True when the browser does not expose the geolocation API. */
  isSupported: boolean;
}

/**
 * Watches the device position and pushes meaningful updates to the backend.
 *
 * `watchPosition` is used so movement is tracked continuously. Pushes are
 * throttled by both distance and time to avoid flooding the canister while
 * standing still. Pass `enabled: false` to keep watching locally without
 * reporting (for example, before the game is active).
 */
export function useGeolocation(enabled = true): GeolocationState {
  const { actor } = useActor(createActor);
  const [state, setState] = useState<GeolocationState>({
    position: null,
    accuracy: null,
    error: null,
    isLoading: true,
    isSupported: typeof navigator !== "undefined" && "geolocation" in navigator,
  });

  const lastPushRef = useRef<{ lat: number; lng: number; at: number } | null>(
    null,
  );
  const actorRef = useRef(actor);
  actorRef.current = actor;

  useEffect(() => {
    if (typeof navigator === "undefined" || !("geolocation" in navigator)) {
      setState((prev) => ({
        ...prev,
        isLoading: false,
        isSupported: false,
        error: "This device does not support location services.",
      }));
      return;
    }

    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        const next = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
        };
        setState({
          position: next,
          accuracy: pos.coords.accuracy,
          error: null,
          isLoading: false,
          isSupported: true,
        });

        if (!enabled) return;
        const currentActor = actorRef.current;
        if (!currentActor) return;

        const last = lastPushRef.current;
        const now = Date.now();
        const movedEnough =
          !last ||
          Math.abs(last.lat - next.lat) > 0.00002 ||
          Math.abs(last.lng - next.lng) > 0.00002;
        const waitedEnough = !last || now - last.at >= MIN_PUSH_INTERVAL_MS;

        if (movedEnough && waitedEnough) {
          lastPushRef.current = { ...next, at: now };
          void gameApi.updatePosition(
            currentActor,
            degreesToMicro(next.lat),
            degreesToMicro(next.lng),
          );
        }
      },
      (err) => {
        setState((prev) => ({
          ...prev,
          isLoading: false,
          error:
            err.code === err.PERMISSION_DENIED
              ? "Location permission denied. Enable it to play."
              : "Unable to get a GPS fix. Move to an open area.",
        }));
      },
      {
        enableHighAccuracy: true,
        maximumAge: 2000,
        timeout: 15000,
      },
    );

    return () => {
      navigator.geolocation.clearWatch(watchId);
    };
  }, [enabled]);

  return state;
}

export { MIN_PUSH_DISTANCE_M };
