import { createActor } from "@/backend";
import { gameApi } from "@/lib/backend";
import type { GameError, GameView } from "@/types/game";
import { useActor } from "@caffeineai/core-infrastructure";
import { useQuery } from "@tanstack/react-query";

/** Polling interval for live game state, in milliseconds. */
export const GAME_POLL_MS = 2000;

export interface GameStateResult {
  /** Latest game view, or `null` when the caller is not in a lobby. */
  game: GameView | null;
  /** True while the first fetch is in flight. */
  isLoading: boolean;
  /** True while any fetch (initial or poll) is in flight. */
  isFetching: boolean;
  /** Backend error from the most recent fetch, if any. */
  error: GameError | null;
  /** True when the backend reports the caller is not in a lobby. */
  notInLobby: boolean;
  /** Force an immediate refetch. */
  refresh: () => void;
}

/**
 * Polls `syncGameState` on an interval and exposes the latest `GameView`.
 *
 * `syncGameState` is the update variant: it advances server-side timers, so it
 * is the correct call for a live polling loop. The query is disabled until the
 * actor is ready, and polling stops automatically when the tab is hidden.
 */
export function useGameState(enabled = true): GameStateResult {
  const { actor, isFetching: actorFetching } = useActor(createActor);

  const query = useQuery({
    queryKey: ["gameState"],
    queryFn: async () => {
      if (!actor) return null;
      const result = await gameApi.syncGameState(actor);
      if (!result.ok) {
        if (result.error === "notInLobby" || result.error === "notFound") {
          return null;
        }
        throw new Error(result.error);
      }
      return result.value;
    },
    enabled: !!actor && !actorFetching && enabled,
    refetchInterval: GAME_POLL_MS,
    refetchIntervalInBackground: false,
    staleTime: 0,
    retry: false,
  });

  const error =
    query.error instanceof Error ? (query.error.message as GameError) : null;

  return {
    game: query.data ?? null,
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    error,
    notInLobby: !query.isLoading && !query.error && query.data === null,
    refresh: () => {
      void query.refetch();
    },
  };
}
