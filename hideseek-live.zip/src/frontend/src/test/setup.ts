import "@testing-library/jest-dom/vitest";
import { cleanup } from "@testing-library/react";
import { afterEach } from "vitest";

/**
 * Shared test setup: jest-dom matchers plus a DOM cleanup between tests.
 *
 * `ResizeObserver` is not implemented in jsdom, and the map component observes
 * its container size on mount, so a minimal stub keeps component tests from
 * throwing on an unrelated browser API.
 */
afterEach(() => {
  cleanup();
});

if (!("ResizeObserver" in globalThis)) {
  class ResizeObserverStub {
    observe() {}
    unobserve() {}
    disconnect() {}
  }
  globalThis.ResizeObserver =
    ResizeObserverStub as unknown as typeof ResizeObserver;
}
