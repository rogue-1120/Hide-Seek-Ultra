import { router } from "@/router";
import { RouterProvider } from "@tanstack/react-router";
import { useEffect } from "react";

/**
 * Application root: mounts the router and pins the document to dark mode.
 *
 * The design system is dark-first (outdoor/night play), so `.dark` is applied
 * to the root element on mount rather than toggled by the user.
 */
export default function App() {
  useEffect(() => {
    const root = document.documentElement;
    root.classList.add("dark");
    root.style.colorScheme = "dark";
  }, []);

  return <RouterProvider router={router} />;
}
